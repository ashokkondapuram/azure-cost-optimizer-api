// ─── API helper ───────────────────────────────────────────────────────────────
const _API_TIMEOUT_MS = 20000; // 20s — handles Azure cold-start

async function api(path, opts = {}) {
  const token = localStorage.getItem('rs_token');
  // Allow callers to pass _timeoutMs to override default (e.g. slow AI calls)
  const timeoutMs = opts._timeoutMs || _API_TIMEOUT_MS;
  const { _timeoutMs, ...restOpts } = opts;
  const defaults = {
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { 'X-Auth-Token': token } : {})
    }
  };
  const merged = { ...defaults, ...restOpts, headers: { ...defaults.headers, ...(restOpts.headers || {}) } };
  if (merged.body && typeof merged.body !== 'string') merged.body = JSON.stringify(merged.body);

  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const res = await fetch(path, { ...merged, signal: ctrl.signal });
    clearTimeout(timer);
    if (res.status === 401) { _redirectToLogin(); throw new Error('Not authenticated'); }
    if (!res.ok) {
      const txt = await res.text().catch(() => res.statusText);
      throw new Error(`${res.status} ${txt}`);
    }
    return res.json();
  } catch (e) {
    clearTimeout(timer);
    if (e.name === 'AbortError') throw new Error('Request timed out — backend may be starting up');
    throw e;
  }
}

// ─── Auth ─────────────────────────────────────────────────────────────────────
function _redirectToLogin() {
  const next = encodeURIComponent(location.href);
  location.href = `login.html?next=${next}`;
}

let _currentUser = null;
function currentUser() { return _currentUser ? _currentUser.username : 'user'; }

async function checkAuth() {
  const token = localStorage.getItem('rs_token');
  if (!token) { _redirectToLogin(); return null; }
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), _API_TIMEOUT_MS);
  try {
    const res = await fetch('/api/auth/me', { headers: { 'X-Auth-Token': token }, signal: ctrl.signal });
    clearTimeout(timer);
    if (!res.ok) throw new Error(res.status);
    const user = await res.json();
    _currentUser = user;
    _renderNavUser(user);
    return user;
  } catch (e) {
    clearTimeout(timer);
    if (e && e.name === 'AbortError') {
      // Backend timeout — keep session, let page show its own error state
      return { _timeout: true };
    }
    localStorage.removeItem('rs_token');
    _redirectToLogin();
    return null;
  }
}

function _renderNavUser(user) {
  const nav = document.getElementById('sidenav');
  if (!nav || document.getElementById('nav-user')) return;
  const roleCls = { admin: 'var(--red)', editor: 'var(--amber)', viewer: 'var(--green)' };
  const color = roleCls[user.role] || 'var(--muted)';
  const userEl = document.createElement('div');
  userEl.id = 'nav-user';
  userEl.style.cssText = 'padding:10px 12px 4px;border-top:1px solid var(--border);flex-shrink:0;';

  userEl.innerHTML = `
    <div style="display:flex;align-items:center;gap:8px;overflow:hidden">
      <div style="width:28px;height:28px;border-radius:50%;background:rgba(0,114,206,.25);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:11px;font-weight:700;color:#fff">${user.username[0].toUpperCase()}</div>
      <div class="nav-label" style="min-width:0;">
        <div style="font-size:12px;font-weight:600;color:#fff;white-space:nowrap;overflow:hidden;text-overflow:ellipsis">${user.username}</div>
        <div style="font-size:10px;color:${color};font-weight:600;text-transform:uppercase;letter-spacing:.4px">${user.role}</div>
      </div>
    </div>`;

  // Insert at the top of nav-footer (above refresh/logout)
  const footer = nav.querySelector('.nav-footer');
  if (footer) {
    footer.insertBefore(userEl, footer.firstChild);
  } else {
    nav.appendChild(userEl);
  }
}

// ─── Theme ────────────────────────────────────────────────────────────────────
function _applyTheme(light) {
  document.documentElement.classList.toggle('light', light);
  const btn = document.getElementById('nav-theme-btn');
  if (!btn) return;
  const icon = btn.querySelector('.nav-icon');
  const lbl  = btn.querySelector('.nav-label');
  if (light) {
    icon.innerHTML = `<svg viewBox="0 0 24 24"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>`;
    if (lbl) lbl.textContent = 'Dark Mode';
  } else {
    icon.innerHTML = `<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="5"/><line x1="12" y1="1" x2="12" y2="3"/><line x1="12" y1="21" x2="12" y2="23"/><line x1="4.22" y1="4.22" x2="5.64" y2="5.64"/><line x1="18.36" y1="18.36" x2="19.78" y2="19.78"/><line x1="1" y1="12" x2="3" y2="12"/><line x1="21" y1="12" x2="23" y2="12"/><line x1="4.22" y1="19.78" x2="5.64" y2="18.36"/><line x1="18.36" y1="5.64" x2="19.78" y2="4.22"/></svg>`;
    if (lbl) lbl.textContent = 'Light Mode';
  }
}

function toggleTheme() {
  const isLight = document.documentElement.classList.toggle('light');
  localStorage.setItem('rs_theme', isLight ? 'light' : 'dark');
  _applyTheme(isLight);
}

function _initTheme() {
  const saved = localStorage.getItem('rs_theme');
  const light = saved !== 'dark';
  _applyTheme(light);
  // Inject theme toggle nav item (once)
  const nav = document.getElementById('sidenav');
  if (!nav || document.getElementById('nav-theme-btn')) return;
  const btn = document.createElement('div');
  btn.id = 'nav-theme-btn';
  btn.className = 'nav-item';
  btn.onclick = toggleTheme;
  btn.innerHTML = `
    <div class="nav-icon"></div>
    <span class="nav-label"></span>`;
  // Append to nav-body (above the footer actions)
  const body = nav.querySelector('.nav-body');
  if (body) {
    body.appendChild(btn);
  } else {
    nav.appendChild(btn);
  }
  _applyTheme(light);
}

// Run theme init immediately so there's no flash of wrong theme
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', _initTheme);
} else {
  _initTheme();
}

function logout() {
  const token = localStorage.getItem('rs_token');
  if (token) fetch('/api/auth/logout', { method: 'POST', headers: { 'X-Auth-Token': token } }).catch(() => {});
  localStorage.removeItem('rs_token');
  localStorage.removeItem('rs_user');
  location.href = 'login.html';
}

// ─── Toast notifications ──────────────────────────────────────────────────────
function showToast(message, type = 'info', duration = 3000) {
  const container = document.getElementById('toast-container');
  if (!container) return;
  const toast = document.createElement('div');
  toast.className = `toast ${type}`;
  const icons = {
    success: `<svg viewBox="0 0 24 24" style="width:15px;height:15px;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round"><polyline points="20 6 9 17 4 12"/></svg>`,
    error:   `<svg viewBox="0 0 24 24" style="width:15px;height:15px;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round;stroke-linejoin:round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>`,
    info:    `<svg viewBox="0 0 24 24" style="width:15px;height:15px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round"><circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/></svg>`
  };
  toast.innerHTML = `
    <span class="toast-icon">${icons[type] || icons.info}</span>
    <span class="toast-msg">${message}</span>
    <button class="toast-close" onclick="dismissToast(this.parentElement)">
      <svg viewBox="0 0 24 24" style="width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2.5;stroke-linecap:round"><line x1="18" y1="6" x2="6" y2="18"/><line x1="6" y1="6" x2="18" y2="18"/></svg>
    </button>`;
  container.appendChild(toast);
  setTimeout(() => dismissToast(toast), duration);
}
function dismissToast(toast) {
  if (!toast || !toast.parentElement) return;
  toast.classList.add('hiding');
  setTimeout(() => toast.remove(), 220);
}

// ─── Formatting helpers ───────────────────────────────────────────────────────
function fmtCpu(cores) {
  if (cores == null) return '—';
  const v = parseFloat(cores);
  if (isNaN(v)) return '—';
  if (v >= 1) return v.toFixed(2).replace(/\.?0+$/, '') + 'c';
  return Math.round(v * 1000) + 'm';
}

function pct(v) {
  if (v == null) return '—';
  const n = parseFloat(v);
  const color = n > 80 ? 'var(--red)' : n > 60 ? 'var(--amber)' : 'var(--green)';
  return `<span style="color:${color}">${n.toFixed(1)}%</span>`;
}

// ─── Status bar ───────────────────────────────────────────────────────────────
function setConnStatus(ok, msg) {
  const dot = document.getElementById('conn-dot');
  const lbl = document.getElementById('conn-status');
  if (!dot || !lbl) return;
  dot.className = 'status-dot ' + (ok ? 'ok' : 'err');
  lbl.textContent = ok ? ('Connected · ' + msg) : ('Error: ' + msg);
}

function updateRowCount(elId, shown, total, singular, plural) {
  const el = document.getElementById(elId);
  if (!el) return;
  el.innerHTML = shown === total
    ? `Showing <strong>${total}</strong> ${total === 1 ? singular : plural}`
    : `Showing <strong>${shown}</strong> of <strong>${total}</strong> ${plural}`;
}

// ─── Config / status bar init ─────────────────────────────────────────────────
async function loadConfig() {
  try {
    const cfg = await api('/api/config');
    setConnStatus(true, cfg.grafana_url || 'backend');
    const aiEl = document.getElementById('ai-badge');
    if (aiEl) {
      aiEl.innerHTML = `<svg viewBox="0 0 24 24" style="width:12px;height:12px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;vertical-align:middle"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg> AI: ${cfg.ai_enabled ? 'GPT-4o mini' : 'disabled'}`;
    }
    const fetchInfo = document.getElementById('fetch-info');
    if (fetchInfo && cfg.last_fetch) {
      fetchInfo.textContent = 'Last fetch: ' + new Date(cfg.last_fetch).toLocaleString();
    }
    const hint = document.getElementById('auto-refresh-hint');
    if (hint && cfg.fetch_interval_hours) {
      hint.textContent = 'Auto-refresh every ' + cfg.fetch_interval_hours + 'h';
      hint.style.display = '';
    }
    return cfg;
  } catch (e) {
    setConnStatus(false, e.message);
    return {};
  }
}

// ─── Sidebar nav ─────────────────────────────────────────────────────────────
function toggleNavGroup(el) {
  const id       = el.id;
  const children = document.getElementById(id + '-children');
  const collapsed = el.classList.toggle('collapsed');
  children.classList.toggle('collapsed', collapsed);
  localStorage.setItem('ng_' + id, collapsed ? '1' : '0');
}
function _initNavGroups() {
  document.querySelectorAll('.nav-group-toggle').forEach(el => {
    const childrenEl = document.getElementById(el.id + '-children');
    if (!childrenEl) return;
    // Expand only when the current page is inside this group; collapse otherwise
    const hasActiveChild = !!childrenEl.querySelector('.active');
    el.classList.toggle('collapsed', !hasActiveChild);
    childrenEl.classList.toggle('collapsed', !hasActiveChild);
  });
}
document.addEventListener('DOMContentLoaded', _initNavGroups);

function toggleSidenav() {
  const nav = document.getElementById('sidenav');
  const collapsed = nav.classList.toggle('collapsed');
  document.body.classList.toggle('nav-collapsed', collapsed);
  localStorage.setItem('rs_nav_collapsed', collapsed ? '1' : '0');
}

// Init nav collapsed state from localStorage
(function _initSidenav() {
  if (localStorage.getItem('rs_nav_collapsed') === '1') {
    document.getElementById('sidenav')?.classList.add('collapsed');
    document.body.classList.add('nav-collapsed');
  }
})();

// ── Client-side data cache (localStorage, 1-hour TTL) ────────────────────
// Uses localStorage so data survives tab closes and app restarts.
// Sync Data busts the cache explicitly. Stale after 1 h automatically.
const _CACHE_TTL = 60 * 60 * 1000;

function cacheSet(key, data) {
  try { localStorage.setItem('rs_' + key, JSON.stringify({ ts: Date.now(), data })); } catch {}
}
function cacheGet(key) {
  try {
    const raw = localStorage.getItem('rs_' + key);
    if (!raw) return null;
    const { ts, data } = JSON.parse(raw);
    if (Date.now() - ts > _CACHE_TTL) { localStorage.removeItem('rs_' + key); return null; }
    return { ts, data };
  } catch { return null; }
}
function cacheBust(key) {
  try { localStorage.removeItem('rs_' + key); } catch {}
}

// ─── Sync / Refresh ───────────────────────────────────────────────────────────
async function refreshAll() {
  const btn = document.getElementById('refresh-btn');
  if (!btn) return;
  const orig = btn.innerHTML;
  const _spin = `<svg viewBox="0 0 24 24" style="width:13px;height:13px;stroke:currentColor;fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;animation:spin .8s linear infinite"><polyline points="23 4 23 10 17 10"/><polyline points="1 20 1 14 7 14"/><path d="M3.51 9a9 9 0 0 1 14.85-3.36L23 10M1 14l4.64 4.36A9 9 0 0 0 20.49 15"/></svg>`;
  btn.innerHTML = `${_spin} Syncing…`;
  btn.disabled = true;
  try {
    cacheBust('nodes'); cacheBust('containers');
    await api('/api/refresh', { method: 'POST' });
    // Poll until sync finishes, then reload with fresh DB data
    let elapsed = 0;
    const _poll = async () => {
      try {
        const s = await api('/api/sync/status');
        if (!s.running) {
          if (s.error) showToast('Sync error: ' + s.error, 'error');
          else showToast('Sync complete. Reloading…', 'success');
          // Clear all page caches so reload fetches fresh data from DB
          ['nodes','containers','history'].forEach(k => localStorage.removeItem('rs_' + k));
          location.reload();
          return;
        }
      } catch {}
      elapsed += 3;
      btn.innerHTML = `${_spin} Syncing… ${elapsed}s`;
      setTimeout(_poll, 3000);
    };
    setTimeout(_poll, 3000);
  } catch (e) {
    showToast('Refresh failed: ' + e.message, 'error');
    btn.innerHTML = orig;
    btn.disabled = false;
  }
}

// ─── Confirm dialog (replaces native confirm()) ───────────────────────────────
let _confirmResolve = null;

function _ensureConfirmModal() {
  if (document.getElementById('rs-confirm-overlay')) return;
  const el = document.createElement('div');
  el.id = 'rs-confirm-overlay';
  el.innerHTML = `
    <div id="rs-confirm-box">
      <div id="rs-confirm-icon"></div>
      <div id="rs-confirm-title"></div>
      <div id="rs-confirm-msg"></div>
      <div id="rs-confirm-btns">
        <button id="rs-confirm-cancel">Cancel</button>
        <button id="rs-confirm-ok">Confirm</button>
      </div>
    </div>`;
  document.body.appendChild(el);
  document.getElementById('rs-confirm-cancel').addEventListener('click', () => _resolveConfirm(false));
  document.getElementById('rs-confirm-ok').addEventListener('click',     () => _resolveConfirm(true));
  el.addEventListener('click', e => { if (e.target === el) _resolveConfirm(false); });

  const style = document.createElement('style');
  style.textContent = `
    #rs-confirm-overlay {
      position:fixed;inset:0;z-index:9999;background:rgba(0,0,0,.6);
      display:flex;align-items:center;justify-content:center;padding:20px;
      opacity:0;pointer-events:none;transition:opacity .18s;
    }
    #rs-confirm-overlay.open { opacity:1;pointer-events:auto; }
    #rs-confirm-box {
      background:var(--surface,#1a1d2e);border:1px solid var(--border,#2e3350);
      border-radius:14px;padding:28px 28px 22px;max-width:400px;width:100%;
      box-shadow:0 24px 64px rgba(0,0,0,.7);
      transform:scale(.94) translateY(6px);transition:transform .18s;text-align:center;
    }
    #rs-confirm-overlay.open #rs-confirm-box { transform:scale(1) translateY(0); }
    #rs-confirm-icon {
      width:48px;height:48px;border-radius:50%;background:rgba(236,96,96,.12);
      margin:0 auto 16px;display:flex;align-items:center;justify-content:center;
    }
    #rs-confirm-icon svg { width:22px;height:22px;stroke:var(--red,#ec6060);fill:none;stroke-width:2;stroke-linecap:round;stroke-linejoin:round; }
    #rs-confirm-title { font-size:15px;font-weight:700;color:var(--text,#e8eaf6);margin-bottom:8px; }
    #rs-confirm-msg   { font-size:13px;color:var(--muted,#7b82a6);line-height:1.5;margin-bottom:22px; }
    #rs-confirm-btns  { display:flex;gap:10px;justify-content:center; }
    #rs-confirm-cancel {
      padding:8px 22px;border-radius:8px;border:1px solid var(--border,#2e3350);
      background:transparent;color:var(--muted,#7b82a6);font-size:13px;cursor:pointer;transition:all .15s;
    }
    #rs-confirm-cancel:hover { border-color:var(--text,#e8eaf6);color:var(--text,#e8eaf6); }
    #rs-confirm-ok {
      padding:8px 22px;border-radius:8px;border:none;
      background:var(--red,#ec6060);color:#fff;font-size:13px;font-weight:600;cursor:pointer;transition:opacity .15s;
    }
    #rs-confirm-ok:hover { opacity:.85; }
  `;
  document.head.appendChild(style);
}

function _resolveConfirm(val) {
  document.getElementById('rs-confirm-overlay').classList.remove('open');
  if (_confirmResolve) { _confirmResolve(val); _confirmResolve = null; }
}

function showConfirm(message, title = 'Are you sure?', confirmLabel = 'Confirm') {
  _ensureConfirmModal();
  document.getElementById('rs-confirm-title').textContent = title;
  document.getElementById('rs-confirm-msg').textContent = message;
  document.getElementById('rs-confirm-ok').textContent = confirmLabel;
  document.getElementById('rs-confirm-icon').innerHTML =
    `<svg viewBox="0 0 24 24"><path d="M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>`;
  document.getElementById('rs-confirm-overlay').classList.add('open');
  return new Promise(res => { _confirmResolve = res; });
}

// ─── Quick Navigation (Ctrl+K / Cmd+K) ───────────────────────────────────────
const _QN_ITEMS = [
  { label: 'Dashboard',    href: 'index.html',        group: '',           icon: '<rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/>' },
  { label: 'Nodes',        href: 'nodes.html',        group: 'Kubernetes', icon: '<rect x="2" y="3" width="20" height="14" rx="2"/><line x1="8" y1="21" x2="16" y2="21"/><line x1="12" y1="17" x2="12" y2="21"/>' },
  { label: 'Containers',   href: 'containers.html',   group: 'Kubernetes', icon: '<path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"/><polyline points="3.27 6.96 12 12.01 20.73 6.96"/><line x1="12" y1="22.08" x2="12" y2="12"/>' },
  { label: 'Disks',        href: 'disks.html',        group: 'Storage',    icon: '<ellipse cx="12" cy="5" rx="9" ry="3"/><path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3"/><path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5"/>' },
  { label: 'Snapshots',    href: 'snapshots.html',    group: 'Storage',    icon: '<path d="M23 19a2 2 0 0 1-2 2H3a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h4l2-3h6l2 3h4a2 2 0 0 1 2 2z"/><circle cx="12" cy="13" r="4"/>' },
  { label: 'Architecture', href: 'architecture.html', group: 'Tools',      icon: '<rect x="9" y="2" width="6" height="4" rx="1"/><rect x="2" y="10" width="6" height="4" rx="1"/><rect x="16" y="10" width="6" height="4" rx="1"/><line x1="12" y1="6" x2="12" y2="10"/><line x1="5" y1="12" x2="5" y2="14"/><line x1="19" y1="12" x2="19" y2="14"/><line x1="8" y1="12" x2="16" y2="12"/>' },
  { label: 'SKU Advisor',  href: 'sku-advisor.html',  group: 'Tools',      icon: '<polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/>' },
  { label: 'Policies',     href: 'policy.html',       group: 'Tools',      icon: '<path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>' },
  { label: 'Alerts',       href: 'alerts.html',       group: 'Insights',   icon: '<path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/>' },
  { label: 'History',      href: 'history.html',      group: 'Insights',   icon: '<polyline points="1 4 1 10 7 10"/><path d="M3.51 15a9 9 0 1 0 .49-4.95"/>' },
  { label: 'How it Works', href: 'faq.html',          group: 'Insights',   icon: '<circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"/><line x1="12" y1="17" x2="12.01" y2="17"/>' },
];

let _qnActive = -1;

function _qnOpen() {
  let el = document.getElementById('qn-overlay');
  if (!el) { _qnBuild(); el = document.getElementById('qn-overlay'); }
  el.classList.add('open');
  const inp = document.getElementById('qn-input');
  inp.value = '';
  _qnRender('');
  setTimeout(() => inp.focus(), 30);
}

function _qnClose() {
  document.getElementById('qn-overlay')?.classList.remove('open');
}

function _qnBuild() {
  const overlay = document.createElement('div');
  overlay.id = 'qn-overlay';
  overlay.onclick = e => { if (e.target === overlay) _qnClose(); };
  overlay.innerHTML = `
    <div class="qn-box">
      <div class="qn-search-row">
        <svg class="qn-search-icon" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
        <input id="qn-input" class="qn-input" placeholder="Go to…" autocomplete="off" spellcheck="false" />
        <kbd class="qn-esc">Esc</kbd>
      </div>
      <div id="qn-list" class="qn-list"></div>
      <div class="qn-footer">
        <span><kbd>↑</kbd><kbd>↓</kbd> navigate</span>
        <span><kbd>↵</kbd> open</span>
        <span><kbd>Esc</kbd> close</span>
      </div>
    </div>`;
  document.body.appendChild(overlay);
  document.getElementById('qn-input').addEventListener('input', e => _qnRender(e.target.value));
  document.getElementById('qn-input').addEventListener('keydown', _qnKeydown);
}

function _qnRender(q) {
  const term = q.trim().toLowerCase();
  const list = document.getElementById('qn-list');
  const curPage = location.pathname.split('/').pop() || 'index.html';
  const filtered = term
    ? _QN_ITEMS.filter(it => it.label.toLowerCase().includes(term) || it.group.toLowerCase().includes(term))
    : _QN_ITEMS;
  _qnActive = filtered.length ? 0 : -1;
  list.innerHTML = filtered.map((it, i) => `
    <a class="qn-item${it.href === curPage ? ' qn-current' : ''}${i === 0 ? ' qn-sel' : ''}" href="${it.href}" data-idx="${i}">
      <div class="qn-item-icon">
        <svg viewBox="0 0 24 24">${it.icon}</svg>
      </div>
      <div class="qn-item-body">
        <span class="qn-item-label">${it.label}</span>
        ${it.group ? `<span class="qn-item-group">${it.group}</span>` : ''}
      </div>
      ${it.href === curPage ? '<span class="qn-badge">current</span>' : ''}
    </a>`).join('');
  list.querySelectorAll('.qn-item').forEach(el => {
    el.addEventListener('mouseenter', () => {
      _qnActive = +el.dataset.idx;
      _qnHighlight();
    });
  });
}

function _qnHighlight() {
  const items = document.querySelectorAll('.qn-item');
  items.forEach((el, i) => el.classList.toggle('qn-sel', i === _qnActive));
  const sel = items[_qnActive];
  if (sel) sel.scrollIntoView({ block: 'nearest' });
}

function _qnKeydown(e) {
  const items = document.querySelectorAll('.qn-item');
  if (e.key === 'ArrowDown')  { e.preventDefault(); _qnActive = Math.min(_qnActive + 1, items.length - 1); _qnHighlight(); }
  else if (e.key === 'ArrowUp') { e.preventDefault(); _qnActive = Math.max(_qnActive - 1, 0); _qnHighlight(); }
  else if (e.key === 'Enter') { e.preventDefault(); if (items[_qnActive]) { items[_qnActive].click(); _qnClose(); } }
  else if (e.key === 'Escape') { _qnClose(); }
}

document.addEventListener('keydown', e => {
  if ((e.ctrlKey || e.metaKey) && e.key === 'k') { e.preventDefault(); _qnOpen(); }
});
