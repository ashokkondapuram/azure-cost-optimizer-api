"""
WebJob — Cluster Discovery (Daily)
===================================
Schedule : daily  (App_Data/jobs/triggered/webjob_cluster_discovery/settings.job)
Local run : python webjob_cluster_discovery.py [--force]

Responsibilities:
  1. List all resource groups in the subscription
  2. For each RG, find all AKS clusters
  3. Build cluster registry with location mappings
  4. Store in database so webjob2 can do fast lookups
"""

import json
import sys
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from sqlalchemy import delete
from database import SessionLocal, DATA_WRITE_LOCK, init_db
from azure_auth import _get_azure_token, _get_subscription_ids, _load_azure_db_creds
from models import ClusterRegistry, WebjobState


def _list_resource_groups(subscription_id: str, access_token: str) -> list[dict]:
    """List all resource groups in a subscription."""
    url = f"https://management.azure.com/subscriptions/{subscription_id}/resourcegroups?api-version=2021-04-01"
    req = urllib.request.Request(url, method="GET")
    req.add_header("Authorization", f"Bearer {access_token}")

    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
            rgs = data.get("value", [])
            return [{"name": rg.get("name"), "location": rg.get("location")} for rg in rgs]
    except Exception as e:
        print(f"[cluster-discovery] Failed to list RGs: {e}")
        return []


def _list_clusters_in_rg(subscription_id: str, rg_name: str, access_token: str) -> list[dict]:
    """List AKS clusters in a resource group."""
    url = (f"https://management.azure.com/subscriptions/{subscription_id}"
           f"/resourceGroups/{rg_name}"
           f"/providers/Microsoft.ContainerService/managedClusters"
           f"?api-version=2024-02-01")
    req = urllib.request.Request(url, method="GET")
    req.add_header("Authorization", f"Bearer {access_token}")

    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
            clusters = data.get("value", [])
            return [
                {
                    "name": c.get("name"),
                    "location": c.get("location"),
                    "cluster_id": c.get("id"),
                }
                for c in clusters
            ]
    except Exception as e:
        print(f"[cluster-discovery] Failed to list clusters in {rg_name}: {e}")
        return []


def run(force: bool = False):
    init_db()
    db = SessionLocal()

    try:
        print(f"[cluster-discovery] Starting cluster discovery — {datetime.now(timezone.utc).isoformat()}")

        # Load Azure config and get token
        _load_azure_db_creds()
        access_token = _get_azure_token()
        if not access_token:
            print("[cluster-discovery] ERROR: Failed to get access token")
            return

        subscription_ids = _get_subscription_ids(access_token)
        if not subscription_ids:
            print("[cluster-discovery] ERROR: No subscription IDs found")
            return

        print(f"[cluster-discovery] Discovering clusters in {len(subscription_ids)} subscription(s)…")

        # Discover all clusters
        all_clusters = []
        for sub_id in subscription_ids:
            print(f"[cluster-discovery] Scanning subscription {sub_id[:8]}...")

            # List RGs
            rgs = _list_resource_groups(sub_id, access_token)
            print(f"[cluster-discovery]   Found {len(rgs)} resource group(s)")

            # For each RG, list clusters
            for rg in rgs:
                rg_name = rg.get("name", "")
                clusters = _list_clusters_in_rg(sub_id, rg_name, access_token)
                for cluster in clusters:
                    all_clusters.append({
                        "subscription_id": sub_id,
                        "resource_group": rg_name,
                        "cluster_name": cluster.get("name"),
                        "location": cluster.get("location"),
                        "cluster_id": cluster.get("cluster_id"),
                    })
                    print(f"[cluster-discovery]     Found cluster: {cluster.get('name')} → {cluster.get('location')}")

        print(f"[cluster-discovery] Discovered {len(all_clusters)} total clusters")

        # Upsert to registry with write lock
        with DATA_WRITE_LOCK:
            # Clear old registry
            db.execute(delete(ClusterRegistry))
            db.commit()

            # Insert all clusters
            if all_clusters:
                db.bulk_insert_mappings(ClusterRegistry, all_clusters)
                db.commit()
                print(f"[cluster-discovery] ✓ DB write done: {len(all_clusters)} clusters upserted to registry")

        # Update webjob state
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob_cluster_discovery").first()
        if not row:
            row = WebjobState(job_name="webjob_cluster_discovery")
            db.add(row)
        row.last_run_at = datetime.now(timezone.utc)
        row.last_run_ok = True
        row.context = {"clusters_discovered": len(all_clusters)}
        db.commit()
        print(f"[cluster-discovery] ✓ DB write done: Collector state updated")
        print("[cluster-discovery] Done")

    except Exception as e:
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob_cluster_discovery").first()
        if row:
            row.last_run_ok = False
            row.last_error = str(e)
            db.commit()
            print(f"[cluster-discovery] ✓ DB write done: Error recorded")
        print(f"[cluster-discovery] ERROR: {e}")
        raise

    finally:
        db.close()


if __name__ == "__main__":
    force = "--force" in sys.argv
    run(force=force)
