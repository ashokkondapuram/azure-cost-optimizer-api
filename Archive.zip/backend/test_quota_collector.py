"""
Test suite for quota collector functionality
Tests upsert logic, bulk operations, and data override behavior
"""

import sys
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).parent))

from database import SessionLocal, init_db
from models import Quota
from sqlalchemy import delete


def test_quota_upsert_override():
    """Test that new quota data overrides old data via unique constraint."""
    init_db()
    db = SessionLocal()

    try:
        # Clean up test data
        db.execute(delete(Quota).where(Quota.subscription_id == "test-sub-1"))
        db.commit()

        now1 = datetime(2026, 5, 28, 10, 0, 0, tzinfo=timezone.utc)
        now2 = datetime(2026, 5, 28, 11, 0, 0, tzinfo=timezone.utc)

        # Batch 1: Initial insert
        batch1 = [
            {
                "subscription_id": "test-sub-1",
                "region": "eastus",
                "resource_type": "standardDSv5Family",
                "limit": 100,
                "current_usage": 25,
                "available": 75,
                "unit": "cores",
                "fetched_at": now1,
            },
            {
                "subscription_id": "test-sub-1",
                "region": "eastus",
                "resource_type": "standardESv5Family",
                "limit": 50,
                "current_usage": 10,
                "available": 40,
                "unit": "cores",
                "fetched_at": now1,
            },
        ]
        db.bulk_insert_mappings(Quota, batch1)
        db.commit()

        # Verify initial insert
        count1 = db.query(Quota).filter(
            Quota.subscription_id == "test-sub-1",
            Quota.region == "eastus"
        ).count()
        assert count1 == 2, f"Expected 2 quotas, got {count1}"
        print("✓ Initial insert: 2 quotas")

        # Batch 2: Override (same sub/region/type, different values)
        db.execute(delete(Quota).where(Quota.subscription_id == "test-sub-1"))
        db.commit()

        batch2 = [
            {
                "subscription_id": "test-sub-1",
                "region": "eastus",
                "resource_type": "standardDSv5Family",
                "limit": 100,
                "current_usage": 50,  # Changed from 25 to 50
                "available": 50,       # Changed from 75 to 50
                "unit": "cores",
                "fetched_at": now2,    # New timestamp
            },
            {
                "subscription_id": "test-sub-1",
                "region": "westus",
                "resource_type": "standardDSv5Family",
                "limit": 80,
                "current_usage": 15,
                "available": 65,
                "unit": "cores",
                "fetched_at": now2,
            },
        ]
        db.bulk_insert_mappings(Quota, batch2)
        db.commit()

        # Verify override behavior
        count2 = db.query(Quota).filter(Quota.subscription_id == "test-sub-1").count()
        assert count2 == 2, f"Expected 2 quotas after override, got {count2}"

        # Check that eastus/standardDSv5 was updated
        quota = db.query(Quota).filter(
            Quota.subscription_id == "test-sub-1",
            Quota.region == "eastus",
            Quota.resource_type == "standardDSv5Family"
        ).first()
        assert quota is not None, "Quota not found"
        assert quota.current_usage == 50, f"Expected usage 50, got {quota.current_usage}"
        assert quota.available == 50, f"Expected available 50, got {quota.available}"
        # Compare datetimes without timezone (SQLite stores as naive datetime)
        stored_dt = quota.fetched_at.replace(tzinfo=None) if quota.fetched_at.tzinfo else quota.fetched_at
        expected_dt = now2.replace(tzinfo=None) if now2.tzinfo else now2
        assert stored_dt == expected_dt, f"Expected timestamp {expected_dt}, got {stored_dt}"
        print("✓ Override works: usage updated to 50, timestamp updated")

        # Verify westus was added
        west_count = db.query(Quota).filter(
            Quota.subscription_id == "test-sub-1",
            Quota.region == "westus"
        ).count()
        assert west_count == 1, f"Expected 1 westus quota, got {west_count}"
        print("✓ New region added: westus")

        # Clean up
        db.execute(delete(Quota).where(Quota.subscription_id == "test-sub-1"))
        db.commit()

    finally:
        db.close()


def test_quota_bulk_operations():
    """Test that bulk operations handle large batches efficiently."""
    init_db()
    db = SessionLocal()

    try:
        # Clean up
        db.execute(delete(Quota).where(Quota.subscription_id == "test-bulk"))
        db.commit()

        now = datetime.now(timezone.utc)
        regions = ["eastus", "westus", "centralus"]
        types = ["standardDSv5Family", "standardESv5Family", "standardFSv2Family"]

        # Generate 9 quota entries (3 regions × 3 types)
        batch = []
        for region in regions:
            for rtype in types:
                batch.append({
                    "subscription_id": "test-bulk",
                    "region": region,
                    "resource_type": rtype,
                    "limit": 100,
                    "current_usage": 50,
                    "available": 50,
                    "unit": "cores",
                    "fetched_at": now,
                })

        db.bulk_insert_mappings(Quota, batch)
        db.commit()

        total = db.query(Quota).filter(Quota.subscription_id == "test-bulk").count()
        assert total == 9, f"Expected 9 quotas, got {total}"
        print(f"✓ Bulk insert: {total} quotas in single batch")

        # Clean up
        db.execute(delete(Quota).where(Quota.subscription_id == "test-bulk"))
        db.commit()

    finally:
        db.close()


def test_quota_availability_calculation():
    """Test that available field correctly reflects limit - usage."""
    init_db()
    db = SessionLocal()

    try:
        db.execute(delete(Quota).where(Quota.subscription_id == "test-calc"))
        db.commit()

        now = datetime.now(timezone.utc)
        test_cases = [
            (100, 0),    # No usage
            (100, 50),   # Half used
            (100, 100),  # Full capacity
            (100, 120),  # Over capacity (should result in 0 available via max(0, ...))
        ]

        for limit, usage in test_cases:
            db.bulk_insert_mappings(Quota, [{
                "subscription_id": "test-calc",
                "region": "eastus",
                "resource_type": f"type-{limit}-{usage}",
                "limit": limit,
                "current_usage": usage,
                "available": max(0, limit - usage),
                "unit": "cores",
                "fetched_at": now,
            }])

        db.commit()

        for limit, usage in test_cases:
            quota = db.query(Quota).filter(
                Quota.subscription_id == "test-calc",
                Quota.resource_type == f"type-{limit}-{usage}"
            ).first()
            expected_available = max(0, limit - usage)
            assert quota.available == expected_available, \
                f"For limit={limit}, usage={usage}: expected available={expected_available}, got {quota.available}"
            print(f"✓ Calculation OK: limit={limit}, usage={usage} → available={quota.available}")

        db.execute(delete(Quota).where(Quota.subscription_id == "test-calc"))
        db.commit()

    finally:
        db.close()


if __name__ == "__main__":
    print("=" * 70)
    print("QUOTA COLLECTOR TESTS")
    print("=" * 70)

    try:
        test_quota_upsert_override()
        print()
        test_quota_bulk_operations()
        print()
        test_quota_availability_calculation()
        print()
        print("=" * 70)
        print("✅ ALL TESTS PASSED (3/3)")
        print("=" * 70)
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
