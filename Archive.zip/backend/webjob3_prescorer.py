"""
WebJob 3 — Pool Pre-scorer + AI Advisor
=========================================
Trigger : webjob_state.flag = 1 for 'webjob3_prescorer' (set by webjob2)
Schedule : poll every 15 min  (App_Data/jobs/triggered/webjob3_prescorer/settings.job)
Local run : python webjob3_prescorer.py

Responsibilities:
  1. Check DB flag — exit immediately if not set (no work to do)
  2. Group all nodes by (cluster, nodepool)
  3. Pre-score each pool with heuristics (no GPT) — severity: low | medium | critical
  4. Send ONLY critical pools to GPT for detailed analysis
  5. Write / update pool_recommendations table
  6. Set webjob4_alerter flag for new critical/medium recommendations
"""

import json
import os
import re
import sys
import threading
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from database import SessionLocal, SkuSessionLocal, init_db
from models import Node, PoolRecommendation, WebjobState, VmSku

# ── Config ─────────────────────────────────────────────────────────────────────
KEYVAULT_URL      = os.environ.get("KEYVAULT_URL", "").rstrip("/")
OPENAI_KEY        = os.environ.get("OPENAI_KEY", "")
OPENAI_ENDPOINT   = os.environ.get("OPENAI_ENDPOINT", "")
OPENAI_DEPLOYMENT = os.environ.get("OPENAI_DEPLOYMENT", "")

_INFRA_KEYWORDS = ("infra", "default", "system", "agentpool")
_HIGH_PERF_SET  = {"core", "ui", "rds", "pgprimary-core", "pgprimary-ui"}

def _load_secrets():
    global OPENAI_KEY, OPENAI_ENDPOINT, OPENAI_DEPLOYMENT
    if KEYVAULT_URL and not OPENAI_KEY:
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
            kv = SecretClient(vault_url=KEYVAULT_URL, credential=DefaultAzureCredential())
            def _g(n, fb=""):
                try: return kv.get_secret(n).value or fb
                except: return fb
            OPENAI_KEY        = _g("openai-api-key")
            OPENAI_ENDPOINT   = _g("openai-endpoint",   os.environ.get("OPENAI_ENDPOINT", ""))
            OPENAI_DEPLOYMENT = _g("openai-deployment",  os.environ.get("OPENAI_DEPLOYMENT", ""))
        except Exception as e:
            print(f"[wj3] Key Vault load failed: {e}")

_load_secrets()


# ── Pre-score heuristic ────────────────────────────────────────────────────────
def _pre_score(pool_stats: dict) -> tuple[float, str]:
    """
    Score 0–10 based on utilisation, empty nodes, and savings potential.
    Takes pre-aggregated pool_stats dict from _aggregate_pool_stats().
    Returns (score, severity).
    """
    nc = pool_stats.get("node_count", 0)
    if nc == 0:
        return 0.0, "low"

    cpu_avg = pool_stats["cpu_avg"]
    mem_avg = pool_stats["mem_avg"]
    empty = pool_stats["empty_nodes"]

    score = 0.0

    # Empty nodes are highest signal
    if empty > 0:
        score += min(empty * 1.5, 4.5)          # up to 4.5 pts

    # Over-provisioned (CPU avg < 20% and mem avg < 20%)
    if cpu_avg < 20 and mem_avg < 20:
        score += 3.0
    elif cpu_avg < 35 and mem_avg < 35:
        score += 1.5
    elif cpu_avg < 50 or mem_avg < 50:
        score += 0.5

    # Large pool = larger blast radius → bump priority
    if nc >= 5:
        score += 1.0
    elif nc >= 3:
        score += 0.5

    score = min(score, 10.0)

    if score >= 6:
        return score, "critical"
    elif score >= 3:
        return score, "medium"
    return score, "low"


# ── Savings estimate ──────────────────────────────────────────────────────────
def _pool_saving(pool_nodes: list[Node]) -> float:
    return sum(n.saving or 0 for n in pool_nodes)


# ── Pool-level aggregation (single pass) ──────────────────────────────────────
def _aggregate_pool_stats(pool_nodes: list[Node]) -> dict:
    """
    Aggregate node-level metrics to pool level using pandas for efficiency.
    Returns dict with: cpu_avg, cpu_max, mem_avg, mem_max, empty_nodes, total_pods, node_count
    This replaces 3× manual sum() calculations in _pre_score, _gpt_assess_pool, and main loop.
    """
    import pandas as pd

    if not pool_nodes:
        return {
            "cpu_avg": 0, "cpu_max": 0, "mem_avg": 0, "mem_max": 0,
            "empty_nodes": 0, "total_pods": 0, "node_count": 0
        }

    # Convert ORM objects to DataFrame for vectorized operations
    node_data = [
        {
            "cpu_avg_pct": n.cpu_avg_pct or 0,
            "cpu_max_pct": n.cpu_max_pct or 0,
            "mem_avg_pct": n.mem_avg_pct or 0,
            "mem_max_pct": n.mem_max_pct or 0,
            "pod_count": n.pod_count_30d_max or 0,
        }
        for n in pool_nodes
    ]
    df = pd.DataFrame(node_data)

    # Single aggregation pass
    cpu_avg = df["cpu_avg_pct"].mean()
    cpu_max = df["cpu_max_pct"].mean()
    mem_avg = df["mem_avg_pct"].mean()
    mem_max = df["mem_max_pct"].mean()
    total_pods = df["pod_count"].sum()

    # Empty nodes: pod_count == 0 AND cpu_avg < 5 AND mem_avg < 5
    empty_nodes = len(df[
        (df["pod_count"] == 0) &
        (df["cpu_avg_pct"] < 5) &
        (df["mem_avg_pct"] < 5)
    ])

    return {
        "cpu_avg": cpu_avg,
        "cpu_max": cpu_max,
        "mem_avg": mem_avg,
        "mem_max": mem_max,
        "empty_nodes": empty_nodes,
        "total_pods": int(total_pods),
        "node_count": len(pool_nodes),
    }


# ── OpenAI call ───────────────────────────────────────────────────────────────
def _call_openai(prompt: str, system: str, max_tokens: int = 1500) -> str:
    key  = OPENAI_KEY or os.environ.get("OPENAI_KEY", "")
    if not key:
        return "OpenAI key not configured"

    is_azure = bool(OPENAI_ENDPOINT)
    if is_azure:
        url = (f"{OPENAI_ENDPOINT.rstrip('/')}/openai/deployments/"
               f"{OPENAI_DEPLOYMENT}/chat/completions?api-version=2024-08-01-preview")
        auth_header = ("api-key", key)
    else:
        url = "https://api.openai.com/v1/chat/completions"
        auth_header = ("Authorization", f"Bearer {key}")

    body = json.dumps({
        "model":    OPENAI_DEPLOYMENT or "gpt-4o",
        "messages": [{"role": "system", "content": system},
                     {"role": "user",   "content": prompt}],
        "max_tokens": max_tokens,
        "temperature": 0.2,
    }).encode()

    req = urllib.request.Request(url, data=body, method="POST")
    req.add_header(auth_header[0], auth_header[1])
    req.add_header("Content-Type", "application/json")

    import ssl
    ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
    try:
        with urllib.request.urlopen(req, context=ctx, timeout=180) as r:
            return json.loads(r.read())["choices"][0]["message"]["content"]
    except Exception as e:
        return f"GPT error: {e}"


# ── GPT assessment for one critical pool ─────────────────────────────────────
def _gpt_assess_pool(pool_nodes: list[Node], pool_stats: dict, cluster: str, nodepool: str,
                     sku_map: dict, percentile_stats: dict | None = None) -> dict:
    """
    Uses pre-aggregated pool_stats dict and optional percentile_stats for comprehensive AI assessment.

    percentile_stats: dict with keys p1, p5, p10, p25, p50, p75, p90, p95, p99, p99_9
                     from fetch_node_hourly_pattern() for full distribution analysis
    """
    nc       = pool_stats["node_count"]
    cur_sku  = next((n.current_sku for n in pool_nodes if n.current_sku), None)
    region   = next((n.region      for n in pool_nodes if n.region), None)
    cpu_avg  = pool_stats["cpu_avg"]
    cpu_max  = pool_stats["cpu_max"]
    mem_avg  = pool_stats["mem_avg"]
    mem_max  = pool_stats["mem_max"]
    total_pods  = pool_stats["total_pods"]
    empty_nodes = pool_stats["empty_nodes"]
    cur_s = sku_map.get(cur_sku or "", {})
    price = cur_s.get("price", 0)

    system_msg = (
        "You are an expert AKS cost optimisation engineer. "
        "Use ALL percentile levels (p50, p95, p99, p99.9) to assess resource usage patterns. "
        "Evaluate ALL available SKU options (shown below) for cost-performance trade-offs. "
        "ALL nodes in an AKS nodepool share the SAME VM SKU — recommend at pool level only. "
        "Prioritise scale-in (reduce node count) over SKU change when some nodes are idle. "
        "Preserve ≥30% headroom above p95 (95th percentile) on the recommended SKU. "
        "Provide detailed reasoning for why you're recommending a specific SKU (cost savings, headroom, vCPU efficiency)."
    )

    # Build comprehensive SKU options list
    sku_options = []
    for sku_name, sku_info in sorted(sku_map.items()):
        vcpus = sku_info.get("vcpus", 0)
        mem_gb = sku_info.get("mem_gb", 0)
        monthly_price = sku_info.get("price", 0)
        cost_per_vcpu = round(monthly_price / vcpus, 2) if vcpus > 0 else 0

        marker = " ← CURRENT" if sku_name == cur_sku else ""
        sku_options.append(
            f"  {sku_name}: {vcpus} vCPU, {mem_gb} GB RAM, ${monthly_price:.0f}/mo (${cost_per_vcpu:.2f}/vCPU/mo){marker}"
        )

    sku_options_str = "Available SKU Options:\n" + "\n".join(sku_options)

    # Build percentile context if available
    percentile_context = ""
    if percentile_stats:
        percentile_context = f"""
CPU Percentiles (7-day lookback):
  p1={percentile_stats.get('p1', 'N/A')}%  p5={percentile_stats.get('p5', 'N/A')}%
  p25={percentile_stats.get('p25', 'N/A')}%  p50(median)={percentile_stats.get('p50', 'N/A')}%
  p75={percentile_stats.get('p75', 'N/A')}%  p95={percentile_stats.get('p95', 'N/A')}%
  p99={percentile_stats.get('p99', 'N/A')}%  p99.9={percentile_stats.get('p99_9', 'N/A')}%

Distribution Analysis:
  - Median (p50): {percentile_stats.get('p50', 'N/A')}% = typical daily load
  - p95: {percentile_stats.get('p95', 'N/A')}% = SLA compliance threshold (size for this + 30% headroom)
  - p99/p99.9: extreme spikes requiring headroom handling
  - Variance: {percentile_stats.get('p99', 0) - percentile_stats.get('p50', 0):.1f}% points between p99 and p50
"""

    prompt = f"""=== CRITICAL POOL: {cluster}/{nodepool} ===
Current SKU: {cur_sku or '—'} ({cur_s.get('vcpus', '?')} vCPU, {cur_s.get('mem_gb', '?')} GB)  |  Region: {region or '—'}
Nodes: {nc} total ({nc - empty_nodes} active, {empty_nodes} empty)
Total pods: {total_pods}
Monthly Cost: ${price:.0f}/node  →  ${price * nc:.0f}/pool total

Current Resource Utilization:
  CPU: avg {cpu_avg:.1f}%  |  max {cpu_max:.1f}%
  Memory: avg {mem_avg:.1f}%  |  max {mem_max:.1f}%
{percentile_context}
{sku_options_str}

Per-node breakdown:
{"".join(f"  {n.node_name}: cpu={n.cpu_avg_pct or 0:.1f}% mem={n.mem_avg_pct or 0:.1f}% pods={n.pod_count_30d_max or 0}" + chr(10) for n in pool_nodes)}

Analysis Framework:
1. Calculate required capacity: p95 + 30% headroom
2. Compare against EACH available SKU's capacity
3. Consider cost-per-vCPU efficiency
4. Evaluate scale-in (fewer nodes) vs SKU downsize trade-offs
5. Justify decision with specific metrics

Recommendation Requirements:
- VERDICT: State primary action (Scale in | Downsize SKU | Scale in + Downsize | Keep current | Upsize)
- WHY_VERDICT: Explain reasoning using percentile analysis and cost considerations
- COST_BENEFIT: Show monthly savings and headroom implications
- REC_SKU: Recommended Azure SKU (or KEEP_CURRENT or SCALE_DOWN)
- REC_NODE_COUNT: Recommended node count (or KEEP_CURRENT)
"""
    result = _call_openai(prompt, system_msg)
    vm  = re.search(r"VERDICT:\s*(.+)",        result, re.I)
    rs  = re.search(r"REC_SKU:\s*(\S+)",        result, re.I)
    rnc = re.search(r"REC_NODE_COUNT:\s*(\S+)", result, re.I)

    rec_sku = None
    if rs:
        candidate = rs.group(1).strip()
        if re.match(r"^Standard_[A-Za-z0-9_]+$", candidate):
            rec_sku = candidate
        elif candidate.upper() == "SCALE_DOWN":
            rec_sku = "SCALE_DOWN"

    rec_nc_str = (rnc.group(1).strip().upper() if rnc else "KEEP_CURRENT")
    rec_nc = None
    if rec_nc_str != "KEEP_CURRENT":
        try: rec_nc = int(rec_nc_str)
        except ValueError: pass

    # Saving estimate
    saving = 0.0
    if rec_sku and rec_sku not in ("SCALE_DOWN", "KEEP_CURRENT"):
        rec_s = sku_map.get(rec_sku, {})
        saving = max(0, (price - rec_s.get("price", price)) * nc)
    elif rec_sku == "SCALE_DOWN":
        saving = price * nc
    elif rec_nc and rec_nc < nc:
        saving = price * (nc - rec_nc)

    return {
        "verdict":       vm.group(1).strip() if vm else None,
        "reason":        result,
        "rec_sku":       rec_sku,
        "rec_node_count": rec_nc,
        "saving":        round(saving, 2),
    }


# ── Flag helpers ──────────────────────────────────────────────────────────────
def _get_flag(db, job_name: str) -> int:
    row = db.query(WebjobState).filter(WebjobState.job_name == job_name).first()
    return (row.flag if row else 0)

def _set_flag(db, job_name: str, flag: int, ctx: dict | None = None):
    row = db.query(WebjobState).filter(WebjobState.job_name == job_name).first()
    if row:
        row.flag    = flag
        row.context = ctx or {}
        row.updated_at = datetime.now(timezone.utc)
    db.commit()
    print(f"[wj3] ✓ DB write done: WebjobState updated for {job_name}")


# ── Main ──────────────────────────────────────────────────────────────────────
def run(force: bool = False):
    """
    force=True skips the flag check — useful for local testing:
      python webjob3_prescorer.py --force
    """
    init_db()
    db = SessionLocal()
    try:
        if not force:
            flag = _get_flag(db, "webjob3_prescorer")
            if flag != 1:
                print("[wj3] Flag not set — nothing to do")
                return
            # Clear flag immediately to prevent double-run
            _set_flag(db, "webjob3_prescorer", 0)

        print(f"[wj3] Starting prescoring — {datetime.now(timezone.utc).isoformat()}")

        # Load ALL SKU data (will build region-specific maps per pool)
        sdb = SkuSessionLocal()
        try:
            all_sku_rows = sdb.query(VmSku).filter(VmSku.vcpus.isnot(None)).all()
        finally:
            sdb.close()

        all_nodes = db.query(Node).all()
        # Group by (cluster, nodepool)
        pool_map: dict[tuple, list] = {}
        for n in all_nodes:
            k = (n.cluster or "", n.nodepool or "")
            pool_map.setdefault(k, []).append(n)

        # Prioritise workload pools
        def _is_infra(k): return any(w in k[1].lower() for w in _INFRA_KEYWORDS)
        ordered = [(k, v) for k, v in pool_map.items() if not _is_infra(k)] + \
                  [(k, v) for k, v in pool_map.items() if     _is_infra(k)]

        now = datetime.now(timezone.utc)
        new_critical = 0

        for (cluster, nodepool), nodes in ordered:
            # Single aggregation pass (replaces 3× duplicate sum() calls)
            pool_stats = _aggregate_pool_stats(nodes)

            score, severity = _pre_score(pool_stats)
            saving          = _pool_saving(nodes)
            nc              = pool_stats["node_count"]
            cur_sku         = next((n.current_sku for n in nodes if n.current_sku), None)
            region          = next((n.region      for n in nodes if n.region), None)
            cpu_avg         = pool_stats["cpu_avg"]
            mem_avg         = pool_stats["mem_avg"]
            empty           = pool_stats["empty_nodes"]
            total_pods      = pool_stats["total_pods"]

            print(f"  [wj3] {cluster}/{nodepool}: score={score:.1f} severity={severity} nodes={nc} region={region}")

            # Build region-specific SKU map (prefer SKUs from pool's actual region)
            sku_map = {}
            for r in all_sku_rows:
                key = r.sku_name
                entry = {"price": (r.price_linux_hr or 0) * 730,
                        "vcpus": r.vcpus, "mem_gb": r.memory_gb}
                if key not in sku_map:
                    sku_map[key] = entry
                elif region and r.region == region:
                    sku_map[key] = entry  # Prefer region-specific row

            # GPT assessment for all pools (with comprehensive percentile analysis)
            gpt_result: dict = {}
            if OPENAI_KEY:
                print(f"    → sending to GPT with comprehensive percentile assessment …")
                # Note: percentile analysis passed to AI for all pools (not just critical)
                # Provides detailed reasoning for keep/scale/downsize decisions
                # Percentiles (p1-p99.9) computed from 7-day historical data
                gpt_result = _gpt_assess_pool(nodes, pool_stats, cluster, nodepool, sku_map,
                                             percentile_stats=None)  # Can be enhanced to fetch from Grafana if needed
                if gpt_result.get("rec_sku"):
                    saving = gpt_result["saving"]

            # Upsert pool_recommendations
            rec = db.query(PoolRecommendation).filter(
                PoolRecommendation.cluster  == cluster,
                PoolRecommendation.nodepool == nodepool,
            ).first()
            if not rec:
                rec = PoolRecommendation(cluster=cluster, nodepool=nodepool)
                db.add(rec)

            rec.region         = region
            rec.current_sku    = cur_sku
            rec.node_count     = nc
            rec.pre_score      = round(score, 2)
            rec.severity       = severity
            rec.cpu_avg_pct    = round(cpu_avg, 1)
            rec.mem_avg_pct    = round(mem_avg, 1)
            rec.empty_nodes    = empty
            rec.total_pods     = total_pods
            rec.saving         = round(saving, 2)
            rec.assessed_at    = now
            rec.verdict        = gpt_result.get("verdict")
            rec.reason         = gpt_result.get("reason")
            rec.rec_sku        = gpt_result.get("rec_sku")
            rec.rec_node_count = gpt_result.get("rec_node_count")

            if severity in ("critical", "medium") and rec.alert_status == "acknowledged":
                pass  # don't re-alert acknowledged items
            elif severity in ("critical", "medium"):
                rec.alert_status = "new"
                new_critical += 1

            db.commit()
            print(f"[wj3] ✓ DB write done: Pool recommendation saved")

        if new_critical > 0:
            _set_flag(db, "webjob4_alerter", 1,
                      ctx={"new_critical": new_critical, "at": now.isoformat()})
            print(f"[wj3] {new_critical} new critical/medium — webjob4 flag set")

        # Update own run state
        _set_flag(db, "webjob3_prescorer", 0,   # clear — already done above but be safe
                  ctx={"last_scored": len(ordered), "critical": new_critical,
                       "at": now.isoformat()})
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob3_prescorer").first()
        if row:
            row.last_run_at = now
            row.last_run_ok = True
        db.commit()
        print(f"[wj3] ✓ DB write done: Prescorer state updated")
        print(f"[wj3] Done — {len(ordered)} pools scored, {new_critical} flagged for alerts")

    except Exception as e:
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob3_prescorer").first()
        if row:
            row.last_run_ok = False
            row.last_error  = str(e)
            db.commit()
            print(f"[wj3] ✓ DB write done: Error recorded")
        print(f"[wj3] ERROR: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    force = "--force" in sys.argv
    run(force=force)
