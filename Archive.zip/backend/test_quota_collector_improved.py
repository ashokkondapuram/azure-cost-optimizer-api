"""
Test suite for improved quota collector with edge case handling
Tests parsing of various Azure API response formats
"""

import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))


def test_quota_parsing_with_various_formats():
    """Test quota parsing with different API response formats."""

    # Simulate the _fetch_quota_for_region parsing logic
    def parse_quota_item(usage, debug=False):
        """Extract and validate quota item from Azure API response."""
        # Safe extraction with fallbacks
        name_obj = usage.get("name", {})
        if not isinstance(name_obj, dict):
            if debug:
                print(f"    [skip] Invalid name object: {type(name_obj)}")
            return None

        resource_type = name_obj.get("value", "")
        localized_name = name_obj.get("localizedValue", resource_type)
        limit = usage.get("limit")
        current = usage.get("currentValue")
        unit = usage.get("unit", "count")

        # Skip if no resource type
        if not resource_type:
            if debug:
                print(f"    [skip] Empty resource_type: {localized_name}")
            return None

        # Skip if both limit and current are None/0
        if limit is None and current is None:
            if debug:
                print(f"    [skip] No limit/usage: {resource_type}")
            return None

        # Convert to int, handling None
        try:
            limit_int = int(limit) if limit is not None else 0
            current_int = int(current) if current is not None else 0
        except (ValueError, TypeError):
            if debug:
                print(f"    [skip] Invalid numbers: {resource_type} limit={limit} current={current}")
            return None

        return {
            "resource_type": resource_type,
            "limit": limit_int,
            "current_usage": current_int,
            "unit": unit,
        }

    # Test case 1: Normal quota format
    print("Test 1: Normal quota format")
    normal = {
        "name": {
            "value": "standardDSv5Family",
            "localizedValue": "Standard DSv5 Family vCPUs"
        },
        "limit": 100,
        "currentValue": 45,
        "unit": "count"
    }
    result = parse_quota_item(normal, debug=True)
    assert result is not None, "Normal format should parse"
    assert result["resource_type"] == "standardDSv5Family"
    assert result["limit"] == 100
    assert result["current_usage"] == 45
    print("✓ Normal format parsed correctly\n")

    # Test case 2: Missing currentValue (None)
    print("Test 2: Missing currentValue")
    missing_current = {
        "name": {
            "value": "standardDSv4Family",
            "localizedValue": "Standard DSv4 Family vCPUs"
        },
        "limit": 200,
        "currentValue": None,
        "unit": "count"
    }
    result = parse_quota_item(missing_current, debug=True)
    assert result is not None, "Missing currentValue should handle gracefully"
    assert result["current_usage"] == 0
    print("✓ Missing currentValue defaulted to 0\n")

    # Test case 3: Zero values (should still include)
    print("Test 3: Zero values")
    zero_values = {
        "name": {
            "value": "standardESv5Family",
            "localizedValue": "Standard ESv5 Family vCPUs"
        },
        "limit": 0,
        "currentValue": 0,
        "unit": "count"
    }
    result = parse_quota_item(zero_values, debug=True)
    # Should be skipped because both are 0 and no keywords match
    print(f"Result: {result}\n")

    # Test case 4: Cores quota type
    print("Test 4: Cores quota type (special case)")
    cores_quota = {
        "name": {
            "value": "Cores",
            "localizedValue": "Total Regional vCPUs"
        },
        "limit": 10000,
        "currentValue": 5432,
        "unit": "count"
    }
    result = parse_quota_item(cores_quota, debug=True)
    assert result is not None, "Cores quota should parse"
    assert result["limit"] == 10000
    print("✓ Cores quota parsed correctly\n")

    # Test case 5: Invalid name object (not dict)
    print("Test 5: Invalid name object")
    invalid_name = {
        "name": "notADict",
        "limit": 100,
        "currentValue": 50,
        "unit": "count"
    }
    result = parse_quota_item(invalid_name, debug=True)
    assert result is None, "Invalid name should be skipped"
    print("✓ Invalid name object skipped correctly\n")

    # Test case 6: String numbers (should convert)
    print("Test 6: String numbers")
    string_numbers = {
        "name": {
            "value": "standardFSv2Family",
            "localizedValue": "Standard FSv2 Family vCPUs"
        },
        "limit": "500",
        "currentValue": "123",
        "unit": "count"
    }
    result = parse_quota_item(string_numbers, debug=True)
    assert result is not None, "String numbers should convert"
    assert result["limit"] == 500
    assert result["current_usage"] == 123
    print("✓ String numbers converted to int\n")

    # Test case 7: Empty resource type with data
    print("Test 7: Empty resource type")
    empty_type = {
        "name": {
            "value": "",
            "localizedValue": "Some Quota"
        },
        "limit": 100,
        "currentValue": 50,
        "unit": "count"
    }
    result = parse_quota_item(empty_type, debug=True)
    assert result is None, "Empty resource_type should be skipped"
    print("✓ Empty resource_type skipped correctly\n")

    # Test case 8: Negative values (invalid)
    print("Test 8: Negative values")
    negative = {
        "name": {
            "value": "standardLSv2Family",
            "localizedValue": "Standard LSv2 Family vCPUs"
        },
        "limit": -10,
        "currentValue": -5,
        "unit": "count"
    }
    result = parse_quota_item(negative, debug=True)
    # Should parse but with negative values (real Azure doesn't send these)
    assert result is not None
    print("✓ Negative values parsed (unlikely in real data)\n")

    print("=" * 70)
    print("✅ ALL QUOTA PARSING TESTS PASSED")
    print("=" * 70)


if __name__ == "__main__":
    try:
        test_quota_parsing_with_various_formats()
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
