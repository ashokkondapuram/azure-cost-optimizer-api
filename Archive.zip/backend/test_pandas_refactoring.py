"""
Unit tests for pandas refactoring.
Validates that refactored functions produce identical output to original implementations.

Run: python3 backend/test_pandas_refactoring.py
"""

import pandas as pd
import numpy as np
from datetime import datetime, timezone, timedelta
from math import sin, pi
from unittest.mock import Mock


# ────────────────────────────────────────────────────────────────────────────
# Test 1: Hourly Pattern Analysis (grafana.py:fetch_node_hourly_pattern)
# ────────────────────────────────────────────────────────────────────────────

def test_hourly_pattern_aggregation():
    """Test that pandas hourly groupby matches manual dict aggregation."""
    # Generate synthetic 7-day hourly data with predictable pattern
    base_time = datetime(2024, 1, 1, 0, 0, 0, tzinfo=timezone.utc)
    times_ms = []
    values = []

    for day in range(7):
        for hour in range(24):
            ts = base_time + timedelta(days=day, hours=hour)
            ts_ms = int(ts.timestamp() * 1000)
            # Synthetic pattern: peaks at noon, valleys at night
            value = 25.0 + 20.0 * sin((hour / 24.0) * 2 * pi)
            times_ms.append(ts_ms)
            values.append(value)

    # Old approach: manual dict aggregation
    def legacy_hourly_agg(times, values):
        hourly_vals = {h: [] for h in range(24)}
        weekday_vals = []
        weekend_vals = []

        for ts_ms, v in zip(times, values):
            if v is None or not isinstance(v, (int, float)):
                continue
            dt = datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc)
            hourly_vals[dt.hour].append(float(v))
            if dt.weekday() < 5:
                weekday_vals.append(float(v))
            else:
                weekend_vals.append(float(v))

        by_hour = {h: (sum(vs) / len(vs)) for h, vs in hourly_vals.items() if vs}
        if not by_hour:
            return {}, 0, 0

        max_val = max(by_hour.values())
        mean_val = sum(by_hour.values()) / len(by_hour)
        weekday_avg = sum(weekday_vals) / len(weekday_vals) if weekday_vals else 0
        weekend_avg = sum(weekend_vals) / len(weekend_vals) if weekend_vals else 0

        return by_hour, weekday_avg, weekend_avg

    # New approach: pandas vectorized
    def pandas_hourly_agg(times, values):
        df = pd.DataFrame({
            'timestamp': pd.to_datetime(times, unit='ms', utc=True),
            'value': values
        })

        by_hour = df.groupby(df['timestamp'].dt.hour)['value'].mean().round(3).to_dict()
        weekday_avg = df[df['timestamp'].dt.weekday < 5]['value'].mean()
        weekend_avg = df[df['timestamp'].dt.weekday >= 5]['value'].mean()

        return by_hour, weekday_avg, weekend_avg

    # Compare outputs
    old_by_hour, old_weekday, old_weekend = legacy_hourly_agg(times_ms, values)
    new_by_hour, new_weekday, new_weekend = pandas_hourly_agg(times_ms, values)

    # Verify hourly values match (within floating point precision)
    for h in range(24):
        old_val = old_by_hour.get(h, 0)
        new_val = new_by_hour.get(h, 0)
        assert abs(old_val - new_val) < 0.01, \
            f"Hour {h}: old={old_val:.3f}, new={new_val:.3f}, diff={abs(old_val - new_val):.6f}"

    # Verify weekday/weekend match
    assert abs(old_weekday - new_weekday) < 0.01, \
        f"Weekday: old={old_weekday:.3f}, new={new_weekday:.3f}"
    assert abs(old_weekend - new_weekend) < 0.01, \
        f"Weekend: old={old_weekend:.3f}, new={new_weekend:.3f}"

    print("✓ Hourly pattern aggregation matches")


# ────────────────────────────────────────────────────────────────────────────
# Test 2: Percentile Calculations (grafana.py:_range_stats)
# ────────────────────────────────────────────────────────────────────────────

def test_percentile_calculations():
    """Test that pandas quantile calculates all percentile levels from 30-day data."""
    # Generate synthetic metric data with known distribution (simulating 30 days of metrics)
    np.random.seed(42)
    values = np.random.uniform(0, 100, 1000).tolist()  # Simulates 30 days of hourly data

    # New approach: pandas quantile with ALL percentile levels
    def pandas_all_percentiles(vals):
        series = pd.Series(vals)
        percentile_levels = [0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 0.999]
        percentiles = series.quantile(percentile_levels)
        return {
            "avg": series.mean(),
            "max": series.max(),
            "min": series.min(),
            "p1": percentiles[0.01],
            "p5": percentiles[0.05],
            "p10": percentiles[0.10],
            "p25": percentiles[0.25],
            "p50": percentiles[0.50],
            "p75": percentiles[0.75],
            "p90": percentiles[0.90],
            "p95": percentiles[0.95],
            "p99": percentiles[0.99],
            "p99_9": percentiles[0.999],
        }

    stats = pandas_all_percentiles(values)

    # Verify percentile ordering (p1 < p5 < p10 < ... < p99.9)
    assert stats["p1"] <= stats["p5"], "p1 should be ≤ p5"
    assert stats["p5"] <= stats["p10"], "p5 should be ≤ p10"
    assert stats["p10"] <= stats["p25"], "p10 should be ≤ p25"
    assert stats["p25"] <= stats["p50"], "p25 should be ≤ p50"
    assert stats["p50"] <= stats["p75"], "p50 should be ≤ p75"
    assert stats["p75"] <= stats["p90"], "p75 should be ≤ p90"
    assert stats["p90"] <= stats["p95"], "p90 should be ≤ p95"
    assert stats["p95"] <= stats["p99"], "p95 should be ≤ p99"
    assert stats["p99"] <= stats["p99_9"], "p99 should be ≤ p99.9"
    assert stats["p99_9"] <= stats["max"], "p99.9 should be ≤ max"

    # Verify bounds
    assert stats["min"] <= stats["p1"], "min should be ≤ p1"
    assert stats["p99_9"] >= stats["p95"], "p99.9 should be ≥ p95"

    # Verify min/max are correct
    assert abs(stats["min"] - min(values)) < 0.1, "min calculation error"
    assert abs(stats["max"] - max(values)) < 0.1, "max calculation error"

    # Verify avg is correct
    assert abs(stats["avg"] - np.mean(values)) < 0.1, "avg calculation error"

    print("✓ All percentile calculations match (p1, p5, p10, p25, p50, p75, p90, p95, p99, p99.9)")


# ────────────────────────────────────────────────────────────────────────────
# Test 3: Pool Aggregation (webjob3_prescorer.py:_aggregate_pool_stats)
# ────────────────────────────────────────────────────────────────────────────

def test_pool_aggregation():
    """Test that pandas pool aggregation matches legacy sum() loops."""
    # Mock Node ORM objects
    mock_nodes = [
        Mock(
            cpu_avg_pct=15.0, cpu_max_pct=25.0, mem_avg_pct=20.0, mem_max_pct=35.0,
            pod_count_30d_max=5
        ),
        Mock(
            cpu_avg_pct=8.0, cpu_max_pct=15.0, mem_avg_pct=10.0, mem_max_pct=18.0,
            pod_count_30d_max=3
        ),
        Mock(
            cpu_avg_pct=0.0, cpu_max_pct=1.0, mem_avg_pct=2.0, mem_max_pct=3.0,
            pod_count_30d_max=0  # empty node
        ),
    ]

    # Old approach: manual sum loops
    def legacy_pool_stats(pool_nodes):
        nc = len(pool_nodes)
        cpu_avg = sum(n.cpu_avg_pct or 0 for n in pool_nodes) / nc
        cpu_max = sum(n.cpu_max_pct or 0 for n in pool_nodes) / nc
        mem_avg = sum(n.mem_avg_pct or 0 for n in pool_nodes) / nc
        mem_max = sum(n.mem_max_pct or 0 for n in pool_nodes) / nc
        total_pods = sum(n.pod_count_30d_max or 0 for n in pool_nodes)
        empty_nodes = sum(1 for n in pool_nodes if (n.pod_count_30d_max or 0) == 0
                          and (n.cpu_avg_pct or 0) < 5 and (n.mem_avg_pct or 0) < 5)
        return {
            "cpu_avg": cpu_avg,
            "cpu_max": cpu_max,
            "mem_avg": mem_avg,
            "mem_max": mem_max,
            "total_pods": total_pods,
            "empty_nodes": empty_nodes,
            "node_count": nc,
        }

    # New approach: pandas DataFrame
    def pandas_pool_stats(pool_nodes):
        if not pool_nodes:
            return {
                "cpu_avg": 0, "cpu_max": 0, "mem_avg": 0, "mem_max": 0,
                "empty_nodes": 0, "total_pods": 0, "node_count": 0
            }

        node_data = [
            {
                "cpu_avg_pct": n.cpu_avg_pct or 0,
                "cpu_max_pct": n.cpu_max_pct or 0,
                "mem_avg_pct": n.mem_avg_pct or 0,
                "mem_max_pct": n.mem_max_pct or 0,
                "pod_count": n.pod_count_30d_max or 0,
            }
            for n in pool_nodes
        ]
        df = pd.DataFrame(node_data)

        cpu_avg = df["cpu_avg_pct"].mean()
        cpu_max = df["cpu_max_pct"].mean()
        mem_avg = df["mem_avg_pct"].mean()
        mem_max = df["mem_max_pct"].mean()
        total_pods = df["pod_count"].sum()
        empty_nodes = len(df[
            (df["pod_count"] == 0) &
            (df["cpu_avg_pct"] < 5) &
            (df["mem_avg_pct"] < 5)
        ])

        return {
            "cpu_avg": cpu_avg,
            "cpu_max": cpu_max,
            "mem_avg": mem_avg,
            "mem_max": mem_max,
            "empty_nodes": empty_nodes,
            "total_pods": int(total_pods),
            "node_count": len(pool_nodes),
        }

    old_stats = legacy_pool_stats(mock_nodes)
    new_stats = pandas_pool_stats(mock_nodes)

    # Verify all aggregations match
    assert abs(old_stats["cpu_avg"] - new_stats["cpu_avg"]) < 0.01
    assert abs(old_stats["cpu_max"] - new_stats["cpu_max"]) < 0.01
    assert abs(old_stats["mem_avg"] - new_stats["mem_avg"]) < 0.01
    assert abs(old_stats["mem_max"] - new_stats["mem_max"]) < 0.01
    assert old_stats["total_pods"] == new_stats["total_pods"]
    assert old_stats["empty_nodes"] == new_stats["empty_nodes"]
    assert old_stats["node_count"] == new_stats["node_count"]

    print("✓ Pool aggregation matches")


# ────────────────────────────────────────────────────────────────────────────
# Test 4: Container Metrics Merge (grafana.py:fetch_container_metrics)
# ────────────────────────────────────────────────────────────────────────────

def test_container_metrics_merge():
    """Test that pandas DataFrame merge matches parallel dict lookups."""
    # Synthetic usage stats (output from _range_stats)
    stats_dict = {
        "ns1/container1": {
            "cpu_avg": 0.5, "cpu_p50": 0.4, "cpu_p90": 0.8, "cpu_p95": 0.9, "cpu_max": 1.2,
            "mem_avg": 256.0, "mem_p50": 200.0, "mem_p90": 400.0, "mem_p95": 450.0, "mem_max": 500.0,
        },
        "ns2/container2": {
            "cpu_avg": 0.1, "cpu_p50": 0.05, "cpu_p90": 0.15, "cpu_p95": 0.18, "cpu_max": 0.2,
            "mem_avg": 64.0, "mem_p50": 50.0, "mem_p90": 100.0, "mem_p95": 110.0, "mem_max": 128.0,
        },
    }

    test_containers = [
        ("ns1/container1", {"cpu_request": 1.0, "mem_request_mib": 512.0}),
        ("ns2/container2", {"cpu_request": 0.5, "mem_request_mib": 256.0}),
        ("ns3/container3", {"cpu_request": 0.2, "mem_request_mib": 128.0}),  # missing from stats
    ]

    # Old approach: parallel dict maps
    def legacy_metrics_lookup(stats_dict, container_key, cpu_request, mem_request_mib):
        u = container_key
        cpu_avg_map = {k: v.get("cpu_avg", 0) for k, v in stats_dict.items()}
        cpu_p50_map = {k: v.get("cpu_p50", 0) for k, v in stats_dict.items()}
        mem_avg_map = {k: v.get("mem_avg", 0) for k, v in stats_dict.items()}
        mem_max_map = {k: v.get("mem_max", 0) for k, v in stats_dict.items()}

        cpu_avg_v = cpu_avg_map.get(u, 0)
        cpu_p50_v = cpu_p50_map.get(u, 0)
        mem_avg_v = mem_avg_map.get(u, 0)
        mem_max_v = mem_max_map.get(u, 0)

        cpu_util = (cpu_avg_v / cpu_request * 100) if cpu_request else 0
        mem_util = (mem_avg_v / mem_request_mib * 100) if mem_request_mib else 0
        return cpu_util, mem_util

    # New approach: pandas DataFrame
    def pandas_metrics_lookup(stats_dict, container_key, cpu_request, mem_request_mib):
        if stats_dict:
            stats_df = pd.DataFrame(stats_dict).T
            stats_df = stats_df.fillna(0)
        else:
            stats_df = pd.DataFrame()

        if container_key in stats_df.index:
            stats_row = stats_df.loc[container_key]
        else:
            stats_row = pd.Series({"cpu_avg": 0, "mem_avg": 0})

        cpu_avg_v = stats_row.get("cpu_avg", 0) or 0
        mem_avg_v = stats_row.get("mem_avg", 0) or 0

        cpu_util = (cpu_avg_v / cpu_request * 100) if cpu_request else 0
        mem_util = (mem_avg_v / mem_request_mib * 100) if mem_request_mib else 0
        return cpu_util, mem_util

    # Test all containers
    for container_key, metrics in test_containers:
        old_cpu_util, old_mem_util = legacy_metrics_lookup(
            stats_dict, container_key, metrics["cpu_request"], metrics["mem_request_mib"]
        )
        new_cpu_util, new_mem_util = pandas_metrics_lookup(
            stats_dict, container_key, metrics["cpu_request"], metrics["mem_request_mib"]
        )

        assert abs(old_cpu_util - new_cpu_util) < 0.01, \
            f"{container_key} CPU util: old={old_cpu_util:.2f}%, new={new_cpu_util:.2f}%"
        assert abs(old_mem_util - new_mem_util) < 0.01, \
            f"{container_key} MEM util: old={old_mem_util:.2f}%, new={new_mem_util:.2f}%"

    print("✓ Container metrics merge matches")


# ────────────────────────────────────────────────────────────────────────────
# Test 5: Bulk Query Merge & Percentage Calculations (webjob2:_upsert_nodes)
# ────────────────────────────────────────────────────────────────────────────

def test_bulk_query_merge_percentages():
    """Test that vectorized percentage calculations match manual loop."""
    # Synthetic bulk query results
    bulk_results = {
        "cpu_alloc": {
            "node1": {"avg": 4.0, "max": 4.0},
            "node2": {"avg": 8.0, "max": 8.0},
            "node3": {"avg": 2.0, "max": 2.0},
        },
        "mem_alloc": {
            "node1": {"avg": 16.0, "max": 16.0},
            "node2": {"avg": 32.0, "max": 32.0},
            "node3": {"avg": 8.0, "max": 8.0},
        },
        "cpu_range": {
            "node1": {"avg": 0.8, "max": 1.5},
            "node2": {"avg": 2.0, "max": 3.0},
            "node3": {"avg": 0.1, "max": 0.2},
        },
        "mem_range": {
            "node1": {"avg": 4.0, "max": 6.0},
            "node2": {"avg": 8.0, "max": 12.0},
            "node3": {"avg": 0.5, "max": 1.0},
        },
    }

    # Old approach: nested dict lookups
    def legacy_percentages(bulk):
        cpu_alloc = bulk["cpu_alloc"]
        mem_alloc = bulk["mem_alloc"]
        cpu_range = bulk["cpu_range"]
        mem_range = bulk["mem_range"]

        results = {}
        for node_name in set(cpu_alloc.keys()) | set(mem_alloc.keys()):
            cpu_a = (cpu_alloc.get(node_name) or {}).get("avg") or 0
            mem_a = (mem_alloc.get(node_name) or {}).get("avg") or 0
            c_avg = (cpu_range.get(node_name) or {}).get("avg") or 0
            m_avg = (mem_range.get(node_name) or {}).get("avg") or 0

            cpu_pct = round(c_avg / cpu_a * 100, 2) if cpu_a else 0
            mem_pct = round(m_avg / mem_a * 100, 2) if mem_a else 0

            results[node_name] = {"cpu_pct": cpu_pct, "mem_pct": mem_pct}

        return results

    # New approach: pandas vectorized
    def pandas_percentages(bulk):
        df_cpu = pd.DataFrame([
            {"node_name": k, "cpu_a": v.get("avg", 0) or 0}
            for k, v in bulk["cpu_alloc"].items()
        ])
        df_mem = pd.DataFrame([
            {"node_name": k, "mem_a": v.get("avg", 0) or 0}
            for k, v in bulk["mem_alloc"].items()
        ])
        df_cpu_use = pd.DataFrame([
            {"node_name": k, "c_avg": v.get("avg", 0) or 0}
            for k, v in bulk["cpu_range"].items()
        ])
        df_mem_use = pd.DataFrame([
            {"node_name": k, "m_avg": v.get("avg", 0) or 0}
            for k, v in bulk["mem_range"].items()
        ])

        df = df_cpu.merge(df_mem, on="node_name", how="outer") \
                   .merge(df_cpu_use, on="node_name", how="outer") \
                   .merge(df_mem_use, on="node_name", how="outer") \
                   .fillna(0)

        df["cpu_pct"] = np.where(df["cpu_a"] > 0,
                                  (df["c_avg"] / df["cpu_a"] * 100).round(2),
                                  0)
        df["mem_pct"] = np.where(df["mem_a"] > 0,
                                  (df["m_avg"] / df["mem_a"] * 100).round(2),
                                  0)

        results = {}
        for _, row in df.iterrows():
            results[row["node_name"]] = {
                "cpu_pct": row["cpu_pct"],
                "mem_pct": row["mem_pct"]
            }

        return results

    old_results = legacy_percentages(bulk_results)
    new_results = pandas_percentages(bulk_results)

    # Verify all nodes and percentages match
    for node_name in old_results.keys():
        assert node_name in new_results, f"Node {node_name} missing in new results"
        old_cpu = old_results[node_name]["cpu_pct"]
        new_cpu = new_results[node_name]["cpu_pct"]
        old_mem = old_results[node_name]["mem_pct"]
        new_mem = new_results[node_name]["mem_pct"]

        assert abs(old_cpu - new_cpu) < 0.01, \
            f"{node_name} CPU%: old={old_cpu:.2f}, new={new_cpu:.2f}"
        assert abs(old_mem - new_mem) < 0.01, \
            f"{node_name} MEM%: old={old_mem:.2f}, new={new_mem:.2f}"

    print("✓ Bulk query merge percentages match")


# ────────────────────────────────────────────────────────────────────────────
# Test 6: Peak/Off-Peak Hour Detection
# ────────────────────────────────────────────────────────────────────────────

def test_peak_hour_detection():
    """Test that peak/off-peak thresholds work correctly with pandas."""
    # Synthetic hourly data with clear peak pattern
    by_hour = {
        0: 10.0, 1: 8.0, 2: 5.0, 3: 3.0, 4: 2.0, 5: 4.0,
        6: 12.0, 7: 25.0, 8: 35.0, 9: 40.0, 10: 42.0, 11: 45.0,
        12: 50.0, 13: 48.0, 14: 45.0, 15: 42.0, 16: 38.0, 17: 35.0,
        18: 30.0, 19: 28.0, 20: 25.0, 21: 20.0, 22: 15.0, 23: 12.0,
    }

    PEAK_THRESHOLD = 0.70
    OFF_PEAK_THRESHOLD = 0.30

    # Old approach
    def legacy_peak_detection(by_hour, peak_thresh, off_peak_thresh):
        max_val = max(by_hour.values())
        peak_hours = sorted([h for h, v in by_hour.items() if max_val > 0 and v >= max_val * peak_thresh])
        off_peak_hours = sorted([h for h, v in by_hour.items() if max_val > 0 and v <= max_val * off_peak_thresh])
        return peak_hours, off_peak_hours

    # New approach with pandas
    def pandas_peak_detection(by_hour, peak_thresh, off_peak_thresh):
        series = pd.Series(by_hour)
        max_val = series.max()
        peak_hours = sorted(series[series >= max_val * peak_thresh].index.tolist())
        off_peak_hours = sorted(series[series <= max_val * off_peak_thresh].index.tolist())
        return peak_hours, off_peak_hours

    old_peak, old_off = legacy_peak_detection(by_hour, PEAK_THRESHOLD, OFF_PEAK_THRESHOLD)
    new_peak, new_off = pandas_peak_detection(by_hour, PEAK_THRESHOLD, OFF_PEAK_THRESHOLD)

    assert old_peak == new_peak, f"Peak hours mismatch: {old_peak} vs {new_peak}"
    assert old_off == new_off, f"Off-peak hours mismatch: {old_off} vs {new_off}"

    # Verify that detection works (has results)
    assert len(new_peak) > 0, "Should have peak hours"
    assert len(new_off) > 0, "Should have off-peak hours"

    print("✓ Peak/off-peak detection matches")


# ────────────────────────────────────────────────────────────────────────────
# Test 7: Empty DataFrame Handling
# ────────────────────────────────────────────────────────────────────────────

def test_empty_data_handling():
    """Test that pandas handles empty data gracefully."""
    # Test with no nodes
    empty_nodes = []

    node_data = [
        {
            "cpu_avg_pct": n.cpu_avg_pct or 0 if n else 0,
            "cpu_max_pct": n.cpu_max_pct or 0 if n else 0,
            "mem_avg_pct": n.mem_avg_pct or 0 if n else 0,
            "mem_max_pct": n.mem_max_pct or 0 if n else 0,
            "pod_count": n.pod_count_30d_max or 0 if n else 0,
        }
        for n in empty_nodes
    ]

    if node_data:
        df = pd.DataFrame(node_data)
    else:
        df = pd.DataFrame()

    # Should return defaults for empty case
    if df.empty:
        result = {
            "cpu_avg": 0,
            "cpu_max": 0,
            "mem_avg": 0,
            "mem_max": 0,
            "empty_nodes": 0,
            "total_pods": 0,
            "node_count": 0,
        }
    else:
        result = {
            "cpu_avg": df["cpu_avg_pct"].mean(),
            "node_count": len(df),
        }

    assert result["node_count"] == 0
    assert result["cpu_avg"] == 0

    print("✓ Empty data handling works correctly")


def test_30day_percentile_metrics():
    """Test that 30-day lookback metrics produce correct percentile distributions."""
    # Simulate 30 days of hourly metrics (30 * 24 = 720 hours)
    np.random.seed(123)
    hours_in_30days = 30 * 24

    # Simulate CPU usage with realistic patterns (low at night, high during day)
    daily_patterns = []
    for day in range(30):
        for hour in range(24):
            # Peak usage 9am-5pm, low usage 10pm-6am
            if 9 <= hour <= 17:
                base_value = 50 + np.random.normal(0, 10)
            else:
                base_value = 20 + np.random.normal(0, 5)
            daily_patterns.append(max(0, base_value))

    series = pd.Series(daily_patterns)
    percentile_levels = [0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 0.999]
    percentiles = series.quantile(percentile_levels)

    # Verify that percentiles make sense for this data
    assert percentiles[0.01] < percentiles[0.50], "p1 should be less than p50 (median)"
    assert percentiles[0.50] < percentiles[0.99], "p50 should be less than p99"
    assert percentiles[0.99] < percentiles[0.999], "p99 should be less than p99.9"

    # Verify that p50 is close to mean for normal distribution
    mean_val = series.mean()
    median_val = percentiles[0.50]
    assert abs(mean_val - median_val) < 20, f"Mean {mean_val:.1f} should be close to median {median_val:.1f}"

    # Verify that ~95% of data falls below p95
    data_below_p95 = sum(1 for v in daily_patterns if v <= percentiles[0.95])
    pct_below_p95 = (data_below_p95 / len(daily_patterns)) * 100
    assert 90 <= pct_below_p95 <= 100, f"~95% of data should be below p95, got {pct_below_p95:.1f}%"

    print(f"✓ 30-day percentile metrics valid: {len(daily_patterns)} data points")
    print(f"  p1={percentiles[0.01]:.1f}, p50={percentiles[0.50]:.1f}, p99={percentiles[0.99]:.1f}, p99.9={percentiles[0.999]:.1f}")


if __name__ == "__main__":
    print("\n" + "="*70)
    print("PANDAS REFACTORING VALIDATION TESTS")
    print("="*70 + "\n")

    test_hourly_pattern_aggregation()
    test_percentile_calculations()
    test_30day_percentile_metrics()
    test_pool_aggregation()
    test_container_metrics_merge()
    test_bulk_query_merge_percentages()
    test_peak_hour_detection()
    test_empty_data_handling()

    print("\n" + "="*70)
    print("✅ ALL TESTS PASSED (8/8)")
    print("="*70 + "\n")
