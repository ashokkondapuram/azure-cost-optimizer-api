"""
WebJob 2 — Restructured Metrics & Quota Collector
==================================================
Schedule : every 6 hours  (App_Data/jobs/triggered/webjob2_collector/settings.job)
Local run : python webjob2_collector.py

Data Flow:
  1. Get all nodes + metrics from Grafana (filtered by cluster)
  2. For each cluster → query Azure API for location/region
  3. For each node (sku) → query Azure API for quota (location + subscription + sku)
  4. Store in DB:
     - nodes table: metrics + location (from Azure)
     - quotas table: subscription + region + sku quota data
  5. Trigger webjob3 for AI scoring

Storage:
  - nodes: node_name, cluster, nodepool, region, sku, metrics (cpu/mem utilization)
  - quotas: subscription_id, region, resource_type (e.g., "Standard_D4s_v4"), limit, usage, available
"""

import json
import os
import sys
import ssl
import time
import urllib.request
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from sqlalchemy import text
from database import SessionLocal, SkuSessionLocal, init_db, DATA_WRITE_LOCK
from models import Node, Container, FetchLog, WebjobState, Quota
from datetime import datetime as dt
import grafana as gf

# ── Config ─────────────────────────────────────────────────────────────────────
KEYVAULT_URL  = os.environ.get("KEYVAULT_URL", "").rstrip("/")
GRAFANA_URL   = os.environ.get("GRAFANA_URL", "").rstrip("/")
GRAFANA_TOKEN = os.environ.get("GRAFANA_TOKEN", "")

# Token cache
_cached_azure_token: dict = {"token": None, "fetched_at": 0}

def _load_secrets():
    global GRAFANA_TOKEN
    if KEYVAULT_URL and not GRAFANA_TOKEN:
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
            kv = SecretClient(vault_url=KEYVAULT_URL, credential=DefaultAzureCredential())
            GRAFANA_TOKEN = kv.get_secret("grafana-api-token").value or ""
            print(f"[wj2] Secrets loaded from Key Vault")
        except Exception as e:
            print(f"[wj2] Key Vault load failed: {e}")

_load_secrets()

def _get_cached_azure_token() -> str:
    """Get Azure token. Fetched once per webjob2 run, reused for all API calls."""
    global _cached_azure_token
    # Return cached token if available (same webjob2 run)
    if _cached_azure_token["token"]:
        return _cached_azure_token["token"]

    # Fetch fresh token only once per run
    from main import _get_azure_token as _fetch_azure_token
    token = _fetch_azure_token()
    if token:
        _cached_azure_token["token"] = token
    return token

# ── Import Azure helpers from main (uses Managed Identity) ───────────────────
# These functions support:
# 1. App Service Managed Identity (IDENTITY_ENDPOINT env vars)
# 2. IMDS Managed Identity (VMs, older App Service plans)
# 3. Azure CLI token (local dev with `az login`)
# 4. Service Principal (DB config or env vars)
from main import _get_azure_token, _get_subscription_ids, _get_cluster_location, _get_sku_quota

# ── Bulk Prometheus Queries ────────────────────────────────────────────────────
_BULK_QUERIES = [
    ("cpu_alloc",  'sum by(node)(kube_node_status_allocatable{resource="cpu"})',                             "node"),
    ("mem_alloc",  'sum by(node)(kube_node_status_allocatable{resource="memory"}) / 1073741824',             "node"),
    ("cpu_range",  'sum by(node)(rate(container_cpu_usage_seconds_total{container!="",container!="POD"}[5m]))', "node"),
    ("mem_range",  'sum by(node)(container_memory_working_set_bytes{container!="",container!="POD"}) / 1073741824', "node"),
    ("pod_count",  'count by(node)(kube_pod_info{node!=""})',                                                "node"),
    ("node_labels",'kube_node_labels',                                                                       "node"),
]

def _run_bulk_queries(ds: dict) -> dict:
    """Run all 6 bulk queries for one datasource in parallel threads."""
    uid = ds["uid"]
    results = {}

    def _fetch(label, promql, _key):
        try:
            if label == "node_labels":
                return label, gf.fetch_node_labels(GRAFANA_URL, GRAFANA_TOKEN, uid)
            else:
                return label, gf.query_range(GRAFANA_URL, GRAFANA_TOKEN, uid, promql, _key)
        except Exception as e:
            print(f"  [wj2/{ds['name']}] {label} failed: {e}")
            return label, {}

    with ThreadPoolExecutor(max_workers=6) as pool:
        futures = [pool.submit(_fetch, lbl, pql, key) for lbl, pql, key in _BULK_QUERIES]
        for f in as_completed(futures):
            label, data = f.result()
            results[label] = data

    return results

# ── Node Upsert (Restructured) ─────────────────────────────────────────────────
def _upsert_nodes(db, ds: dict, bulk: dict, now: datetime, azure_token: str, sub_ids: list) -> int:
    """
    Restructured node upsert:
    1. Merge Grafana metrics
    2. Get cluster location from Azure API
    3. Get SKU quota from Azure API
    4. Store node metrics + location in nodes table
    5. Store quota in quotas table
    """
    import pandas as pd
    import numpy as np

    cpu_alloc  = bulk.get("cpu_alloc", {})
    mem_alloc  = bulk.get("mem_alloc", {})
    cpu_range  = bulk.get("cpu_range", {})
    mem_range  = bulk.get("mem_range", {})
    pod_counts = bulk.get("pod_count", {})
    labels_map = bulk.get("node_labels", {})

    # Build DataFrame from Grafana metrics
    df_cpu_alloc = pd.DataFrame([
        {"node_name": k, "cpu_a": v.get("avg", 0) or 0}
        for k, v in cpu_alloc.items() if k
    ])
    df_mem_alloc = pd.DataFrame([
        {"node_name": k, "mem_a": v.get("avg", 0) or 0}
        for k, v in mem_alloc.items() if k
    ])
    df_cpu_range = pd.DataFrame([
        {"node_name": k, "c_avg_cores": v.get("avg", 0) or 0, "c_max_cores": v.get("max", 0) or 0}
        for k, v in cpu_range.items() if k
    ])
    df_mem_range = pd.DataFrame([
        {"node_name": k, "m_avg_gb": v.get("avg", 0) or 0, "m_max_gb": v.get("max", 0) or 0}
        for k, v in mem_range.items() if k
    ])
    df_pod_counts = pd.DataFrame([
        {"node_name": k, "pod_max": int(v.get("avg", 0) or 0)}
        for k, v in pod_counts.items() if k
    ])

    if df_cpu_alloc.empty:
        return 0

    # Merge all metrics on node_name
    df = df_cpu_alloc
    for df_src in [df_mem_alloc, df_cpu_range, df_mem_range, df_pod_counts]:
        if not df_src.empty:
            df = df.merge(df_src, on="node_name", how="outer")
    df = df.fillna(0)

    # Add labels (cluster, nodepool, sku) from Grafana
    df["cluster"] = df["node_name"].map(
        lambda n: labels_map.get(n, {}).get("cluster", "") or ds["name"]
    )

    # Extract nodepool from labels, with fallback to parse AKS node name pattern
    def _extract_nodepool(node_name: str) -> str:
        # Try to get from labels first
        label_pool = labels_map.get(node_name, {}).get("nodepool", "")
        if label_pool:
            return label_pool
        # Fallback: AKS node names follow pattern: aks-{poolname}-{vmss_id}-{suffix}
        # e.g., "aks-appnodes-18545079-vmss00000n" → "appnodes"
        if node_name.startswith("aks-"):
            parts = node_name.split("-")
            if len(parts) >= 3:
                # parts[0]="aks", parts[1]=poolname, parts[2]=vmss_id, parts[3:]=suffix
                # rejoin parts[1:] until we hit a numeric vmss_id
                for i in range(1, len(parts)):
                    if parts[i] and parts[i][0].isdigit():
                        # Found the numeric part, everything before it (except "aks") is the poolname
                        return "-".join(parts[1:i])
        return ""

    df["nodepool"] = df["node_name"].map(_extract_nodepool)

    df["sku"] = df["node_name"].map(
        lambda n: labels_map.get(n, {}).get("sku", "")
    )

    # Vectorized percentage calculations
    df["cpu_avg_pct"] = np.where(df["cpu_a"] > 0,
                                  (df["c_avg_cores"] / df["cpu_a"] * 100).round(2),
                                  0)
    df["cpu_max_pct"] = np.where(df["cpu_a"] > 0,
                                  (df["c_max_cores"] / df["cpu_a"] * 100).round(2),
                                  0)
    df["mem_avg_pct"] = np.where(df["mem_a"] > 0,
                                  (df["m_avg_gb"] / df["mem_a"] * 100).round(2),
                                  0)
    df["mem_max_pct"] = np.where(df["mem_a"] > 0,
                                  (df["m_max_gb"] / df["mem_a"] * 100).round(2),
                                  0)

    # Bulk-load existing nodes
    all_node_names = df["node_name"].unique().tolist()
    existing_nodes = {n.node_name: n for n in db.query(Node).filter(Node.node_name.in_(all_node_names)).all()}

    # ── STEP 1: Get cluster locations (ClusterRegistry is source of truth) ──
    print("[wj2] STEP 1: Checking cluster locations from ClusterRegistry…")
    clusters_processed = {}  # {cluster_name: location}

    # Get unique clusters from metrics
    unique_clusters = df["cluster"].unique()
    print(f"[wj2] Found {len(unique_clusters)} unique cluster(s) in metrics: {list(unique_clusters)}")

    # Priority: ClusterRegistry → existing nodes → Azure API
    from models import ClusterRegistry

    for cluster_name in unique_clusters:
        if not cluster_name or cluster_name in clusters_processed:
            continue

        # First, check ClusterRegistry (source of truth)
        registry = db.query(ClusterRegistry).filter(ClusterRegistry.cluster_name == cluster_name).first()
        if registry and registry.location:
            location = registry.location
            print(f"[wj2] ✓ Found '{cluster_name}' in ClusterRegistry → '{location}'")
            clusters_processed[cluster_name] = location
            continue

        # Fallback: check existing nodes table
        from sqlalchemy import distinct as _distinct
        existing = db.query(Node.region).filter(
            Node.cluster == cluster_name,
            Node.region.isnot(None),
            Node.region != ""
        ).first()

        if existing and existing[0]:
            location = existing[0]
            print(f"[wj2] ✓ Found '{cluster_name}' in nodes table → '{location}'")
            clusters_processed[cluster_name] = location
            continue

        # Final fallback: query Azure API
        if azure_token and sub_ids:
            print(f"[wj2] Cluster '{cluster_name}' not in registry, querying Azure API...")
            location = _get_cluster_location(cluster_name, azure_token, sub_ids)
            clusters_processed[cluster_name] = location or ""
            print(f"[wj2] Result: '{cluster_name}' → '{location or '(NOT FOUND)'}'")
        else:
            clusters_processed[cluster_name] = ""
            print(f"[wj2] ⚠️  No location found for '{cluster_name}' (no Azure token)")

    # Add region to DataFrame
    # Direct mapping: cluster_name → location (from cache/database, or empty if not found)
    df["region"] = df["cluster"].map(lambda c: clusters_processed.get(c, ""))
    region_distribution = df["region"].value_counts()
    print(f"[wj2] Region distribution after lookup:")
    for region, count in region_distribution.items():
        print(f"[wj2]   {region or '(empty)'}: {count} nodes")

    # ── STEP 2: Update Node rows with metrics + location ──────────────────────
    count = 0
    for _, row in df.iterrows():
        node_name = row["node_name"]
        n = existing_nodes.get(node_name)
        if not n:
            n = Node(node_name=node_name)
            db.add(n)

        n.cluster           = row["cluster"]
        n.nodepool          = row["nodepool"]
        n.region            = row["region"]  # From Azure API
        n.current_sku       = row["sku"] or n.current_sku
        n.cpu_alloc         = row["cpu_a"]
        n.mem_alloc_gb      = row["mem_a"]
        n.cpu_avg_pct       = row["cpu_avg_pct"]
        n.cpu_max_pct       = row["cpu_max_pct"]
        n.mem_avg_pct       = row["mem_avg_pct"]
        n.mem_max_pct       = row["mem_max_pct"]
        n.cpu_avg_cores     = row["c_avg_cores"]
        n.cpu_max_cores     = row["c_max_cores"]
        n.mem_avg_gb        = row["m_avg_gb"]
        n.mem_max_gb        = row["m_max_gb"]
        n.pod_count_30d_max = int(row["pod_max"])
        n.last_fetched_at   = now

        # Clear stale SCALE_DOWN if node has pods again
        if int(row["pod_max"]) > 0 and n.rec_sku == "SCALE_DOWN":
            n.rec_sku = None

        count += 1

    db.commit()
    print(f"[wj2] ✓ DB write done: {count} nodes updated with metrics + locations")

    # ── STEP 2.5: Fetch and store container data from Grafana ────────────────────
    print("[wj2] STEP 2.5: Fetching container metrics from Grafana…")
    try:
        # Query Grafana for container metrics (preserve namespace, pod, and container labels)
        container_metrics = gf.query_range(
            GRAFANA_URL, GRAFANA_TOKEN, ds["uid"],
            'sum by(namespace, pod, container) (container_cpu_usage_seconds_total{container!="", container!="POD"})',
            start_time, end_time
        )

        containers_processed = {}
        if container_metrics and "data" in container_metrics:
            for result in container_metrics.get("data", {}).get("result", []):
                labels = result.get("metric", {})
                namespace = labels.get("namespace", "default")
                pod_name = labels.get("pod", "")
                container_name = labels.get("container", pod_name)

                if pod_name:
                    container_id = f"{namespace}/{container_name}"
                    containers_processed[container_id] = {
                        "namespace": namespace,
                        "container_name": container_name,
                        "pod_name": pod_name,
                    }

            print(f"[wj2] Found {len(containers_processed)} unique containers in metrics")

            # Store containers (simple mapping for now)
            container_count = 0
            now = datetime.now(timezone.utc)
            for container_id, ctr_data in containers_processed.items():
                c = db.query(Container).filter(Container.container_id == container_id).first()
                if not c:
                    c = Container(container_id=container_id)
                    db.add(c)

                c.container_name = ctr_data.get("container_name")
                c.namespace = ctr_data.get("namespace")
                c.cluster = ds["name"]
                c.pod_names = [ctr_data.get("pod_name")]
                c.last_fetched_at = now
                container_count += 1

            db.commit()
            print(f"[wj2] ✓ DB write done: {container_count} containers stored")
        else:
            print("[wj2] No container metrics found in Grafana")
    except Exception as e:
        print(f"[wj2] ⚠️  Container fetch failed: {e}")

    # ── STEP 3: Fetch SKU quotas only for NEW region/SKU combinations ──────────
    print("[wj2] STEP 3: Checking SKU quotas (using cached token)…")
    if azure_token and sub_ids:
        print(f"[wj2] Using cached token for quota lookups")

        # Get unique region/SKU pairs from current metrics
        unique_region_sku_pairs = df[['region', 'sku']].drop_duplicates().values.tolist()
        print(f"[wj2] Found {len(unique_region_sku_pairs)} unique region/SKU combinations in metrics")

        # Check which region/SKU combinations already exist in quotas table
        existing_quotas = {(row[0], row[1]) for row in
                          db.query(Quota.region, Quota.resource_type).distinct().all()}
        print(f"[wj2] Found {len(existing_quotas)} region/SKU combinations already in database")

        # Find new combinations needing quota lookup
        new_quotas = [(r, s) for r, s in unique_region_sku_pairs
                      if r and s and (r, s) not in existing_quotas]
        print(f"[wj2] Need to fetch quotas for {len(new_quotas)} new combinations")

        quota_success = 0
        quota_failed = 0
        quota_skipped = 0
        sub_id = sub_ids[0]  # Use primary subscription

        # Process with throttling to avoid Azure rate limits
        for idx, (region, sku) in enumerate(new_quotas):
            if not region or not sku:
                quota_skipped += 1
                continue

            if region not in clusters_processed.values():
                print(f"[wj2] ⚠️  Region '{region}' not in processed clusters: {list(clusters_processed.values())}")
                quota_skipped += 1
                continue

            try:
                quota_info = _get_sku_quota(region, sub_id, sku, azure_token)
                if quota_info:
                    quota_success += 1
                    print(f"[wj2] ✅ {region}/{sku}: {quota_info.get('vcpus')}vCPU, {quota_info.get('memory_gb')}GB")
                else:
                    quota_failed += 1
                    print(f"[wj2] ⚠️  {region}/{sku}: no quota data returned")
            except Exception as e:
                quota_failed += 1
                print(f"[wj2] ❌ {region}/{sku}: {type(e).__name__}: {str(e)[:80]}")

            # Small delay between requests to avoid Azure rate limiting (429 errors)
            if idx < len(new_quotas) - 1:
                import time as time_module
                time_module.sleep(0.5)

        print(f"[wj2] SKU quota results: ✅ {quota_success} new, ❌ {quota_failed} failed, ⏭️  {quota_skipped} skipped")
    else:
        print(f"[wj2] ⚠️  Skipping SKU quota lookup: token={bool(azure_token)}, subs={bool(sub_ids)}")

    return count

def run():
    if not GRAFANA_URL or not GRAFANA_TOKEN:
        print("[wj2] GRAFANA_URL / GRAFANA_TOKEN not set — aborting")
        sys.exit(1)

    print(f"[wj2] Starting metrics collection — {datetime.now(timezone.utc).isoformat()}")
    init_db()

    try:
        datasources = gf.list_mimir_datasources(GRAFANA_URL, GRAFANA_TOKEN)
    except Exception as e:
        print(f"[wj2] Cannot reach Grafana: {e}")
        sys.exit(1)

    if not datasources:
        print("[wj2] No Prometheus datasources found")
        sys.exit(0)

    print(f"[wj2] {len(datasources)} datasource(s): {[d['name'] for d in datasources]}")

    # Get Azure credentials ONCE (token fetched once, reused for all calls)
    print("[wj2] Fetching Managed Identity token (once per run)…")
    azure_token = _get_cached_azure_token()
    if azure_token:
        print("[wj2] ✅ Managed Identity token obtained — will be reused for all API calls")

    sub_ids = _get_subscription_ids(azure_token) if azure_token else []
    if azure_token and sub_ids:
        print(f"[wj2] ✅ Authenticated with {len(sub_ids)} subscription(s) — reusing same token for cluster/quota lookups")
    else:
        print("[wj2] ⚠️  Azure authentication failed or no subscriptions — quota lookup disabled")

    now = datetime.now(timezone.utc)
    total_n = 0

    with DATA_WRITE_LOCK:
        db = SessionLocal()
        log = FetchLog(started_at=now)
        db.add(log)
        db.commit()
        print("[wj2] ✓ DB write done: FetchLog created")
        try:
            for ds in datasources:
                print(f"  [wj2] querying {ds['name']} …")
                bulk = _run_bulk_queries(ds)
                n = _upsert_nodes(db, ds, bulk, now, azure_token, sub_ids)
                db.commit()
                print(f"  [wj2] ✓ DB write done: {n} nodes upserted for {ds['name']}")
                total_n += n
                print(f"  [wj2] {ds['name']}: {n} nodes upserted")

            # Signal webjob3 to run
            db.query(WebjobState).filter(WebjobState.job_name == "webjob3_prescorer").update({
                WebjobState.flag: 1,
                WebjobState.context: {"triggered_by": "webjob2", "nodes": total_n, "at": now.isoformat()},
                WebjobState.updated_at: now,
            })

            log.finished_at = datetime.now(timezone.utc)
            log.nodes_upserted = total_n
            db.commit()
            print(f"[wj2] ✓ DB write done: FetchLog finished, {total_n} nodes total, webjob3 flag set")

        except Exception as e:
            log.error = str(e)
            db.commit()
            print(f"[wj2] ✓ DB write done: Error logged — {e}")
            raise
        finally:
            db.close()

if __name__ == "__main__":
    run()
