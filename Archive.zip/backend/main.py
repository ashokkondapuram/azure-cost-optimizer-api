"""
VM Right-Sizing — FastAPI backend
Serves the dashboard HTML + REST API backed by PostgreSQL/SQLite.
"""

import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import ssl
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
import urllib.parse
import urllib.request
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import List, Optional

# APScheduler retained only for SKU sync — metrics/AI moved to WebJob 2/3
from apscheduler.schedulers.background import BackgroundScheduler
from fastapi import Depends, FastAPI, Header, HTTPException, BackgroundTasks
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
from sqlalchemy.exc import OperationalError
from sqlalchemy.orm import Session

import grafana as gf
from database import (SessionLocal, AuthSessionLocal, SkuSessionLocal,
                       get_db, get_auth_db, get_sku_db, init_db,
                       DATA_WRITE_LOCK, SKU_WRITE_LOCK)
from models import ActionHistory, Alert, AzureConfig, Container, Disk, FetchLog, Node, Policy, Snapshot, User, UserSession, VmSku

# ── Config ─────────────────────────────────────────────────────────────────────
# Only non-secret config is read from env vars.
# All secrets come from Azure Key Vault via Managed Identity.
KEYVAULT_URL           = os.environ.get("KEYVAULT_URL", "").rstrip("/")
GRAFANA_URL            = os.environ.get("GRAFANA_URL", "").rstrip("/")
FETCH_INTERVAL_HOURS   = int(os.environ.get("FETCH_INTERVAL_HOURS", "6"))
AZURE_SUBSCRIPTION_IDS = [
    s.strip() for s in
    os.environ.get("AZURE_SUBSCRIPTION_IDS",
                   os.environ.get("AZURE_SUBSCRIPTION_ID", "")).split(",")
    if s.strip()
]

# In-memory cache of DB-stored Azure creds — loaded at startup and on PUT /api/azure-config
_azure_db_creds: dict = {}   # keys: tenant_id, client_id, client_secret, subscription_ids
SKU_SYNC_INTERVAL_DAYS = int(os.environ.get("SKU_SYNC_INTERVAL_DAYS", "15"))  # Update SKU pricing every 15 days

_here = Path(__file__).parent
PAGES_DIR = (_here / "static") if (_here / "static").exists() else (_here.parent / "static")

# Secrets — loaded from Key Vault (production) or env vars (local dev only)
GRAFANA_TOKEN       = ""
OPENAI_KEY          = ""   # API key for both OpenAI and Azure OpenAI
DATABASE_URL_SECRET = ""   # overrides DATABASE_URL env var when set in Key Vault

# Azure OpenAI — set these to use Azure instead of api.openai.com
# OPENAI_ENDPOINT:   https://<resource>.openai.azure.com
# OPENAI_DEPLOYMENT: your deployment name (e.g. "gpt-4o")
# OPENAI_API_VERSION: defaults to 2024-08-01-preview
OPENAI_ENDPOINT   = ""
OPENAI_DEPLOYMENT = ""

def _load_secrets():
    """Load all secrets from Azure Key Vault using Managed Identity."""
    global GRAFANA_TOKEN, OPENAI_KEY, DATABASE_URL_SECRET, OPENAI_ENDPOINT, OPENAI_DEPLOYMENT

    if KEYVAULT_URL:
        try:
            from azure.identity import DefaultAzureCredential
            from azure.keyvault.secrets import SecretClient
            kv = SecretClient(vault_url=KEYVAULT_URL, credential=DefaultAzureCredential())

            def _get(name: str, fallback: str = "") -> str:
                try:
                    return kv.get_secret(name).value or fallback
                except Exception:
                    return fallback

            GRAFANA_TOKEN       = _get("grafana-api-token")
            OPENAI_KEY          = _get("openai-api-key")
            DATABASE_URL_SECRET = _get("database-url")
            # Azure OpenAI — try KV first, then App Settings env var
            OPENAI_ENDPOINT   = _get("openai-endpoint",   os.environ.get("OPENAI_ENDPOINT", ""))
            OPENAI_DEPLOYMENT = _get("openai-deployment", os.environ.get("OPENAI_DEPLOYMENT", ""))
            print(f"✓ Secrets loaded from Key Vault: {KEYVAULT_URL}")
            print(f"  OPENAI_KEY set: {bool(OPENAI_KEY)}  |  OPENAI_ENDPOINT: {OPENAI_ENDPOINT or '(not set)'}  |  OPENAI_DEPLOYMENT: {OPENAI_DEPLOYMENT or '(not set)'}")
        except Exception as e:
            print(f"WARNING: Key Vault load failed: {e}")
    else:
        # Local dev fallback — use env vars directly
        GRAFANA_TOKEN     = os.environ.get("GRAFANA_TOKEN", "")
        OPENAI_KEY        = os.environ.get("OPENAI_KEY", "")
        OPENAI_ENDPOINT   = os.environ.get("OPENAI_ENDPOINT", "")
        OPENAI_DEPLOYMENT = os.environ.get("OPENAI_DEPLOYMENT", "")
        print("ℹ No KEYVAULT_URL set — using local env vars for secrets")

_load_secrets()

# Apply Key Vault DATABASE_URL override before DB engine is created
if DATABASE_URL_SECRET:
    os.environ["DATABASE_URL"] = DATABASE_URL_SECRET

# ── Auth helpers ───────────────────────────────────────────────────────────────
# Session store: in-memory cache (warm path only — truth is the signed token)
_SESSIONS: dict = {}
SESSION_TTL_DAYS = 7

# ── Signed session tokens ─────────────────────────────────────────────────────
# Tokens are HMAC-SHA256 signed so they can be verified without DB or memory
# lookups — works correctly across multiple App Service instances and restarts.
# Secret is loaded from env var SESSION_SECRET, or auto-generated and stored
# in a file on the persistent /home mount the first time the app starts.
_SESSION_SECRET: str = ""
_SESSION_SECRET_FILE = "/home/session_secret.key"

def _load_session_secret() -> str:
    """Return a stable HMAC signing secret shared across ALL instances and restarts.

    Priority:
    1. SESSION_SECRET env var (set in Azure Portal App Settings — best option)
    2. Derived from admin user's password_hash in the auth DB (same DB = same secret
       across all processes/instances, survives restarts as long as DB persists)
    3. Persistent file on /home mount
    4. Ephemeral random (last resort — sessions won't survive instance switches)
    """
    env = os.environ.get("SESSION_SECRET", "").strip()
    if env:
        return env

    # Derive from the admin user's stable password_hash in the shared auth DB.
    # All processes and instances read the same DB file, so they all compute the
    # same secret without any coordination.
    try:
        db = AuthSessionLocal()
        try:
            user = db.query(User).filter(User.username == "admin").first()
            if user and user.password_hash:
                seed = f"rs_session_v1:{user.password_hash}"
                return hashlib.sha256(seed.encode()).hexdigest()
        finally:
            db.close()
    except Exception:
        pass

    # Persistent file fallback (works if /home is writable)
    try:
        if os.path.exists(_SESSION_SECRET_FILE):
            val = Path(_SESSION_SECRET_FILE).read_text().strip()
            if val:
                return val
        val = secrets.token_hex(32)
        Path(_SESSION_SECRET_FILE).write_text(val)
        return val
    except Exception:
        pass

    # Last resort: ephemeral (tokens break on restart/instance switch — acceptable)
    return secrets.token_hex(32)

def _sign_token(username: str, role: str, expires_ts: int) -> str:
    """Create a signed token: base64url(payload.sig)"""
    global _SESSION_SECRET
    if not _SESSION_SECRET:
        _SESSION_SECRET = _load_session_secret()
    payload = f"{username}:{role}:{expires_ts}"
    sig = hmac.new(_SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
    raw = f"{payload}.{sig}"
    return base64.urlsafe_b64encode(raw.encode()).decode().rstrip("=")

def _verify_signed_token(token: str):
    """Verify a signed token; returns session dict or None."""
    global _SESSION_SECRET
    if not _SESSION_SECRET:
        _SESSION_SECRET = _load_session_secret()
    try:
        padding = (4 - len(token) % 4) % 4
        padded = token + "=" * padding
        raw = base64.urlsafe_b64decode(padded.encode()).decode()
        payload, sig = raw.rsplit(".", 1)
        expected = hmac.new(_SESSION_SECRET.encode(), payload.encode(), hashlib.sha256).hexdigest()
        if not hmac.compare_digest(sig, expected):
            print(f"[auth] token signature mismatch — secret may differ across instances")
            return None
        parts = payload.split(":")
        if len(parts) != 3:
            return None
        username, role, expires_str = parts
        if int(expires_str) < int(time.time()):
            return None
        return {"username": username, "role": role}
    except Exception as _e:
        print(f"[auth] token verify error: {_e}")
        return None

def _hash_pw(pw: str) -> str:
    return hashlib.sha256(pw.encode()).hexdigest()

def _seed_users(db: Session):
    """Create default users if they don't exist (username == password)."""
    defaults = [
        ("admin",  "admin",  "admin"),
        ("editor", "editor", "editor"),
        ("viewer", "viewer", "viewer"),
    ]
    for username, password, role in defaults:
        if not db.query(User).filter(User.username == username).first():
            db.add(User(username=username, password_hash=_hash_pw(password), role=role))
    db.commit()

def _get_session(x_auth_token: str = Header(None)):
    token = x_auth_token or ""
    if not token:
        raise HTTPException(401, "Not authenticated")

    # 1. In-memory cache (fast path — same instance, same process)
    session = _SESSIONS.get(token)
    if session:
        return session

    # 2. Signed token verification (works across ALL instances and restarts)
    session = _verify_signed_token(token)
    if session:
        _SESSIONS[token] = session  # warm cache for future requests
        return session

    # 3. DB fallback for old-format opaque tokens (backward compatibility)
    try:
        db = AuthSessionLocal()
        try:
            row = db.query(UserSession).filter(
                UserSession.token == token[:64],
                UserSession.expires_at > datetime.utcnow()
            ).first()
            if row:
                session = {"username": row.username, "role": row.role}
                _SESSIONS[token] = session
                return session
        finally:
            db.close()
    except Exception as _e:
        print(f"[auth] DB fallback failed: {_e}")

    raise HTTPException(401, "Not authenticated")

# ── App init ───────────────────────────────────────────────────────────────────
app = FastAPI(title="VM Right-Sizing API", version="2.0")

@app.exception_handler(OperationalError)
async def db_locked_handler(request, exc):
    msg = str(exc.orig) if hasattr(exc, "orig") else str(exc)
    if "database is locked" in msg:
        return JSONResponse(status_code=503, content={"detail": "Database temporarily busy — please retry in a moment."})
    return JSONResponse(status_code=500, content={"detail": f"Database error: {msg}"})

init_db()

def _migrate_db():
    """Add any missing columns to existing tables (safe to run on every start)."""
    from sqlalchemy import text
    from database import _data_engine as data_engine, _sku_engine as sku_engine, SkuBase

    # Detect if using PostgreSQL or SQLite
    is_postgres_data = "postgresql" in str(data_engine.url)
    is_postgres_sku = "postgresql" in str(sku_engine.url)

    # ── data DB migrations ────────────────────────────────────────────────────
    with data_engine.connect() as conn:
        def _col_exists(table, col):
            if is_postgres_data:
                # PostgreSQL: use information_schema
                rows = conn.execute(text(
                    "SELECT column_name FROM information_schema.columns WHERE table_name = :t AND column_name = :c"
                ), {"t": table, "c": col}).fetchall()
                return len(rows) > 0
            else:
                # SQLite: use PRAGMA
                rows = conn.execute(text(f"PRAGMA table_info({table})")).fetchall()
                return any(r[1] == col for r in rows)

        for table, col, typ in [
            ("containers", "node_names",     "JSON"),
            ("containers", "cpu_max_pct",    "FLOAT"),
            ("containers", "mem_max_pct",    "FLOAT"),
            ("containers", "pod_names",      "JSON"),
            ("containers", "pod_node_map",   "JSON"),
            ("containers", "cpu_p50",          "FLOAT"),
            ("containers", "cpu_p90",          "FLOAT"),
            ("containers", "cpu_p95",          "FLOAT"),
            ("containers", "mem_p50_mib",      "FLOAT"),
            ("containers", "mem_p90_mib",      "FLOAT"),
            ("containers", "mem_p95_mib",      "FLOAT"),
            ("containers", "last_exit_reason",    "TEXT"),
            ("containers", "restart_count",      "INTEGER"),
            ("nodes",      "ai_assessed_at",     "DATETIME"),
            ("nodes",      "pod_count_30d_max",  "INTEGER"),
        ]:
            if not _col_exists(table, col):
                conn.execute(text(f"ALTER TABLE {table} ADD COLUMN {col} {typ}"))
                print(f"✓ Migrated: {table}.{col}")
        conn.commit()

    # ── SKU DB migration — drop+recreate if any required column missing ───────
    sku_required = [
        "sku_type", "local_storage_gb", "rdma_enabled", "gpu_count",
        "gpu_memory_gb", "confidential_compute", "vcpus_available",
        "max_uncached_disk_iops", "max_uncached_disk_mbps", "cpu_arch",
        "hyper_v_gen", "family",
    ]
    with sku_engine.connect() as conn:
        if is_postgres_sku:
            # PostgreSQL: use information_schema
            rows = conn.execute(text(
                "SELECT column_name FROM information_schema.columns WHERE table_name = 'vm_skus'"
            )).fetchall()
            existing = {r[0] for r in rows}
        else:
            # SQLite: use PRAGMA
            rows = conn.execute(text("PRAGMA table_info(vm_skus)")).fetchall()
            existing = {r[1] for r in rows}

        if existing:  # table exists — check for missing columns
            missing = [c for c in sku_required if c not in existing]
            if missing:
                print(f"✓ SKU migration: dropping vm_skus (missing: {missing})")
                conn.execute(text("DROP TABLE IF EXISTS vm_skus"))
                conn.commit()
    # Recreate outside the connection so SQLite releases the file lock
    SkuBase.metadata.create_all(bind=sku_engine)
    print("✓ SKU schema verified")

_migrate_db()

# Seed default users on startup (auth DB)
_seed_db = AuthSessionLocal()
try:
    _seed_users(_seed_db)
finally:
    _seed_db.close()

def _load_sessions_from_db():
    """On startup, warm the in-memory session cache from auth DB."""
    db = AuthSessionLocal()
    try:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
        rows = db.query(UserSession).filter(UserSession.expires_at > now).all()
        for row in rows:
            _SESSIONS[row.token] = {"username": row.username, "role": row.role}
        db.query(UserSession).filter(UserSession.expires_at <= now).delete()
        db.commit()
        if rows:
            print(f"✓ Restored {len(rows)} active sessions from auth DB")
    except Exception as e:
        print(f"Warning: could not load sessions from auth DB: {e}")
    finally:
        db.close()

_load_sessions_from_db()


# Serve shared CSS/JS from the static/ directory
if PAGES_DIR.exists():
    app.mount("/static", StaticFiles(directory=PAGES_DIR), name="static")

# Serve icons directory
_icons_dir = PAGES_DIR / "icons"
if _icons_dir.exists():
    app.mount("/icons", StaticFiles(directory=_icons_dir), name="icons")

def _sku_family(sku: str) -> str:
    m = re.match(r"^(Standard_[A-Z]+)", sku, re.I)
    return m.group(1) if m else sku


def _derive_sku_type(raw_caps: dict) -> str:
    """
    Derive the Azure Portal 'Type' column from raw Azure capability key-value pairs.
    Uses only values returned directly by the Azure Compute SKUs API — no hardcoded
    family-name assumptions.

    Azure capability keys used:
      RdmaEnabled               → HPC
      GPUCount / GPUMemoryGB    → GPU (N-series, etc.)
      ConfidentialComputingType → Confidential compute
      NvmeDiskSizeInMiB         → Storage optimized (Lsv3/Lasv3 NVMe VMs)
      CpuCreditsPerHour         → Burstable (B-series)
      MemoryGB / vCPUs ratio    → Memory optimized (≥ 8 GiB/vCPU)
                                   Compute optimized (≤ 2 GiB/vCPU)
      fallback                  → General purpose
    """
    def _b(k):  return raw_caps.get(k, "False").lower() == "true"
    def _n(k):  return float(raw_caps.get(k, 0) or 0)

    if _b("RdmaEnabled"):
        return "HPC"
    if _n("GPUCount") > 0 or _n("GPUMemoryGB") > 0:
        return "GPU"
    if raw_caps.get("ConfidentialComputingType"):
        return "Confidential"
    if _n("NvmeDiskSizeInMiB") > 0:
        return "Storage optimized"
    if _n("CpuCreditsPerHour") > 0:
        return "Burstable"

    vcpus = _n("vCPUs")
    mem   = _n("MemoryGB")
    if vcpus > 0:
        ratio = mem / vcpus
        if ratio >= 8:
            return "Memory optimized"
        if ratio <= 2:
            return "Compute optimized"

    return "General purpose"


def _build_sku_map(db, region: str = None) -> dict:
    """
    Load SKU data from the vm_skus table and return a dict keyed by sku_name.
    Shape: {sku_name: {"sku": str, "cpu": int, "mem_gb": float, "price": float}}
    price is monthly (price_linux_hr * 730).
    If region is given, prefer rows for that region; fallback to any region for
    SKUs not found in the target region.
    Returns {} on schema errors (stale DB) so callers degrade gracefully.
    """
    try:
        q = db.query(VmSku).filter(
            VmSku.vcpus.isnot(None),
            VmSku.memory_gb.isnot(None),
        )
        rows = q.all()
    except Exception as e:
        print(f"_build_sku_map: DB error (stale schema?) — {e}")
        return {}
    if not rows:
        return {}

    # Build map: prefer region-specific row, fall back to first seen
    sku_map: dict = {}
    for row in rows:
        entry = {
            "sku":    row.sku_name,
            "cpu":    row.vcpus or 0,
            "mem_gb": row.memory_gb or 0.0,
            "price":  round((row.price_linux_hr or 0.0) * 730, 2),
        }
        if row.sku_name not in sku_map:
            sku_map[row.sku_name] = entry
        elif region and row.region == region:
            sku_map[row.sku_name] = entry  # prefer target region
    return sku_map


def recommend_sku(current_sku: str, cpu_alloc: float,
                  cpu_avg_pct: float, mem_avg_pct: float,
                  sku_map: dict = None) -> Optional[dict]:
    """
    Return the best cheaper SKU in the same family that still fits usage,
    or None if the current SKU is already optimal.
    sku_map: dict built by _build_sku_map(); if None the function is a no-op.
    """
    if not sku_map:
        return None
    cur = sku_map.get(current_sku)
    if not cur or cur["price"] <= 0:
        return None

    family   = _sku_family(current_sku)
    cpu_used = cpu_alloc * (cpu_avg_pct / 100)
    mem_need = cur["mem_gb"] * (mem_avg_pct / 100)

    best = None
    for s in sku_map.values():
        if _sku_family(s["sku"]) != family:
            continue
        if s["price"] >= cur["price"]:
            continue
        if s["cpu"] >= cpu_used * 1.3 and s["mem_gb"] >= mem_need * 1.3:
            if best is None or s["price"] < best["price"]:
                best = s
    return best


def calc_confidence(cpu_avg_pct: float, mem_avg_pct: float) -> int:
    util = max(cpu_avg_pct, mem_avg_pct)
    score = 95
    if util > 60:
        score -= 30
    elif util > 40:
        score -= 15
    return max(40, min(95, score))


# ── Background metric fetch ────────────────────────────────────────────────────
_fetch_lock      = threading.Lock()
_ai_assess_lock  = threading.Lock()
_sync_state: dict      = {"running": False, "finished_at": None, "error": None}
_ai_assess_state: dict = {"running": False, "finished_at": None, "last_count": 0, "error": None}

# In-memory live store — populated on every sync, served directly by API endpoints.
# DB is used only for AI results, status, and recommendations (persistent state).
# Seeded from DB on startup so the app is usable immediately after restart.
_LIVE: dict = {"nodes": {}, "containers": {}, "fetched_at": None}


def _seed_live_from_db():
    """Bootstrap _LIVE from DB so the app serves data immediately after restart."""
    db = SessionLocal()
    try:
        for n in db.query(Node).all():
            _LIVE["nodes"][n.node_name] = _node_dict(n)
        for c in db.query(Container).all():
            _LIVE["containers"][c.container_id] = _ctr_dict(c)
        if _LIVE["nodes"]:
            _LIVE["fetched_at"] = "db"
            print(f"  _LIVE seeded from DB: {len(_LIVE['nodes'])} nodes, {len(_LIVE['containers'])} containers")
    except Exception as e:
        print(f"  _LIVE seed failed (DB not ready?): {e}")
    finally:
        db.close()


def _run_fetch(triggered_by: str = "scheduler"):
    if not _fetch_lock.acquire(blocking=False):
        print("Fetch already running — skipping concurrent trigger")
        return
    _sync_state["running"] = True
    _sync_state["error"] = None
    DATA_WRITE_LOCK.acquire()   # serialise against _sync_vm_skus / _recalculate
    if not GRAFANA_URL or not GRAFANA_TOKEN:
        DATA_WRITE_LOCK.release()
        _fetch_lock.release()
        _sync_state["running"] = False
        print("Fetch skipped — GRAFANA_URL / GRAFANA_TOKEN not set")
        return
    db = SessionLocal()
    log = FetchLog(started_at=datetime.now(timezone.utc))
    db.add(log)
    db.commit()
    try:
        datasources = gf.list_mimir_datasources(GRAFANA_URL, GRAFANA_TOKEN)
        nodes_count = ctrs_count = 0
        now = datetime.now(timezone.utc)

        # One-time migration: remove stale "namespace/container" entries that
        # no longer have a cluster prefix (old format). Only delete if a
        # cluster-prefixed replacement already exists for the same container.
        from sqlalchemy import text as _sql_text
        old_fmt = db.execute(
            _sql_text("SELECT container_id FROM containers WHERE container_id NOT LIKE '%|%'")
        ).fetchall()
        if old_fmt:
            old_ids   = [r[0] for r in old_fmt]
            all_new   = set(r[0] for r in db.execute(
                _sql_text("SELECT container_id FROM containers WHERE container_id LIKE '%|%'")
            ).fetchall())
            # Extract the ns/ct suffix from new-format IDs for comparison
            new_suffixes = {cid.split("|", 1)[1] for cid in all_new if "|" in cid}
            to_delete = [oid for oid in old_ids if oid in new_suffixes]
            if to_delete:
                db.query(Container).filter(Container.container_id.in_(to_delete)).delete(synchronize_session=False)
                db.commit()
                print(f"  Cleaned up {len(to_delete)} old-format container records (replaced by cluster-prefixed entries)")

        # Pre-load existing PKs so cross-datasource duplicates are handled
        # without relying on db.flush() (which breaks the session on conflict).
        seen_nodes: set = set(r[0] for r in db.query(Node.node_name).all())
        seen_ctrs: set  = set(r[0] for r in db.query(Container.container_id).all())

        # Load SKU catalogue from the dedicated SKU DB
        _sku_db = SkuSessionLocal()
        try:
            sku_map = _build_sku_map(_sku_db)
        finally:
            _sku_db.close()
        if not sku_map:
            print("Warning: vm_skus table is empty — run SKU sync first for recommendations")

        for ds in datasources:
            # ── Nodes ──
            try:
                raw_nodes = gf.fetch_node_metrics(GRAFANA_URL, GRAFANA_TOKEN, ds)
                for n in raw_nodes:
                    sku = n.get("current_sku") or ""
                    pod_max = n.get("pod_count_30d_max", None)
                    # Only mark as empty (SCALE_DOWN candidate) when:
                    # 1. pod count is explicitly 0 (not just missing), AND
                    # 2. CPU and memory are both near-zero — confirms truly idle, not a Prometheus gap
                    # This prevents false SCALE_DOWN on nodes that have daemonsets or workloads
                    # but whose kube_pod_info was momentarily empty during the scrape.
                    cpu_avg = n.get("cpu_avg_pct", 0) or 0
                    mem_avg = n.get("mem_avg_pct", 0) or 0
                    empty_node = (pod_max is not None and pod_max == 0
                                  and cpu_avg < 5.0 and mem_avg < 5.0)
                    cur_s = sku_map.get(sku, {})
                    existing = db.query(Node).filter(Node.node_name == n["node_name"]).first()
                    # Preserve existing AI rec unless: node is now empty (→ SCALE_DOWN),
                    # or existing rec was SCALE_DOWN but node is no longer empty (→ clear it).
                    if empty_node:
                        keep_rec = "SCALE_DOWN"
                    elif existing and existing.rec_sku == "SCALE_DOWN":
                        keep_rec = None  # node has pods again — clear stale SCALE_DOWN
                    else:
                        keep_rec = existing.rec_sku if existing else None
                    fields = {
                        "cluster": n["cluster"], "nodepool": n["nodepool"],
                        "region": n["region"], "current_sku": sku,
                        "rec_sku": keep_rec,
                        "cpu_alloc": n["cpu_alloc"], "mem_alloc_gb": n["mem_alloc_gb"],
                        "cpu_avg_pct": n["cpu_avg_pct"], "cpu_max_pct": n["cpu_max_pct"],
                        "mem_avg_pct": n["mem_avg_pct"], "mem_max_pct": n["mem_max_pct"],
                        "cpu_avg_cores": n["cpu_avg_cores"], "cpu_max_cores": n["cpu_max_cores"],
                        "mem_avg_gb": n["mem_avg_gb"], "mem_max_gb": n["mem_max_gb"],
                        "current_price": cur_s.get("price", 0),
                        "rec_price": 0 if empty_node else (existing.rec_price if existing else None),
                        "saving": cur_s.get("price", 0) if empty_node else (existing.saving or 0 if existing else 0),
                        "saved_pct": 100.0 if empty_node else (existing.saved_pct or 0.0 if existing else 0.0),
                        "confidence": 95 if empty_node else calc_confidence(n["cpu_avg_pct"], n["mem_avg_pct"]),
                        "pod_count_30d_max": pod_max,
                        "last_fetched_at": now,
                    }
                    # Update in-memory live store immediately
                    node_name = n["node_name"]
                    _LIVE["nodes"][node_name] = {
                        "node_name": node_name,
                        **fields,
                        "last_fetched_at": now.isoformat(),
                        # Preserve AI/status from DB or previous live entry
                        "status":    (existing.status if existing else None) or "pending",
                        "ai_reason": existing.ai_reason if existing else None,
                        "ai_verdict": existing.ai_verdict if existing else None,
                        "ai_assessed_at": existing.ai_assessed_at.isoformat() if existing and existing.ai_assessed_at else None,
                    }
                    if node_name in seen_nodes:
                        existing = db.query(Node).filter(Node.node_name == node_name).first()
                        if existing:
                            for k, v in fields.items():
                                setattr(existing, k, v)
                    else:
                        db.add(Node(node_name=node_name, **fields))
                        seen_nodes.add(node_name)
                    nodes_count += 1
                db.commit()  # commit nodes per datasource — releases SQLite write lock
            except Exception as e:
                db.rollback()
                print(f"  Node fetch error ({ds['name']}): {e}")

            # ── Containers ──
            try:
                raw_ctrs = gf.fetch_container_metrics(GRAFANA_URL, GRAFANA_TOKEN, ds)
                for c in raw_ctrs:
                    cid = c["container_id"]
                    fields = {k: v for k, v in c.items() if k != "container_id"}
                    fields["last_fetched_at"] = now
                    # Update in-memory live store immediately (before DB commit)
                    existing_live = _LIVE["containers"].get(cid, {})
                    _LIVE["containers"][cid] = {
                        **c,
                        "last_fetched_at": now.isoformat(),
                        # Preserve AI/status from previous live entry or defaults
                        "status":           existing_live.get("status", "pending"),
                        "ai_reason":        existing_live.get("ai_reason"),
                        "ai_verdict":       existing_live.get("ai_verdict"),
                        "ai_assessed_at":   existing_live.get("ai_assessed_at"),
                        "rec_cpu_request":  existing_live.get("rec_cpu_request"),
                        "rec_cpu_limit":    existing_live.get("rec_cpu_limit"),
                        "rec_mem_request_mib": existing_live.get("rec_mem_request_mib"),
                        "rec_mem_limit_mib":   existing_live.get("rec_mem_limit_mib"),
                    }
                    if cid in seen_ctrs:
                        existing = db.query(Container).filter(
                            Container.container_id == cid).first()
                        if existing:
                            # Refresh AI/status in live store from DB
                            _LIVE["containers"][cid]["status"]           = existing.status or "pending"
                            _LIVE["containers"][cid]["ai_reason"]        = existing.ai_reason
                            _LIVE["containers"][cid]["ai_verdict"]       = existing.ai_verdict
                            _LIVE["containers"][cid]["rec_cpu_request"]  = existing.rec_cpu_request
                            _LIVE["containers"][cid]["rec_cpu_limit"]    = existing.rec_cpu_limit
                            _LIVE["containers"][cid]["rec_mem_request_mib"] = existing.rec_mem_req
                            _LIVE["containers"][cid]["rec_mem_limit_mib"]   = existing.rec_mem_lim
                            for k, v in fields.items():
                                setattr(existing, k, v)
                    else:
                        db.add(Container(container_id=cid, **fields))
                        seen_ctrs.add(cid)
                    ctrs_count += 1
                _LIVE["fetched_at"] = now.isoformat()
                db.commit()  # commit containers per datasource — releases SQLite write lock
            except Exception as e:
                db.rollback()
                print(f"  Container fetch error ({ds['name']}): {e}")
        log.finished_at = datetime.now(timezone.utc)
        log.nodes_upserted = nodes_count
        log.ctrs_upserted = ctrs_count
        db.add(ActionHistory(
            entity_type="system",
            entity_name="grafana-sync",
            action="fetched",
            performed_by=triggered_by,
            details={"nodes": nodes_count, "containers": ctrs_count},
        ))
        db.commit()
        print(f"✓ Fetch complete — {nodes_count} nodes, {ctrs_count} containers")
    except Exception as e:
        db.rollback()
        log.error = str(e)[:2000]
        log.finished_at = datetime.now(timezone.utc)
        _sync_state["error"] = str(e)[:200]
        db.commit()
        print(f"Fetch error: {e}")
    finally:
        _sync_state["running"] = False
        _sync_state["finished_at"] = datetime.now(timezone.utc).isoformat()
        DATA_WRITE_LOCK.release()
        _fetch_lock.release()
        db.close()


# ── Azure VM SKU Sync ──────────────────────────────────────────────────────────
_sku_sync_lock = threading.Lock()

# ── Token caching: fetch Managed Identity token once, reuse for all API calls ────
_azure_token_cache: dict = {"token": None, "expires_at": 0, "lock": threading.Lock()}
_AZURE_TOKEN_TTL_SECONDS = 55 * 60  # 55 minutes (Azure tokens valid for 60 min)

def _get_azure_token() -> str:
    """
    Obtain an Azure Management token with caching. Three strategies in priority order:

    1. App Service Managed Identity  — uses IDENTITY_ENDPOINT + IDENTITY_HEADER
       env vars injected by Azure when a System/User-assigned MI is enabled.
    2. VM/IMDS Managed Identity      — fallback for VMs or older App Service plans.
    3. Service principal env vars    — local dev / CI fallback.

    Token is cached for 55 minutes — all endpoints share the same cached token
    to avoid repeated Managed Identity token requests.
    """
    now = time.time()

    # Check cache first (thread-safe)
    with _azure_token_cache["lock"]:
        if _azure_token_cache["token"] and _azure_token_cache["expires_at"] > now:
            print(f"[azure-auth] 🔄 Using cached token (expires in {int(_azure_token_cache['expires_at'] - now)}s)")
            return _azure_token_cache["token"]

    # Cache miss or expired — fetch new token
    resource = "https://management.azure.com/"
    print("[azure-auth] Starting token acquisition...")

    # 1. App Service Managed Identity (preferred on Azure App Service)
    identity_endpoint = os.getenv("IDENTITY_ENDPOINT", "")
    identity_header   = os.getenv("IDENTITY_HEADER", "")
    if identity_endpoint and identity_header:
        try:
            print(f"[azure-auth] Attempting App Service Managed Identity: {identity_endpoint[:50]}...")
            url = (f"{identity_endpoint}"
                   f"?api-version=2019-08-01"
                   f"&resource={urllib.parse.quote(resource)}")
            req = urllib.request.Request(
                url, headers={"X-IDENTITY-HEADER": identity_header})
            with urllib.request.urlopen(req, timeout=5) as r:
                token = json.loads(r.read().decode()).get("access_token", "")
            if token:
                print("[azure-auth] ✅ App Service Managed Identity successful")
                # Cache token with TTL
                with _azure_token_cache["lock"]:
                    _azure_token_cache["token"] = token
                    _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
                return token
        except Exception as e:
            print(f"[azure-auth] ❌ App Service MI failed: {type(e).__name__}: {e}")

    # 2. IMDS Managed Identity (VMs, older App Service plans)
    try:
        print("[azure-auth] Attempting IMDS Managed Identity: 169.254.169.254...")
        req = urllib.request.Request(
            f"http://169.254.169.254/metadata/identity/oauth2/token"
            f"?api-version=2018-02-01&resource={urllib.parse.quote(resource)}",
            headers={"Metadata": "true"},
        )
        with urllib.request.urlopen(req, timeout=3) as r:
            token = json.loads(r.read().decode()).get("access_token", "")
        if token:
            print("[azure-auth] ✅ IMDS Managed Identity successful")
            # Cache token with TTL
            with _azure_token_cache["lock"]:
                _azure_token_cache["token"] = token
                _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
            return token
    except Exception as e:
        print(f"[azure-auth] ❌ IMDS failed (expected in non-VM env): {type(e).__name__}")

    # 3. Azure CLI token (local dev — uses whichever account is logged in via `az login`)
    try:
        print("[azure-auth] Attempting Azure CLI token via 'az login'...")
        import subprocess
        result = subprocess.run(
            ["az", "account", "get-access-token", "--resource", resource, "--query", "accessToken", "-o", "tsv"],
            capture_output=True, text=True, timeout=10,
        )
        token = result.stdout.strip()
        if token and not token.startswith("ERROR"):
            print("[azure-auth] ✅ Azure CLI token successful")
            # Cache token with TTL
            with _azure_token_cache["lock"]:
                _azure_token_cache["token"] = token
                _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
            return token
        if result.stderr:
            print(f"[azure-auth] ❌ Azure CLI error: {result.stderr}")
    except Exception as e:
        print(f"[azure-auth] ❌ Azure CLI failed: {type(e).__name__}: {e}")

    # 4. Service principal — DB config first, then env vars (local dev / CI)
    tid  = _azure_db_creds.get("tenant_id")     or os.getenv("AZURE_TENANT_ID", "")
    cid  = _azure_db_creds.get("client_id")     or os.getenv("AZURE_CLIENT_ID", "")
    csec = _azure_db_creds.get("client_secret") or os.getenv("AZURE_CLIENT_SECRET", "")

    if tid or cid:
        print(f"[azure-auth] Attempting Service Principal: {cid or '(from DB)'}...")

    if not all([tid, cid, csec]):
        print("[azure-auth] ❌ No authentication method available (no creds found)")
        return ""
    try:
        body = urllib.parse.urlencode({
            "grant_type": "client_credentials",
            "client_id": cid, "client_secret": csec,
            "scope": f"{resource}.default",
        }).encode()
        req = urllib.request.Request(
            f"https://login.microsoftonline.com/{tid}/oauth2/v2.0/token",
            data=body, method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as r:
            token = json.loads(r.read().decode()).get("access_token", "")
            if token:
                print(f"[azure-auth] ✅ Service Principal successful ({cid})")
                # Cache token with TTL
                with _azure_token_cache["lock"]:
                    _azure_token_cache["token"] = token
                    _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
                return token
    except Exception as e:
        print(f"[azure-auth] ❌ Service Principal failed: {type(e).__name__}: {e}")

    print("[azure-auth] ❌ All authentication methods exhausted")
    return ""


def _get_subscription_ids(token: str) -> list:
    """Return configured subscription IDs (DB > env var > ARM API discovery)."""
    print("[azure-subs] Starting subscription lookup...")

    # Priority 1: DB config
    db_subs = [s.strip() for s in (_azure_db_creds.get("subscription_ids") or "").split(",") if s.strip()]
    if db_subs:
        print(f"[azure-subs] ✅ Found {len(db_subs)} subscription(s) from DB config")
        return db_subs

    # Priority 2: Environment variable
    if AZURE_SUBSCRIPTION_IDS:
        print(f"[azure-subs] ✅ Found {len(AZURE_SUBSCRIPTION_IDS)} subscription(s) from env var")
        return AZURE_SUBSCRIPTION_IDS

    # Priority 3: Discover via ARM API
    if not token:
        print("[azure-subs] ❌ No token available; cannot discover subscriptions via API")
        return []

    try:
        print("[azure-subs] Querying ARM API for subscriptions...")
        req = urllib.request.Request(
            "https://management.azure.com/subscriptions?api-version=2022-12-01",
            headers={"Authorization": f"Bearer {token}"},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode())
            all_subs = data.get("value", [])
            subs = [s["subscriptionId"] for s in all_subs if s.get("state") == "Enabled"]
        print(f"[azure-subs] ✅ Discovered {len(subs)} enabled subscription(s) via API")
        return subs
    except Exception as e:
        print(f"[azure-subs] ❌ API discovery failed: {type(e).__name__}: {e}")
        return []


def _get_cluster_location(cluster_name: str, token: str, sub_ids: list) -> str:
    """
    Query Azure API to find the location/region of an AKS cluster by name.
    Returns the region (e.g., 'eastus', 'westeurope') or empty string if not found.
    """
    if not token or not sub_ids or not cluster_name:
        print(f"[cluster-location] ❌ Missing inputs: cluster={bool(cluster_name)}, token={bool(token)}, subs={bool(sub_ids)}")
        return ""

    print(f"[cluster-location] Looking up cluster '{cluster_name}' across {len(sub_ids)} subscription(s)...")
    search_name_lower = cluster_name.lower()

    for sub_idx, sub_id in enumerate(sub_ids, 1):
        try:
            # Query for managed clusters in the subscription
            url = (
                f"https://management.azure.com/subscriptions/{sub_id}"
                f"/providers/Microsoft.ContainerService/managedClusters"
                f"?api-version=2024-02-01"
            )
            print(f"[cluster-location] [{sub_idx}/{len(sub_ids)}] Querying subscription {sub_id}")
            req = urllib.request.Request(
                url,
                headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE

            with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                data = json.loads(r.read().decode())
                clusters = data.get("value", [])
                print(f"[cluster-location] [{sub_idx}/{len(sub_ids)}] Found {len(clusters)} cluster(s)")

                # Show all cluster names for debugging
                if clusters:
                    all_names = [c.get("id", "").split("/")[-1] if c.get("id") else "?" for c in clusters]
                    print(f"[cluster-location] All {len(all_names)} cluster names: {sorted(all_names)}")

                for idx, cluster in enumerate(clusters):
                    cluster_id = cluster.get("id", "")
                    cluster_name_from_id = cluster_id.split("/")[-1] if cluster_id else ""
                    cluster_name_api = cluster.get("name", "")
                    cluster_name_lower = cluster_name_from_id.lower()
                    cluster_name_api_lower = cluster_name_api.lower() if cluster_name_api else ""

                    # Try matching both extracted name and direct 'name' field
                    if search_name_lower == cluster_name_lower or search_name_lower == cluster_name_api_lower:
                        location = cluster.get("location", "").lower()
                        if location:
                            print(f"[cluster-location] ✅ Found '{cluster_name}' → region '{location}'")
                            return location

                    # Debug: show when we match the search name (even if location is missing)
                    if idx < 5 and (cluster_name_lower == search_name_lower or cluster_name_api_lower == search_name_lower):
                        print(f"[cluster-location] [DEBUG] Matched '{search_name_lower}' to '{cluster_name_from_id}' but no location")

        except urllib.error.HTTPError as e:
            error_body = e.read().decode(errors="replace") if hasattr(e, 'read') else ""
            print(f"[cluster-location] ❌ Subscription {sub_id}: HTTP {e.code}")
            if e.code == 403:
                print(f"[cluster-location]    → FORBIDDEN: token may lack permissions")
            elif e.code == 404:
                print(f"[cluster-location]    → NOT FOUND: subscription or resource doesn't exist")
        except Exception as e:
            print(f"[cluster-location] ❌ Subscription {sub_id}: {type(e).__name__}: {str(e)[:100]}")
            continue

    print(f"[cluster-location] ❌ Cluster '{cluster_name}' not found in any subscription")
    return ""


def _get_sku_quota(region: str, subscription_id: str, sku_name: str, token: str) -> dict:
    """
    Query Azure API to get SKU capabilities for a specific region and SKU type.
    Returns dict with vCPUs, memory_gb, or empty dict if not found.

    Example:
      _get_sku_quota("eastus", "sub-123", "Standard_D4s_v4", token)
      → {"vcpus": 4, "memory_gb": 16}
    """
    if not token:
        print(f"[sku-quota] ❌ No token available for SKU lookup")
        return {}
    if not all([region, sku_name, subscription_id]):
        print(f"[sku-quota] ❌ Missing inputs: region={bool(region)}, sku={bool(sku_name)}, sub={bool(subscription_id)}")
        return {}

    try:
        print(f"[sku-quota] Querying {sku_name} in region '{region}'...")
        # Query Microsoft.Compute/skus for the subscription and region
        # Note: $filter must be URL-encoded as %24filter
        url = (
            f"https://management.azure.com/subscriptions/{subscription_id}"
            f"/providers/Microsoft.Compute/skus"
            f"?api-version=2021-07-01"
            f"&%24filter=resourceType%20eq%20%27virtualMachines%27"
        )
        req = urllib.request.Request(
            url,
            headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
        )
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE

        with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
            data = json.loads(r.read().decode())
            all_skus = data.get("value", [])
            print(f"[sku-quota] Retrieved {len(all_skus)} total SKUs from API")

            for sku_item in all_skus:
                # Match by SKU name
                if sku_item.get("name", "").lower() != sku_name.lower():
                    continue

                print(f"[sku-quota] Found SKU '{sku_name}', checking regions...")
                # Check if this SKU is available in the target region
                locations = [l.lower() for l in sku_item.get("locations", [])]
                if region.lower() not in locations:
                    print(f"[sku-quota] ❌ SKU '{sku_name}' not available in '{region}'. Available: {locations[:3]}...")
                    continue

                # Extract vCPUs and memory from capabilities
                caps = {c["name"]: c["value"] for c in sku_item.get("capabilities", [])}
                vcpus = int(float(caps.get("vCPUs", 0) or 0))
                memory_mb = int(float(caps.get("MemoryGB", 0) or 0))

                if vcpus > 0 or memory_mb > 0:
                    print(f"[sku-quota] ✅ {sku_name}: {vcpus} vCPUs, {memory_mb}GB memory")
                    return {
                        "vcpus": vcpus,
                        "memory_gb": memory_mb,
                    }

        print(f"[sku-quota] ❌ SKU '{sku_name}' not found or has no data")
    except Exception as e:
        print(f"[sku-quota] ❌ Query failed for {sku_name} in {region}: {type(e).__name__}: {str(e)[:100]}")

    return {}


def _parse_sku_item(sku: dict, regions_filter: set) -> dict:
    """Parse a single ARM SKU item into our capability dict. Returns {} if not applicable."""
    if sku.get("resourceType") != "virtualMachines":
        return {}
    locs = {(l or "").lower() for l in sku.get("locations", [])}
    matched = locs & regions_filter if regions_filter else locs
    if not matched:
        return {}
    caps = {c["name"]: c["value"] for c in sku.get("capabilities", [])}
    def _b(k): return 1 if caps.get(k, "False").lower() == "true" else 0
    def _i(k, d=0): return int(float(caps.get(k, d) or d))
    def _f(k, d=0.0): return float(caps.get(k, d) or d)
    _nvme_mib  = _f("NvmeDiskSizeInMiB")
    _temp_mib  = _f("MaxResourceVolumeMB")
    _local_gib = round((_nvme_mib if _nvme_mib > 0 else _temp_mib) / 1024, 1)
    rec = {
        "tier":                    sku.get("tier", "Standard"),
        "family":                  sku.get("family", ""),
        "sku_type":                _derive_sku_type(caps),
        "vcpus":                   _i("vCPUs"),
        "vcpus_available":         _i("vCPUsAvailable", _i("vCPUs")),
        "memory_gb":               _f("MemoryGB"),
        "max_data_disks":          _i("MaxDataDiskCount"),
        "max_uncached_disk_iops":  _i("UncachedDiskIOPS") or _i("MaxUncachedDiskIOPS"),
        "max_uncached_disk_mbps":  round(
            max(_f("UncachedDiskBytesPerSecond"), _f("UncachedDiskThroughput")) / (1024 * 1024), 1
        ) if (_f("UncachedDiskBytesPerSecond") > 0 or _f("UncachedDiskThroughput") > 0) else 0,
        "premium_io":              _b("PremiumIO"),
        "accelerated_networking":  _b("AcceleratedNetworkingEnabled"),
        "cpu_arch":                caps.get("CPUArchitectureType", "x64"),
        "hyper_v_gen":             caps.get("HyperVGenerations", ""),
        "max_nics":                _i("MaxNetworkInterfaces"),
        "local_storage_gb":        _local_gib,
        "rdma_enabled":            _b("RdmaEnabled"),
        "gpu_count":               _i("GPUCount"),
        "gpu_memory_gb":           _f("GPUMemoryGB"),
        "confidential_compute":    1 if caps.get("ConfidentialComputingType") else 0,
    }
    return {(sku["name"], loc): rec for loc in matched}


def _fetch_sku_capabilities(sub_ids: list, token: str, regions: list) -> dict:
    """
    Returns {(sku_name, region): {vcpus, memory_gb, iops, …}}

    Optimised: one ARM call per subscription (no per-region filter) fetches all
    VM SKUs for all locations at once, then we filter in-process.  Parallel
    across subscriptions via ThreadPoolExecutor — reduces N*M serial HTTP calls
    to N parallel calls.
    """
    regions_lower = {r.lower() for r in regions}

    def _fetch_sub(sub_id: str):
        url = (
            f"https://management.azure.com/subscriptions/{sub_id}"
            f"/providers/Microsoft.Compute/skus?api-version=2021-07-01"
            f"&$filter=resourceType+eq+%27virtualMachines%27"
        )
        items = _arm_get_all_pages(url, token, timeout=60)
        sub_result = {}
        for sku in items:
            sub_result.update(_parse_sku_item(sku, regions_lower))
        return sub_result

    result = {}
    with ThreadPoolExecutor(max_workers=min(8, len(sub_ids))) as pool:
        futures = {pool.submit(_fetch_sub, sid): sid for sid in sub_ids}
        for future in as_completed(futures):
            sub_id = futures[future]
            try:
                sub_result = future.result()
                # Union merge — first subscription wins for duplicate (sku, region) keys
                for k, v in sub_result.items():
                    if k not in result:
                        result[k] = v
            except Exception as e:
                print(f"SKU capabilities fetch failed for sub={sub_id}: {e}")
    return result


def _fetch_sku_pricing(sku_names: list, regions: list) -> dict:
    """
    Returns {(sku_name, region): {linux_hr, windows_hr}}
    Uses the public Azure Retail Prices API — no auth required.
    Fetches all regions in parallel (ThreadPoolExecutor) to cut total time from
    N*avg_latency → avg_latency.  Handles 429 with per-thread backoff.
    """
    import time
    sku_set = set(sku_names)

    def _fetch_region(region: str) -> dict:
        reg_result = {}
        filt = (
            f"serviceName eq 'Virtual Machines' "
            f"and priceType eq 'Consumption' "
            f"and armRegionName eq '{region}'"
        )
        url = (
            "https://prices.azure.com/api/retail/prices"
            f"?api-version=2023-01-01-preview"
            f"&$filter={urllib.parse.quote(filt)}"
        )
        page = 0
        while url:
            try:
                with urllib.request.urlopen(url, timeout=20) as r:
                    data = json.loads(r.read().decode())
            except urllib.error.HTTPError as e:
                if e.code == 429:
                    time.sleep(10)
                    continue
                raise
            for item in data.get("Items", []):
                sku = item.get("armSkuName", "")
                if sku not in sku_set:
                    continue
                name = item.get("skuName", "")
                if "Spot" in name or "Low Priority" in name:
                    continue
                price = item.get("retailPrice") or item.get("unitPrice")
                if price is None:
                    continue
                key = (sku, region)
                if key not in reg_result:
                    reg_result[key] = {}
                prod = item.get("productName", "")
                if "Windows" in prod:
                    reg_result[key].setdefault("windows_hr", price)
                else:
                    reg_result[key].setdefault("linux_hr", price)
            url = data.get("NextPageLink")
            page += 1
            if page > 20:
                break
        return reg_result

    result = {}
    with ThreadPoolExecutor(max_workers=min(12, len(regions))) as pool:
        futures = {pool.submit(_fetch_region, r): r for r in regions}
        for future in as_completed(futures):
            region = futures[future]
            try:
                result.update(future.result())
            except Exception as e:
                print(f"SKU pricing fetch failed for region={region}: {e}")
    return result



def _fetch_vmss_instances(token: str, sub_ids: list) -> list[dict]:
    """
    Return all VMSS instances across subscriptions with their current VM size.
    Each entry: {name, resource_group, subscription_id, location, sku_name, capacity, tags}
    Fetches all subscriptions in parallel.
    """
    raw, _ = _arm_fetch_parallel(
        sub_ids, "providers/Microsoft.Compute/virtualMachineScaleSets",
        token, "2023-07-01"
    )
    results = []
    for vmss in raw:
        sku   = vmss.get("sku", {})
        rid   = vmss.get("id", "")
        parts = rid.split("/")
        rg    = parts[parts.index("resourceGroups") + 1] if "resourceGroups" in parts else ""
        results.append({
            "name":            vmss.get("name", ""),
            "resource_group":  rg,
            "subscription_id": vmss["_sub_id"],
            "location":        vmss.get("location", ""),
            "sku_name":        sku.get("name", ""),
            "capacity":        sku.get("capacity", 0),
            "tags":            vmss.get("tags", {}),
        })
    return results


def _fetch_vmss_available_sizes(token: str, sub_id: str, rg: str, vmss_name: str) -> list[str]:
    """
    Return all VM size names available for a specific VMSS —
    exactly what the Azure Portal shows on the VMSS → Size page.
    API: /subscriptions/{sub}/resourceGroups/{rg}/providers/
         Microsoft.Compute/virtualMachineScaleSets/{name}/skus
    """
    url = (
        f"https://management.azure.com/subscriptions/{sub_id}"
        f"/resourceGroups/{rg}"
        f"/providers/Microsoft.Compute/virtualMachineScaleSets/{vmss_name}/skus"
        f"?api-version=2023-07-01"
    )
    sizes = []
    while url:
        try:
            req = urllib.request.Request(url, headers={"Authorization": f"Bearer {token}"})
            with urllib.request.urlopen(req, timeout=15) as r:
                data = json.loads(r.read().decode())
            for item in data.get("value", []):
                name = item.get("sku", {}).get("name", "")
                if name:
                    sizes.append(name)
            url = data.get("nextLink")
        except Exception as e:
            print(f"VMSS available sizes failed ({vmss_name}): {e}")
            break
    return sizes


def _sync_skus_from_vmss(token: str, sub_ids: list) -> dict:
    """
    Fetch ALL VM SKU details for every region where we have VMSS instances and
    store them all in vm_skus.  The VMSS available-sizes list is used only to
    discover which ARM regions to query — every SKU returned by the Azure Compute
    SKUs API for those regions is stored, not just the VMSS-available subset.

    Flow:
      1. List all VMSS instances → collect unique ARM locations
      2. Call ARM /providers/Microsoft.Compute/skus?$filter=location eq '...' for
         each location → get ALL SKU capabilities (vCPUs, RAM, IOPS, GPU, …)
      3. Call Azure Retail Prices API for each location → get pricing
      4. Upsert every (sku_name, region) pair into vm_skus — always overwrite so
         newly added columns are backfilled on existing rows
    """
    # 1. Collect unique ARM locations from all VMSS instances
    all_vmss = _fetch_vmss_instances(token, sub_ids)
    if not all_vmss:
        print("VMSS SKU sync: no VMSS instances found")
        return {}

    locations_seen: set = set()
    for vmss in all_vmss:
        locations_seen.add(vmss["location"].lower())

    all_locations = sorted(locations_seen)
    print(f"VMSS SKU sync: found {len(all_vmss)} VMSS instances across {len(all_locations)} regions: {all_locations}")

    # 2. Fetch ALL SKU capabilities for every location in one ARM API call per region.
    #    Returns {(sku_name, arm_region): {vcpus, memory_gb, iops, ...}} for every SKU.
    capabilities = _fetch_sku_capabilities(sub_ids, token, all_locations)
    print(f"  ARM API returned {len(capabilities)} (sku, region) capability entries")

    if not capabilities:
        print("VMSS SKU sync: no capability data returned — check Managed Identity permissions")
        return {}

    # 3. Fetch pricing for ALL SKUs in those regions (one paginated call per region).
    all_sku_names = sorted({name for name, _ in capabilities.keys()})
    pricing = _fetch_sku_pricing(all_sku_names, all_locations)
    print(f"  Pricing API returned {len(pricing)} (sku, region) price entries")

    # 4. Upsert every SKU returned by ARM into vm_skus.
    #    Group by location so we can commit per-location and avoid huge transactions.
    from collections import defaultdict
    by_location: dict = defaultdict(list)
    for (sku_name, location) in capabilities.keys():
        by_location[location].append(sku_name)

    now = datetime.now(timezone.utc)
    db = SkuSessionLocal()
    total_upserted = 0
    try:
        for location, sku_names in sorted(by_location.items()):
            loc_upserted = 0
            for sku_name in sku_names:
                cap   = capabilities.get((sku_name, location), {})
                price = pricing.get((sku_name, location), {})

                existing = db.query(VmSku).filter(
                    VmSku.sku_name == sku_name,
                    VmSku.region   == location,
                ).first()
                row = existing if existing else VmSku(sku_name=sku_name, region=location)
                if not existing:
                    db.add(row)

                for k, v in cap.items():
                    setattr(row, k, v)
                if price.get("linux_hr")   is not None: row.price_linux_hr   = price["linux_hr"]
                if price.get("windows_hr") is not None: row.price_windows_hr = price["windows_hr"]
                row.last_fetched_at = now
                loc_upserted += 1

            db.commit()
            total_upserted += loc_upserted
            print(f"  {location}: {loc_upserted} SKUs stored (total so far: {total_upserted})")

        print(f"✓ SKU sync complete — {total_upserted} SKUs stored across {len(by_location)} regions")
    except Exception as e:
        db.rollback()
        print(f"SKU sync upsert error: {e}")
        import traceback; traceback.print_exc()
    finally:
        db.close()

    return {loc: skus for loc, skus in by_location.items()}



def _sync_vm_skus(force_capabilities: bool = False):
    """
    Fetch VM SKU capabilities + pricing for all unique SKUs/regions in the
    nodes table and upsert into vm_skus. Runs every SKU_SYNC_INTERVAL_DAYS days.

    Capabilities (from file/ARM) are loaded only once — skipped if the DB already
    has capability data and force_capabilities=False.
    Pricing is always refreshed since it changes over time.
    """
    if not _sku_sync_lock.acquire(blocking=False):
        print("SKU sync already running — skipping")
        return
    SKU_WRITE_LOCK.acquire()   # serialise SKU writes; independent of DATA_WRITE_LOCK
    # Read node SKU names from data DB (read-only, no lock needed)
    _node_db = SessionLocal()
    try:
        rows = _node_db.query(Node.current_sku, Node.rec_sku, Node.region).all()
    finally:
        _node_db.close()
    db = SkuSessionLocal()
    try:
        print("▶ Starting VM SKU sync…")
        # Discover unique SKUs + regions from nodes table
        sku_names = sorted({s for r in rows for s in (r.current_sku, r.rec_sku) if s})
        regions   = sorted({r.region for r in rows if r.region})
        if not sku_names or not regions:
            print("SKU sync: no nodes found — nothing to sync")
            return
        print(f"SKU sync: {len(sku_names)} SKUs × {len(regions)} regions")

        # Check if capabilities are already loaded in SKU DB
        cap_count = db.query(VmSku).filter(VmSku.vcpus.isnot(None)).count()
        capabilities_already_loaded = cap_count > 0 and not force_capabilities

        # 1. Load capabilities (skipped if already in DB)
        capabilities = {}
        if capabilities_already_loaded:
            print(f"SKU sync: capabilities already in DB ({cap_count} entries) — skipping file load")
        else:
            # Try ARM API first, then local file
            token = _get_azure_token()
            if token:
                sub_ids = _get_subscription_ids(token)
                if sub_ids:
                    print(f"SKU sync: querying {len(sub_ids)} subscription(s)")
                    capabilities = _fetch_sku_capabilities(sub_ids, token, regions)
                    print(f"SKU sync: got capabilities for {len(capabilities)} combos")

            if not capabilities:
                print("SKU sync: no capabilities from Azure ARM — capabilities will be empty")

        # Map node display regions → ARM region keys used in capabilities dict
        # e.g. "Australia" → "australiaeast", "UAE" → "uaenorth"
        _cap_regions = {r for _, r in capabilities.keys()} if capabilities else set()

        def _arm_region(display: str) -> str:
            dl = display.lower()
            if dl in _cap_regions:
                return dl
            # prefix match: "australia" → "australiacentral"
            matches = sorted(r for r in _cap_regions if r.startswith(dl))
            if matches:
                return matches[0]
            # contains match: "europe" → "westeurope", "us" → "eastus"
            matches = sorted(r for r in _cap_regions if dl in r)
            return matches[0] if matches else dl

        region_arm = {r: _arm_region(r) for r in regions}
        arm_regions = sorted(set(region_arm.values()))
        print(f"SKU sync: region mapping {region_arm}")

        # 2. Get pricing from public Retail Prices API (always)
        pricing = _fetch_sku_pricing(sku_names, arm_regions)
        print(f"SKU sync: got pricing for {len(pricing)} combos")

        # 3. Upsert into vm_skus — use ARM region as the storage key
        now = datetime.now(timezone.utc)
        upserted = 0
        for sku in sku_names:
            for region in regions:
                arm = region_arm.get(region, region.lower())
                cap   = capabilities.get((sku, arm), {})
                price = pricing.get((sku, arm), {})
                if not cap and not price:
                    continue
                existing = (
                    db.query(VmSku)
                    .filter(VmSku.sku_name == sku, VmSku.region == arm)
                    .first()
                )
                if existing:
                    row = existing
                else:
                    row = VmSku(sku_name=sku, region=arm)
                    db.add(row)
                for k, v in cap.items():
                    setattr(row, k, v)
                if price.get("linux_hr")   is not None: row.price_linux_hr   = price["linux_hr"]
                if price.get("windows_hr") is not None: row.price_windows_hr = price["windows_hr"]
                row.last_fetched_at = now
                upserted += 1
        db.commit()
        print(f"✓ SKU sync complete — {upserted} rows upserted")
        # After SKU sync, backfill recommendations for existing nodes
        if upserted > 0:
            threading.Thread(target=_recalculate_node_recommendations, daemon=True).start()
    except Exception as e:
        print(f"SKU sync error: {e}")
        db.rollback()
    finally:
        SKU_WRITE_LOCK.release()
        _sku_sync_lock.release()
        db.close()


def _recalculate_node_recommendations():
    """Refresh current_price for all nodes after SKU sync. SKU recommendations are AI-only."""
    sku_db = SkuSessionLocal()
    try:
        sku_map = _build_sku_map(sku_db)
    finally:
        sku_db.close()
    if not sku_map:
        print("Recalculate: SKU map still empty — skipping")
        return
    db = SessionLocal()
    try:
        nodes = db.query(Node).all()
        updated = 0
        for n in nodes:
            sku   = n.current_sku or ""
            cur_s = sku_map.get(sku, {})
            # Only update current_price; rec_sku/rec_price/saving are set by AI assess only.
            n.current_price = cur_s.get("price", 0)
            # Recalculate saving/saved_pct if AI already set a rec_sku and we now have fresh pricing
            if n.rec_sku and n.rec_sku not in ("SCALE_DOWN",):
                rec_s = sku_map.get(n.rec_sku, {})
                if rec_s.get("price") is not None:
                    n.rec_price = rec_s["price"]
                    n.saving    = max(0, (cur_s.get("price") or 0) - rec_s["price"])
                    n.saved_pct = (n.saving / cur_s["price"] * 100) if cur_s.get("price") else 0
            updated += 1
        db.commit()
        print(f"✓ Updated current_price for {updated} nodes from fresh SKU data")
    except Exception as e:
        db.rollback()
        print(f"Recalculate error: {e}")
    finally:
        db.close()


def _run_ai_assess_all_nodes():
    """Scheduled job: assess all nodepools as units every hour.
    All nodes in a pool share the same VM SKU — assess at pool level, not per-node."""
    key = OPENAI_KEY or os.environ.get("OPENAI_KEY")
    if not key:
        print("Auto-assess: OPENAI_KEY not configured — skipping")
        return
    if not _ai_assess_lock.acquire(blocking=False):
        print("Auto-assess: already running — skipping")
        return
    _ai_assess_state["running"] = True
    _ai_assess_state["error"]   = None
    try:
        list_db = SessionLocal()
        try:
            all_nodes = list_db.query(Node).all()
        finally:
            list_db.close()

        if not all_nodes:
            print("Auto-assess: no nodes found — skipping")
            return

        # Group by (cluster, nodepool) — assess each pool as a unit
        pool_map: dict[tuple, list] = {}
        for n in all_nodes:
            key_t = (n.cluster or "", n.nodepool or "")
            if key_t not in pool_map:
                pool_map[key_t] = []
            pool_map[key_t].append(n)

        # Prioritise workload pools; infra/default pools last
        _INFRA_POOL_KEYWORDS = ("infra", "default", "system", "agentpool")
        def _is_infra_pool(k):
            return any(w in k[1].lower() for w in _INFRA_POOL_KEYWORDS)

        workload_pools = [(k, v) for k, v in pool_map.items() if not _is_infra_pool(k)]
        infra_pools    = [(k, v) for k, v in pool_map.items() if _is_infra_pool(k)]
        ordered_pools  = workload_pools + infra_pools

        print(f"Auto-assess: {len(workload_pools)} workload pools, {len(infra_pools)} infra pools")
        success = 0
        for (cluster, nodepool), _ in ordered_pools:
            pool_db = SessionLocal()
            try:
                assess_nodepool(
                    body=AssessPoolBody(cluster=cluster, nodepool=nodepool, performed_by="scheduler"),
                    db=pool_db
                )
                success += 1
                print(f"  ✓ pool assessed: {cluster}/{nodepool}")
            except HTTPException:
                pass
            except Exception as e:
                print(f"  ✗ pool assess failed {cluster}/{nodepool}: {e}")
                try: pool_db.rollback()
                except Exception: pass
            finally:
                pool_db.close()

        _ai_assess_state["last_count"]  = success
        _ai_assess_state["finished_at"] = datetime.now(timezone.utc).isoformat()
        print(f"Auto-assess complete: {success}/{len(ordered_pools)} pools assessed")
    except Exception as e:
        _ai_assess_state["error"] = str(e)
        print(f"Auto-assess failed: {e}")
    finally:
        _ai_assess_state["running"] = False
        _ai_assess_lock.release()


scheduler = BackgroundScheduler()


def _run_sku_sync():
    """Refresh SKU pricing every 15 days (scheduled job)."""
    try:
        print("[scheduler/sku-sync] Starting SKU sync…")
        _sync_vm_skus()
        print("[scheduler/sku-sync] SKU sync complete")
    except Exception as e:
        print(f"[scheduler/sku-sync] ERROR: {e}")


# ── Scheduled jobs (replaces Azure WebJobs — no AzureWebJobsStorage required) ──

def _run_webjob2():
    """Collect Grafana metrics every 6 hours, bulk-upsert to DB, trigger prescorer."""
    try:
        import webjob2_collector as wj2
        wj2.run()
    except Exception as e:
        print(f"[scheduler/wj2] ERROR: {e}")


def _run_webjob3():
    """Check DB flag every 15 min; prescore pools + GPT for critical ones."""
    try:
        import webjob3_prescorer as wj3
        wj3.run()          # exits immediately if flag not set — very lightweight
    except Exception as e:
        print(f"[scheduler/wj3] ERROR: {e}")


def _run_webjob4():
    """Check DB flag every 5 min; dispatch alerts to DB (+ Teams/SMTP when configured)."""
    try:
        import webjob4_alerter as wj4
        wj4.run()          # exits immediately if flag not set — very lightweight
    except Exception as e:
        print(f"[scheduler/wj4] ERROR: {e}")


_QUOTA_ALERT_WARN     = 60   # % used → warning
_QUOTA_ALERT_CRITICAL = 90   # % used → critical

# Display region name → ARM region name (same mapping as nodes.html regionMap)
_REGION_ARM_MAP: dict[str, str] = {
    "canada":        "canadacentral",
    "us":            "eastus",
    "europe":        "westeurope",
    "uk":            "uksouth",
    "asia":          "southeastasia",
    "australia":     "australiaeast",
    "germany":       "germanywestcentral",
    "norway":        "norwayeast",
    "uae":           "uaenorth",
    "uaenorth":      "uaenorth",
    "india":         "centralindia",
    "japan":         "japaneast",
    "brazil":        "brazilsouth",
    "france":        "francecentral",
    "sweden":        "swedencentral",
    "switzerland":   "switzerlandnorth",
    "korea":         "koreacentral",
    "southafrica":   "southafricanorth",
}


def _to_arm_region(display: str) -> str:
    """Map a display/short region name to an Azure ARM location name."""
    loc = display.lower().strip().replace(" ", "")
    return _REGION_ARM_MAP.get(loc, loc)


def _run_quota_alerts():
    """
    Every hour: write/update Alert rows for vCPU quota families at ≥60% or ≥90%.
    Resolves existing quota alerts automatically when usage drops below warn threshold.
    All Azure API calls are delegated to _refresh_quota_cache — this function only
    reads from _quota_cache (zero direct Azure calls).
    """
    db = SessionLocal()
    try:
        token = _get_azure_token()
        if not token:
            return  # Azure not configured — skip silently

        # Collect unique (sub_id, location) pairs from node records
        from sqlalchemy import distinct as _distinct
        regions_in_db = [r[0] for r in
                         db.query(_distinct(Node.region)).filter(Node.region.isnot(None)).all()
                         if r[0]]
        sub_ids = _get_subscription_ids(token)  # called once
        pairs: set[tuple] = set()
        for display_loc in regions_in_db:
            arm_loc = _to_arm_region(display_loc)
            if arm_loc and sub_ids:
                pairs.add((sub_ids[0], arm_loc))

        if not pairs:
            return

        now    = datetime.now(timezone.utc)
        now_ts = time.time()

        # Check if any location is missing or stale in the shared cache
        with _quota_cache_lock:
            cache_snapshot = dict(_quota_cache)

        needs_refresh = any(
            pair not in cache_snapshot
            or (now_ts - cache_snapshot[pair].get("fetched_at", 0)) > _QUOTA_TTL_SECONDS
            for pair in pairs
        )
        if needs_refresh:
            # Single consolidated refresh — fetches all locations in parallel
            _refresh_quota_cache()
            with _quota_cache_lock:
                cache_snapshot = dict(_quota_cache)

        # Build results list from cache only — no direct Azure calls
        quota_results = []
        for (sub_id, location) in pairs:
            entry = cache_snapshot.get((sub_id, location))
            if entry:
                quota_results.append((sub_id, location, entry.get("usages", []), None))
            else:
                quota_results.append((sub_id, location, [], f"no cache entry for {location}"))

        for sub_id, location, raw_usages, fetch_err in quota_results:
            if fetch_err:
                print(f"[quota-alerts] {sub_id}/{location}: {fetch_err}")
                continue
            for u in raw_usages:
                fam   = u.get("name", {}).get("value", "")
                local = u.get("name", {}).get("localizedValue", fam)
                cur   = u.get("currentValue", 0)
                lim   = u.get("limit", 0)
                if not lim or not fam:
                    continue
                pct = round(cur / lim * 100, 1)
                entity = f"{fam} / {location} / {sub_id[:8]}…"

                if pct >= _QUOTA_ALERT_CRITICAL:
                    sev, title = "critical", f"vCPU Quota Critical: {local}"
                    msg = (f"{local} quota at {pct}% ({cur}/{lim} vCPUs) "
                           f"in {location}. Approaching hard limit — new VMs will be blocked.")
                elif pct >= _QUOTA_ALERT_WARN:
                    sev, title = "warning", f"vCPU Quota High: {local}"
                    msg = (f"{local} quota at {pct}% ({cur}/{lim} vCPUs) "
                           f"in {location}. Request a quota increase proactively.")
                else:
                    existing = db.query(Alert).filter(
                        Alert.entity_type == "quota",
                        Alert.entity_name == entity,
                        Alert.status      == "open",
                    ).first()
                    if existing:
                        existing.status      = "resolved"
                        existing.resolved_at = now
                        db.commit()
                    continue

                existing = db.query(Alert).filter(
                    Alert.entity_type == "quota",
                    Alert.entity_name == entity,
                    Alert.status      == "open",
                ).first()
                if existing:
                    existing.severity   = sev
                    existing.title      = title
                    existing.message    = msg
                    existing.updated_at = now
                else:
                    db.add(Alert(
                        title        = title,
                        message      = msg,
                        severity     = sev,
                        entity_type  = "quota",
                        entity_name  = entity,
                        cluster      = location,
                        status       = "open",
                        triggered_by = "quota-monitor",
                    ))
                db.commit()

    except Exception as e:
        print(f"[quota-alerts] ERROR: {e}")
    finally:
        db.close()


def _startup_background():
    """Run initial fetch + SKU sync sequentially at app start."""
    node_db = SessionLocal()
    sku_db  = SkuSessionLocal()
    try:
        no_nodes = not node_db.query(Node).first()
        no_skus  = not sku_db.query(VmSku).first()
    finally:
        node_db.close()
        sku_db.close()

    if no_nodes:
        # No nodes in DB — trigger webjob2 to run immediately (or run inline for local dev)
        print("Startup: no nodes — hint: run `python webjob2_collector.py` to populate DB")

    if no_skus:
        print("Startup: no SKUs in DB — fetching all VMSS available sizes from Azure…")
        token = _get_azure_token()
        if token:
            sub_ids = _get_subscription_ids(token)
            if sub_ids:
                _sync_skus_from_vmss(token, sub_ids)
                print("Startup: VMSS SKU sync complete")
                return
        # Fallback: sync only SKUs referenced by nodes (Azure token not available)
        print("Startup: Azure token unavailable — falling back to node-based SKU sync")
        _sync_vm_skus()


def _clean_bad_rec_skus():
    """Remove garbage rec_sku values left by old AI responses (e.g. '**', 'NONE', malformed)."""
    _VALID_REC = re.compile(r"^Standard_[A-Za-z0-9_]+$")
    db = SessionLocal()
    try:
        nodes = db.query(Node).filter(Node.rec_sku.isnot(None)).all()
        cleaned = 0
        for n in nodes:
            if n.rec_sku in ("SCALE_DOWN", "KEEP_CURRENT"):
                continue
            if not _VALID_REC.match(n.rec_sku):
                print(f"  [startup] clearing bad rec_sku {n.rec_sku!r} on {n.node_name}")
                n.rec_sku   = None
                n.rec_price = None
                n.saving    = 0
                n.saved_pct = 0
                cleaned += 1
        if cleaned:
            db.commit()
            print(f"  [startup] cleared {cleaned} bad rec_sku values")
    except Exception as e:
        print(f"  [startup] rec_sku cleanup failed: {e}")
    finally:
        db.close()


@app.on_event("startup")
def on_startup():
    _load_azure_db_creds()  # warm Azure credential cache from DB
    _clean_bad_rec_skus()   # remove stale garbage rec_sku values from old AI runs
    _seed_live_from_db()    # warm _LIVE from DB before accepting requests

    # Schedule the pipeline jobs (replaces Azure WebJobs runtime)
    scheduler.add_job(_run_webjob2, "interval", hours=6,   id="wj2_collector",
                      max_instances=1, coalesce=True)
    scheduler.add_job(_run_webjob3, "interval", minutes=15, id="wj3_prescorer",
                      max_instances=1, coalesce=True)
    scheduler.add_job(_run_webjob4, "interval", minutes=5,  id="wj4_alerter",
                      max_instances=1, coalesce=True)
    scheduler.add_job(_run_quota_alerts, "interval", hours=1, id="quota_alerts",
                      max_instances=1, coalesce=True)
    scheduler.add_job(_refresh_disks_cache, "interval", seconds=_RESOURCE_CACHE_TTL,
                      id="disks_cache", max_instances=1, coalesce=True)
    scheduler.add_job(_refresh_snapshots_cache, "interval", seconds=_RESOURCE_CACHE_TTL,
                      id="snapshots_cache", max_instances=1, coalesce=True)
    scheduler.add_job(_refresh_quota_cache, "interval", seconds=_RESOURCE_CACHE_TTL,
                      id="quota_cache", max_instances=1, coalesce=True)
    scheduler.add_job(_run_sku_sync, "interval", hours=SKU_SYNC_INTERVAL_DAYS*24, id="sku_sync",
                      max_instances=1, coalesce=True)

    scheduler.start()
    threading.Thread(target=_startup_background, daemon=True).start()
    # Warm caches at startup so dashboard shows data immediately on first load
    threading.Thread(target=_refresh_quota_cache,     daemon=True).start()
    threading.Thread(target=_refresh_disks_cache,     daemon=True).start()
    threading.Thread(target=_refresh_snapshots_cache, daemon=True).start()


@app.on_event("shutdown")
def on_shutdown():
    scheduler.shutdown()


# ── Multi-page HTML routes ────────────────────────────────────────────────────
def _page(name: str):
    """Return the HTML page from the static/ directory."""
    path = PAGES_DIR / name
    if not path.exists():
        raise HTTPException(404, f"{name} not found")
    return FileResponse(path)


@app.get("/", include_in_schema=False)
@app.get("/dashboard", include_in_schema=False)
@app.get("/index.html", include_in_schema=False)
def serve_index():
    return _page("index.html")


@app.get("/nodes", include_in_schema=False)
@app.get("/nodes.html", include_in_schema=False)
def serve_nodes():
    return _page("nodes.html")


@app.get("/containers", include_in_schema=False)
@app.get("/containers.html", include_in_schema=False)
def serve_containers():
    return _page("containers.html")


@app.get("/history", include_in_schema=False)
@app.get("/history.html", include_in_schema=False)
def serve_history():
    return _page("history.html")


@app.get("/login", include_in_schema=False)
@app.get("/login.html", include_in_schema=False)
def serve_login():
    return _page("login.html")


@app.get("/architecture", include_in_schema=False)
@app.get("/architecture.html", include_in_schema=False)
def serve_architecture():
    return _page("architecture.html")


@app.get("/policy", include_in_schema=False)
@app.get("/policy.html", include_in_schema=False)
def serve_policy():
    return _page("policy.html")


@app.get("/alerts", include_in_schema=False)
@app.get("/alerts.html", include_in_schema=False)
def serve_alerts():
    return _page("alerts.html")


@app.get("/common.css", include_in_schema=False)
def serve_common_css():
    r = _page("common.css")
    r.headers["Cache-Control"] = "no-cache, must-revalidate"
    return r


@app.get("/common.js", include_in_schema=False)
def serve_common_js():
    r = _page("common.js")
    r.headers["Cache-Control"] = "no-cache, must-revalidate"
    return r


# ── Catch-all: serve any .html page that exists in PAGES_DIR ─────────────────
# This is a fallback that ensures all pages are accessible regardless of whether
# a specific named route is registered.
@app.get("/{page_name}.html", include_in_schema=False)
def serve_any_html(page_name: str):
    return _page(f"{page_name}.html")


# ── Auth endpoints ─────────────────────────────────────────────────────────────
class LoginBody(BaseModel):
    username: str
    password: str

@app.post("/api/auth/login")
def auth_login(body: LoginBody, db: Session = Depends(get_auth_db)):
    user = db.query(User).filter(User.username == body.username).first()
    if not user or user.password_hash != _hash_pw(body.password):
        raise HTTPException(401, "Invalid username or password")
    expires_ts = int(time.time()) + SESSION_TTL_DAYS * 86400
    token = _sign_token(user.username, user.role, expires_ts)
    sess = {"username": user.username, "role": user.role}
    _SESSIONS[token] = sess  # warm in-memory cache for same-instance fast path
    # Also persist to DB for audit / logout invalidation
    try:
        expires_dt = datetime.utcnow() + timedelta(days=SESSION_TTL_DAYS)
        db.add(UserSession(token=token[:64], username=user.username, role=user.role, expires_at=expires_dt))
        db.query(UserSession).filter(
            UserSession.username == user.username,
            UserSession.expires_at < datetime.utcnow()
        ).delete()
        db.commit()
    except Exception as _e:
        print(f"[auth] session DB write failed (non-fatal): {_e}")
    return {"token": token, "username": user.username, "role": user.role}

@app.get("/api/auth/me")
def auth_me(session: dict = Depends(_get_session)):
    return session

@app.post("/api/auth/logout")
def auth_logout(x_auth_token: str = Header(None), db: Session = Depends(get_auth_db)):
    token = x_auth_token or ""
    _SESSIONS.pop(token, None)
    db.query(UserSession).filter(UserSession.token == token[:64]).delete()
    db.commit()
    return {"ok": True}


# ── Policies ──────────────────────────────────────────────────────────────────
def _policy_dict(p: Policy) -> dict:
    return {
        "id": p.id, "name": p.name, "description": p.description,
        "enabled": bool(p.enabled), "min_confidence": p.min_confidence,
        "min_savings": p.min_savings, "max_risk": p.max_risk,
        "category_mode": p.category_mode, "cluster_filter": p.cluster_filter,
        "auto_approve": bool(p.auto_approve), "created_by": p.created_by,
        "created_at": p.created_at.isoformat() if p.created_at else None,
        "updated_at": p.updated_at.isoformat() if p.updated_at else None,
        "last_run_at": p.last_run_at.isoformat() if p.last_run_at else None,
        "last_run_count": p.last_run_count,
    }

class PolicyBody(BaseModel):
    name: str
    description: Optional[str] = None
    enabled: bool = False
    min_confidence: int = 85
    min_savings: float = 50
    max_risk: str = "low"
    category_mode: str = "efficiency"
    cluster_filter: Optional[str] = None
    auto_approve: bool = False

@app.get("/api/policies")
def list_policies(db: Session = Depends(get_db)):
    return {"policies": [_policy_dict(p) for p in db.query(Policy).order_by(Policy.created_at.desc()).all()]}

@app.post("/api/policies")
def create_policy(body: PolicyBody, db: Session = Depends(get_db),
                  session: dict = Depends(_get_session)):
    p = Policy(**body.model_dump(), created_by=session["username"])
    db.add(p); db.commit(); db.refresh(p)
    return _policy_dict(p)

@app.put("/api/policies/{policy_id}")
def update_policy(policy_id: int, body: PolicyBody, db: Session = Depends(get_db),
                  session: dict = Depends(_get_session)):
    p = db.query(Policy).filter(Policy.id == policy_id).first()
    if not p: raise HTTPException(404, "Policy not found")
    for k, v in body.model_dump().items():
        setattr(p, k, v)
    db.commit(); db.refresh(p)
    return _policy_dict(p)

@app.delete("/api/policies/{policy_id}")
def delete_policy(policy_id: int, db: Session = Depends(get_db),
                  session: dict = Depends(_get_session)):
    p = db.query(Policy).filter(Policy.id == policy_id).first()
    if not p: raise HTTPException(404, "Policy not found")
    db.delete(p); db.commit()
    return {"ok": True}

@app.post("/api/policies/{policy_id}/run")
def run_policy(policy_id: int, db: Session = Depends(get_db),
               session: dict = Depends(_get_session)):
    p = db.query(Policy).filter(Policy.id == policy_id).first()
    if not p: raise HTTPException(404, "Policy not found")
    risk_order = {"low": 0, "medium": 1, "high": 2}
    cat_set = (["efficiency", "idle", "performance", "prevention", "optimal"]
               if p.category_mode == "all"
               else ["efficiency", "idle"] if p.category_mode == "idle"
               else ["efficiency"])
    q = db.query(Node).filter(Node.status == "pending",
                               Node.confidence >= p.min_confidence)
    if p.cluster_filter: q = q.filter(Node.cluster == p.cluster_filter)
    nodes = q.all()
    matched = [n for n in nodes if (n.saving or 0) >= p.min_savings
               and risk_order.get(_risk(n), 0) <= risk_order.get(p.max_risk, 0)
               and _cat(n) in cat_set]
    count = 0
    if p.auto_approve:
        for n in matched:
            n.status = "approved"
            db.add(ActionHistory(entity_type="node", entity_name=n.node_name,
                                 action="approved", performed_by=f"policy:{p.name}",
                                 details={"policy_id": p.id}))
            count += 1
    p.last_run_at = datetime.now(timezone.utc)
    p.last_run_count = count if p.auto_approve else len(matched)
    db.commit()
    return {"matched": len(matched), "approved": count}

def _risk(n):
    if (n.cpu_max_pct or 0) > 80 or (n.mem_max_pct or 0) > 85 or (n.confidence or 0) < 50: return "high"
    if (n.cpu_max_pct or 0) > 60 or (n.mem_max_pct or 0) > 65 or (n.confidence or 0) < 70: return "medium"
    return "low"

def _cat(n):
    if not n.rec_sku or n.current_sku == n.rec_sku: return "optimal"
    if (n.cpu_max_pct or 0) < 5 and (n.mem_max_pct or 0) < 10: return "idle"
    if (n.cpu_max_pct or 0) > 85 or (n.mem_max_pct or 0) > 90: return "performance"
    if (n.cpu_avg_pct or 0) < 30 and (n.mem_avg_pct or 0) < 40: return "efficiency"
    return "efficiency"


# ── Alerts ────────────────────────────────────────────────────────────────────
def _alert_dict(a: Alert) -> dict:
    return {
        "id": a.id, "title": a.title, "message": a.message,
        "severity": a.severity, "entity_type": a.entity_type,
        "entity_name": a.entity_name, "cluster": a.cluster,
        "status": a.status, "triggered_by": a.triggered_by,
        "created_at": a.created_at.isoformat() if a.created_at else None,
        "updated_at": a.updated_at.isoformat() if a.updated_at else None,
        "resolved_at": a.resolved_at.isoformat() if a.resolved_at else None,
    }

class AlertBody(BaseModel):
    title: str
    message: str
    severity: str = "info"
    entity_type: Optional[str] = None
    entity_name: Optional[str] = None
    cluster: Optional[str] = None

# ── Alert config API ──────────────────────────────────────────────────────────
import base64 as _b64

@app.get("/api/alert-config")
def get_alert_config(db: Session = Depends(get_db), _session=Depends(_get_session)):
    """Return current alert channel config. smtp_pass is never returned."""
    from models import AlertConfig
    cfg = db.query(AlertConfig).filter(AlertConfig.id == 1).first()
    if not cfg:
        return {"teams_webhook_url": "", "teams_enabled": False,
                "smtp_host": "", "smtp_port": 587, "smtp_user": "",
                "smtp_from": "", "smtp_to": "", "smtp_enabled": False,
                "app_url": "", "smtp_pass_set": False}
    return {
        "teams_webhook_url": cfg.teams_webhook_url or "",
        "teams_enabled":     cfg.teams_enabled or False,
        "smtp_host":         cfg.smtp_host or "",
        "smtp_port":         cfg.smtp_port or 587,
        "smtp_user":         cfg.smtp_user or "",
        "smtp_from":         cfg.smtp_from or "",
        "smtp_to":           cfg.smtp_to or "",
        "smtp_enabled":      cfg.smtp_enabled or False,
        "app_url":           cfg.app_url or "",
        "smtp_pass_set":     bool(cfg.smtp_pass_enc),   # only tells frontend if a password exists
    }


@app.put("/api/alert-config")
def save_alert_config(payload: dict, db: Session = Depends(get_db),
                      _session=Depends(_get_session)):
    """Save alert channel config. Admin only."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required")
    from models import AlertConfig
    cfg = db.query(AlertConfig).filter(AlertConfig.id == 1).first()
    if not cfg:
        cfg = AlertConfig(id=1)
        db.add(cfg)

    cfg.teams_webhook_url = payload.get("teams_webhook_url", "") or None
    cfg.teams_enabled     = bool(payload.get("teams_enabled"))
    cfg.smtp_host         = payload.get("smtp_host", "") or None
    cfg.smtp_port         = int(payload.get("smtp_port") or 587)
    cfg.smtp_user         = payload.get("smtp_user", "") or None
    cfg.smtp_from         = payload.get("smtp_from", "") or None
    cfg.smtp_to           = payload.get("smtp_to", "") or None
    cfg.smtp_enabled      = bool(payload.get("smtp_enabled"))
    cfg.app_url           = payload.get("app_url", "") or None
    cfg.updated_by        = _session.get("username", "admin")

    # Only update password if a new one was provided (non-empty)
    new_pass = payload.get("smtp_pass", "")
    if new_pass:
        cfg.smtp_pass_enc = _b64.b64encode(new_pass.encode()).decode()

    db.commit()
    return {"ok": True}


# ── Azure Config ──────────────────────────────────────────────────────────────

def _load_azure_db_creds():
    """Load AzureConfig from DB into the in-memory _azure_db_creds cache."""
    global _azure_db_creds
    db = SessionLocal()
    try:
        cfg = db.query(AzureConfig).filter(AzureConfig.id == 1).first()
        if cfg:
            _azure_db_creds = {
                "tenant_id":        cfg.tenant_id or "",
                "client_id":        cfg.client_id or "",
                "client_secret":    (_b64.b64decode(cfg.client_secret_enc.encode()).decode()
                                     if cfg.client_secret_enc else ""),
                "subscription_ids": cfg.subscription_ids or "",
            }
        else:
            _azure_db_creds = {}
    except Exception as e:
        print(f"[azure-config] Failed to load DB creds: {e}")
    finally:
        db.close()


@app.get("/api/azure-config")
def get_azure_config(db: Session = Depends(get_db), _session=Depends(_get_session)):
    """Return Azure integration config. client_secret is never returned."""
    cfg = db.query(AzureConfig).filter(AzureConfig.id == 1).first()
    if not cfg:
        return {"subscription_ids": "", "tenant_id": "", "client_id": "",
                "client_secret_set": False}
    return {
        "subscription_ids":   cfg.subscription_ids or "",
        "tenant_id":          cfg.tenant_id or "",
        "client_id":          cfg.client_id or "",
        "client_secret_set":  bool(cfg.client_secret_enc),
    }


@app.put("/api/azure-config")
def save_azure_config(payload: dict, db: Session = Depends(get_db),
                      _session=Depends(_get_session)):
    """Save Azure integration config. Admin only. Reloads in-memory credential cache."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required")
    cfg = db.query(AzureConfig).filter(AzureConfig.id == 1).first()
    if not cfg:
        cfg = AzureConfig(id=1)
        db.add(cfg)

    cfg.subscription_ids = payload.get("subscription_ids", "") or None
    cfg.tenant_id        = payload.get("tenant_id", "") or None
    cfg.client_id        = payload.get("client_id", "") or None
    cfg.updated_by       = _session.get("username", "admin")

    new_secret = payload.get("client_secret", "")
    if new_secret:
        cfg.client_secret_enc = _b64.b64encode(new_secret.encode()).decode()

    db.commit()
    _load_azure_db_creds()   # refresh in-memory cache immediately
    return {"ok": True}


# ── Cluster Mappings (Datasource → Azure Cluster) ──────────────────────────────
@app.get("/api/cluster-mappings")
def list_cluster_mappings(db: Session = Depends(get_db)):
    """List all datasource → Azure cluster name mappings."""
    from models import ClusterMapping
    rows = db.query(ClusterMapping).order_by(ClusterMapping.datasource_name).all()
    return {
        "mappings": [
            {
                "id": r.id,
                "datasource_name": r.datasource_name,
                "azure_cluster_name": r.azure_cluster_name,
                "subscription_id": r.subscription_id,
            }
            for r in rows
        ]
    }


@app.post("/api/cluster-mappings")
def create_cluster_mapping(payload: dict, db: Session = Depends(get_db),
                          _session=Depends(_get_session)):
    """Create a datasource → Azure cluster name mapping. Admin only."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required")
    from models import ClusterMapping
    m = ClusterMapping(
        datasource_name=payload.get("datasource_name", ""),
        azure_cluster_name=payload.get("azure_cluster_name", ""),
        subscription_id=payload.get("subscription_id"),
    )
    db.add(m)
    db.commit()
    db.refresh(m)
    return {"id": m.id, "ok": True}


@app.put("/api/cluster-mappings/{mapping_id}")
def update_cluster_mapping(mapping_id: int, payload: dict, db: Session = Depends(get_db),
                          _session=Depends(_get_session)):
    """Update a cluster mapping. Admin only."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required")
    from models import ClusterMapping
    m = db.query(ClusterMapping).filter(ClusterMapping.id == mapping_id).first()
    if not m:
        raise HTTPException(404, "Mapping not found")
    if "datasource_name" in payload:
        m.datasource_name = payload["datasource_name"]
    if "azure_cluster_name" in payload:
        m.azure_cluster_name = payload["azure_cluster_name"]
    if "subscription_id" in payload:
        m.subscription_id = payload["subscription_id"]
    db.commit()
    return {"ok": True}


@app.delete("/api/cluster-mappings/{mapping_id}")
def delete_cluster_mapping(mapping_id: int, db: Session = Depends(get_db),
                          _session=Depends(_get_session)):
    """Delete a cluster mapping. Admin only."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required")
    from models import ClusterMapping
    m = db.query(ClusterMapping).filter(ClusterMapping.id == mapping_id).first()
    if not m:
        raise HTTPException(404, "Mapping not found")
    db.delete(m)
    db.commit()
    return {"ok": True}


@app.post("/api/quota-alerts/check")
def trigger_quota_alert_check(_session: dict = Depends(_get_session)):
    """Manually trigger an immediate quota alert scan (admin)."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required")
    threading.Thread(target=_run_quota_alerts, daemon=True).start()
    return {"ok": True, "message": "Quota alert scan started"}


@app.get("/api/alerts")
def list_alerts(status: Optional[str] = None, severity: Optional[str] = None,
                db: Session = Depends(get_db)):
    q = db.query(Alert)
    if status:   q = q.filter(Alert.status == status)
    if severity: q = q.filter(Alert.severity == severity)
    return {"alerts": [_alert_dict(a) for a in q.order_by(Alert.created_at.desc()).all()]}

@app.post("/api/alerts")
def create_alert(body: AlertBody, db: Session = Depends(get_db),
                 session: dict = Depends(_get_session)):
    a = Alert(**body.model_dump(), triggered_by=session["username"])
    db.add(a); db.commit(); db.refresh(a)
    return _alert_dict(a)

@app.patch("/api/alerts/{alert_id}")
def update_alert(alert_id: int, payload: dict, db: Session = Depends(get_db),
                 session: dict = Depends(_get_session)):
    a = db.query(Alert).filter(Alert.id == alert_id).first()
    if not a: raise HTTPException(404, "Alert not found")
    allowed = {"title", "message", "severity", "status"}
    for k, v in payload.items():
        if k in allowed: setattr(a, k, v)
    if payload.get("status") == "resolved" and not a.resolved_at:
        a.resolved_at = datetime.now(timezone.utc)
    db.commit(); db.refresh(a)
    return _alert_dict(a)

@app.delete("/api/alerts/{alert_id}")
def delete_alert(alert_id: int, db: Session = Depends(get_db),
                 session: dict = Depends(_get_session)):
    a = db.query(Alert).filter(Alert.id == alert_id).first()
    if not a: raise HTTPException(404, "Alert not found")
    db.delete(a); db.commit()
    return {"ok": True}


# ── VM SKU API ────────────────────────────────────────────────────────────────
# IMPORTANT: the wildcard GET /api/skus/{sku_name} route is declared AFTER all
# specific /api/skus/... POST routes so FastAPI matches them first and does not
# consume POST requests with a 405 Method Not Allowed.


@app.get("/api/skus")
def list_skus(region: Optional[str] = None, db: Session = Depends(get_sku_db)):
    """List all synced SKUs, optionally filtered by region."""
    q = db.query(VmSku)
    if region:
        q = q.filter(VmSku.region == region)
    rows = q.order_by(VmSku.sku_name, VmSku.region).all()
    return [{"sku_name": r.sku_name, "region": r.region,
             "vcpus": r.vcpus, "memory_gb": r.memory_gb,
             "price_linux_hr": r.price_linux_hr,
             "last_fetched_at": r.last_fetched_at.isoformat() if r.last_fetched_at else None}
            for r in rows]



# Static mapping: Grafana display region names → one or more ARM region names to try.
# Ordered by most-common first so the first hit is usually right.
_DISPLAY_TO_ARM: dict[str, list[str]] = {
    "europe":      ["westeurope", "northeurope"],
    "us":          ["eastus", "eastus2", "westus", "westus2", "centralus", "southcentralus", "northcentralus", "westcentralus"],
    "australia":   ["australiaeast", "australiasoutheast", "australiacentral"],
    "asia":        ["southeastasia", "eastasia"],
    "uk":          ["uksouth", "ukwest"],
    "canada":      ["canadacentral", "canadaeast"],
    "brazil":      ["brazilsouth", "brazilsoutheast"],
    "japan":       ["japaneast", "japanwest"],
    "india":       ["centralindia", "southindia", "westindia"],
    "korea":       ["koreacentral", "koreasouth"],
    "france":      ["francecentral", "francesouth"],
    "germany":     ["germanywestcentral", "germanynorth"],
    "norway":      ["norwayeast", "norwaywest"],
    "switzerland": ["switzerlandnorth", "switzerlandwest"],
    "sweden":      ["swedencentral"],
    "uae":         ["uaenorth", "uaecentral"],
    "southafrica": ["southafricanorth", "southafricawest"],
    "qatar":       ["qatarcentral"],
    "poland":      ["polandcentral"],
    "mexico":      ["mexicocentral"],
    "newzealand":  ["newzealandnorth"],
    "chile":       ["chilecental"],
    "malaysia":    ["malaysiawest"],
    "taiwan":      ["taiwannorth"],
    "israel":      ["israelcentral"],
    "italy":       ["italynorth"],
    "spain":       ["spaincentral"],
}


def _resolve_arm_regions(display: str) -> list[str]:
    """
    Convert a Grafana display region name to a list of ARM region names to try.
    Falls back to using the input directly if no mapping is found.
    """
    dl = display.lower().replace(" ", "")
    # Exact match in map
    if dl in _DISPLAY_TO_ARM:
        return _DISPLAY_TO_ARM[dl]
    # Already an ARM name (lowercase, no spaces)
    for candidates in _DISPLAY_TO_ARM.values():
        if dl in candidates:
            return [dl]
    # Prefix / contains match against map keys
    for key, candidates in _DISPLAY_TO_ARM.items():
        if key.startswith(dl) or dl.startswith(key):
            return candidates
    return [dl]


def _sku_row_to_dict(row: VmSku) -> dict:
    return {
        "sku_name":               row.sku_name,
        "region":                 row.region,
        "tier":                   row.tier,
        "family":                 row.family,
        "sku_type":               row.sku_type or "General purpose",
        "vcpus":                  row.vcpus,
        "vcpus_available":        row.vcpus_available,
        "memory_gb":              row.memory_gb,
        "max_data_disks":         row.max_data_disks,
        "max_uncached_disk_iops": row.max_uncached_disk_iops,
        "max_uncached_disk_mbps": row.max_uncached_disk_mbps,
        "premium_io":             bool(row.premium_io),
        "accelerated_networking": bool(row.accelerated_networking),
        "cpu_arch":               row.cpu_arch,
        "hyper_v_gen":            row.hyper_v_gen,
        "max_nics":               row.max_nics,
        "local_storage_gb":       row.local_storage_gb,
        "rdma_enabled":           bool(row.rdma_enabled),
        "gpu_count":              row.gpu_count or 0,
        "gpu_memory_gb":          row.gpu_memory_gb,
        "confidential_compute":   bool(row.confidential_compute),
        "price_linux_hr":         row.price_linux_hr,
        "price_windows_hr":       row.price_windows_hr,
        "price_linux_mo":         round(row.price_linux_hr   * 730, 2) if row.price_linux_hr   else None,
        "price_windows_mo":       round(row.price_windows_hr * 730, 2) if row.price_windows_hr else None,
        "last_fetched_at":        row.last_fetched_at.isoformat() if row.last_fetched_at else None,
    }


def _fetch_and_store_sku(sku_name: str, arm_regions: list[str]) -> Optional[VmSku]:
    """
    On-demand: fetch a single SKU's capabilities and pricing from Azure ARM API
    and upsert into vm_skus.  Tries each ARM region in arm_regions until found.
    Called when get_sku hits a 404 so that newly deployed SKU families (v6, etc.)
    are auto-discovered without a full resync.
    Returns the upserted VmSku row, or None if Azure has no data for it.
    """
    token = _get_azure_token()
    if not token:
        return None
    sub_ids = _get_subscription_ids(token)
    if not sub_ids:
        return None
    try:
        caps = _fetch_sku_capabilities(sub_ids, token, arm_regions)
        # Find the first region that has this SKU
        cap = None
        found_region = None
        for region in arm_regions:
            c = caps.get((sku_name, region))
            if not c:
                # case-insensitive fallback
                for (sn, sr), v in caps.items():
                    if sn.lower() == sku_name.lower() and sr == region:
                        c = v
                        break
            if c:
                cap = c
                found_region = region
                break
        if not cap:
            print(f"On-demand SKU fetch: {sku_name} not found in ARM for regions {arm_regions}")
            return None
        pricing = _fetch_sku_pricing([sku_name], [found_region])
        price   = pricing.get((sku_name, found_region), {})
        db = SkuSessionLocal()
        try:
            existing = db.query(VmSku).filter(
                VmSku.sku_name == sku_name, VmSku.region == found_region).first()
            row = existing if existing else VmSku(sku_name=sku_name, region=found_region)
            if not existing:
                db.add(row)
            for k, v in cap.items():
                setattr(row, k, v)
            if price.get("linux_hr")   is not None: row.price_linux_hr   = price["linux_hr"]
            if price.get("windows_hr") is not None: row.price_windows_hr = price["windows_hr"]
            row.last_fetched_at = datetime.now(timezone.utc)
            db.commit()
            db.refresh(row)
            print(f"On-demand SKU fetch: stored {sku_name} / {found_region}")
            return row
        except Exception as e:
            db.rollback()
            print(f"On-demand SKU fetch: DB error for {sku_name}: {e}")
            return None
        finally:
            db.close()
    except Exception as e:
        print(f"On-demand SKU fetch error for {sku_name}: {e}")
        return None


# ── Quota API ─────────────────────────────────────────────────────────────────

def _sku_to_quota_family(sku: str) -> str:
    """
    Convert an Azure VM SKU name to the quota family name used in
    Microsoft.Compute/locations/{loc}/usages.

    Azure quota names follow the pattern: "standard<Family>Family"
    e.g.  Standard_D4s_v5  →  standardDSv5Family
          Standard_E8as_v5 →  standardEASv5Family
          Standard_F4s_v2  →  standardFSv2Family
          Standard_B4ms    →  standardBSFamily
          Standard_NC6s_v3 →  standardNCSv3Family

    Strategy: strip "Standard_", extract letters+digits before the version suffix,
    camelCase the family, append "Family".
    """
    if not sku:
        return ""
    # e.g. Standard_D4s_v5 → D4s_v5 → D + s → Ds + v5 → DsV5
    inner = re.sub(r"^[Ss]tandard_", "", sku)          # D4s_v5
    # Extract letter prefix (family letters), digit size, optional suffix letters, version
    m = re.match(
        r"^([A-Z]+)"           # family letter(s): D, E, F, NC, etc.
        r"\d+"                 # size digits: 4, 8, 16
        r"([a-zA-Z]*)"        # suffix letters: s, as, ms, etc.
        r"(?:_v(\d+))?",       # optional version: _v5
        inner, re.I
    )
    if not m:
        # Fallback: just normalise as-is
        base = inner.split("_")[0]
        return f"standard{base}Family"

    family_letter = m.group(1).upper()    # D, E, NC
    suffix        = m.group(2).upper()    # S, AS, MS, "" (empty)
    version       = m.group(3)            # "5", "2", None

    # Build quota key: standard + FamilyLetter + Suffix + vVersion + Family
    # e.g. D + S + V5 → standardDSv5Family
    ver_part = f"v{version}" if version else ""
    quota_family = f"standard{family_letter}{suffix}{ver_part}Family"
    return quota_family


# In-memory quota cache: (subscription_id, location) → {family: {current, limit}, fetched_at}
_quota_cache: dict = {}
_quota_cache_lock = threading.Lock()
_QUOTA_TTL_SECONDS = 300  # 5 minutes


@app.get("/api/quota")
def get_quota(location: str, skus: str = "",
              subscription_id: str = ""):
    """
    Return Azure vCPU quota for given VM SKU families at a location.

    Query params:
      location        — Azure region name (e.g. "canadacentral")
      skus            — comma-separated SKU names to check (e.g. "Standard_D4s_v5,Standard_E4s_v5")
      subscription_id — optional; defaults to first configured subscription

    Response:
      {
        "location": "canadacentral",
        "families": {
          "standardDSv5Family": {"current": 12, "limit": 100, "available": 88},
          ...
        },
        "cores": {"current": 20, "limit": 200, "available": 180}
      }
    """
    # Validate location parameter early
    location_raw = (location or "").strip()
    if not location_raw:
        raise HTTPException(400, "location parameter is required and cannot be empty")

    # Reject locations that contain invalid/special characters (em-dash, etc.)
    # Valid ARM region names are alphanumeric lowercase, no dashes or special chars in database
    if any(ord(c) > 127 or c in '—––' for c in location_raw):
        print(f"[quota] ❌ Rejecting invalid location with special characters: '{location_raw}'")
        raise HTTPException(400, f"Invalid location parameter: contains invalid characters")

    location = _to_arm_region(location_raw)  # Convert "uae" → "uaenorth", etc.

    # Additional check: if location is empty after normalization
    if not location or not location.strip():
        print(f"[quota] ❌ Rejecting location that normalized to empty: '{location_raw}'")
        raise HTTPException(400, "Invalid location parameter")

    sku_list = [s.strip() for s in skus.split(",") if s.strip()]

    # Fetch token once and reuse
    token = _get_azure_token()

    # Resolve subscription
    sub_id = subscription_id.strip()
    if not sub_id:
        configured = AZURE_SUBSCRIPTION_IDS
        sub_id = configured[0] if configured else ""
    if not sub_id:
        discovered = _get_subscription_ids(token)
        sub_id = discovered[0] if discovered else ""
    if not sub_id:
        raise HTTPException(503, "No Azure subscription ID available")

    cache_key = (sub_id, location)
    now_ts = datetime.now(timezone.utc).timestamp()

    with _quota_cache_lock:
        cached = _quota_cache.get(cache_key)
        if cached and (now_ts - cached["fetched_at"]) < _QUOTA_TTL_SECONDS:
            raw_usages = cached["usages"]
        else:
            raw_usages = None

    if raw_usages is None:
        if not token:
            raise HTTPException(503, "Could not obtain Azure management token")
        api_url = (
            f"https://management.azure.com/subscriptions/{sub_id}"
            f"/providers/Microsoft.Compute/locations/{location}"
            f"/usages?api-version=2024-03-01"
        )
        try:
            req = urllib.request.Request(
                api_url,
                headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode = ssl.CERT_NONE
            with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                raw_usages = json.loads(r.read().decode()).get("value", [])
        except urllib.error.HTTPError as e:
            raise HTTPException(e.code, f"Azure quota API error: {e.reason}")
        except Exception as e:
            raise HTTPException(502, f"Azure quota fetch failed: {e}")

        with _quota_cache_lock:
            _quota_cache[cache_key] = {"usages": raw_usages, "fetched_at": now_ts}

    # Build lookup: quota_name → {current, limit}
    usage_map: dict[str, dict] = {}
    for u in raw_usages:
        name = u.get("name", {}).get("value", "")
        if name:
            usage_map[name] = {
                "current":   u.get("currentValue", 0),
                "limit":     u.get("limit", 0),
                "localName": u.get("name", {}).get("localizedValue", name),
            }

    # Collect requested families
    families_to_check: set[str] = set()
    for sku in sku_list:
        qf = _sku_to_quota_family(sku)
        if qf:
            families_to_check.add(qf)

    result_families: dict = {}
    for fam in families_to_check:
        # Try exact match, then case-insensitive
        entry = usage_map.get(fam)
        if not entry:
            fam_lower = fam.lower()
            entry = next((v for k, v in usage_map.items() if k.lower() == fam_lower), None)
        if entry:
            result_families[fam] = {
                "current":   entry["current"],
                "limit":     entry["limit"],
                "available": max(0, entry["limit"] - entry["current"]),
                "localName": entry["localName"],
            }
        else:
            result_families[fam] = {"current": 0, "limit": 0, "available": 0, "localName": fam, "not_found": True}

    # Always include total vCPU cores
    cores = usage_map.get("cores", {})
    return {
        "location":      location,
        "subscription":  sub_id,
        "families":      result_families,
        "cores":         {
            "current":   cores.get("current", 0),
            "limit":     cores.get("limit", 0),
            "available": max(0, cores.get("limit", 0) - cores.get("current", 0)),
        },
    }


@app.get("/api/cluster-location")
def get_cluster_location_endpoint(cluster: str = ""):
    """
    Fetch the Azure location/region for a given AKS cluster name.

    Query params:
      cluster  — cluster name to look up (e.g. "aks-prod-westeurope")

    Response:
      {
        "cluster": "aks-prod-westeurope",
        "location": "westeurope",
        "found": true
      }
    """
    if not cluster or not cluster.strip():
        raise HTTPException(400, "cluster parameter is required")

    cluster = cluster.strip()
    token = _get_azure_token()

    if not token:
        raise HTTPException(503, "Could not obtain Azure management token")

    sub_ids = _get_subscription_ids(token)
    if not sub_ids:
        raise HTTPException(503, "No Azure subscription IDs available")

    location = _get_cluster_location(cluster, token, sub_ids)

    return {
        "cluster": cluster,
        "location": location or "",
        "found": bool(location),
    }


@app.get("/api/quota/node-regions")
def get_quota_node_regions(skus: str = "", _session: dict = Depends(_get_session)):
    """
    Return Azure vCPU quota for all regions where nodes currently exist.
    Automatically discovers node regions from database and fetches their quotas.

    Query params:
      skus  — optional comma-separated SKU names to focus on (e.g. "Standard_D4s_v5,Standard_E4s_v5")

    Response:
      {
        "regions": {
          "eastus": {
            "location": "eastus",
            "families": {...},
            "cores": {...}
          },
          "westeurope": {...}
        },
        "node_regions": ["eastus", "westeurope"],
        "timestamp": "2026-05-28T14:00:00Z"
      }
    """
    # Get all unique regions from nodes
    db = SessionLocal()
    try:
        from sqlalchemy import distinct as _distinct
        node_regions = [r[0] for r in
                       db.query(_distinct(Node.region))
                       .filter(Node.region.isnot(None)).all()
                       if r[0]]
    finally:
        db.close()

    if not node_regions:
        return {
            "regions": {},
            "node_regions": [],
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "message": "No nodes with regions found in database"
        }

    sku_list = [s.strip() for s in skus.split(",") if s.strip()]
    token = _get_azure_token()
    sub_ids = _get_subscription_ids(token) if token else []
    sub_id = sub_ids[0] if sub_ids else ""

    if not sub_id:
        raise HTTPException(503, "No Azure subscription ID available")

    result_regions = {}
    for region in sorted(node_regions):
        # region is already exact ARM name from Azure API (e.g., "southafricanorth")
        # Do NOT convert — it's already in correct format
        if not region:
            continue

        # Fetch quota for this region (reuse cache from _refresh_quota_cache)
        cache_key = (sub_id, region)
        now_ts = datetime.now(timezone.utc).timestamp()

        with _quota_cache_lock:
            cached = _quota_cache.get(cache_key)
            if cached and (now_ts - cached.get("fetched_at", 0)) < _QUOTA_TTL_SECONDS:
                raw_usages = cached["usages"]
            else:
                raw_usages = None

        if raw_usages is None:
            # Not in cache, try to fetch directly
            if not token:
                continue
            try:
                api_url = (
                    f"https://management.azure.com/subscriptions/{sub_id}"
                    f"/providers/Microsoft.Compute/locations/{region}"
                    f"/usages?api-version=2024-03-01"
                )
                req = urllib.request.Request(
                    api_url,
                    headers={"Authorization": f"Bearer {token}", "Accept": "application/json"},
                )
                ctx = ssl.create_default_context()
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
                with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                    raw_usages = json.loads(r.read().decode()).get("value", [])
                with _quota_cache_lock:
                    _quota_cache[cache_key] = {"usages": raw_usages, "fetched_at": now_ts}
            except Exception as e:
                print(f"[quota] Failed to fetch {region}: {e}")
                continue

        # Build lookup: quota_name → {current, limit}
        usage_map = {}
        for u in raw_usages:
            name = u.get("name", {}).get("value", "")
            if name:
                usage_map[name] = {
                    "current": u.get("currentValue", 0),
                    "limit": u.get("limit", 0),
                    "localName": u.get("name", {}).get("localizedValue", name),
                }

        # Collect requested families
        families_to_check = set()
        for sku in sku_list:
            qf = _sku_to_quota_family(sku)
            if qf:
                families_to_check.add(qf)

        result_families = {}
        if families_to_check:
            for fam in families_to_check:
                entry = usage_map.get(fam)
                if not entry:
                    fam_lower = fam.lower()
                    entry = next((v for k, v in usage_map.items() if k.lower() == fam_lower), None)
                if entry:
                    result_families[fam] = {
                        "current": entry["current"],
                        "limit": entry["limit"],
                        "available": max(0, entry["limit"] - entry["current"]),
                        "localName": entry["localName"],
                    }
        else:
            # No SKUs specified, include all quota entries for this region
            for name, entry in usage_map.items():
                result_families[name] = {
                    "current": entry["current"],
                    "limit": entry["limit"],
                    "available": max(0, entry["limit"] - entry["current"]),
                    "localName": entry["localName"],
                }

        # Always include total vCPU cores
        cores = usage_map.get("cores", {})
        result_regions[region] = {
            "location": region,
            "families": result_families,
            "cores": {
                "current": cores.get("current", 0),
                "limit": cores.get("limit", 0),
                "available": max(0, cores.get("limit", 0) - cores.get("current", 0)),
            },
        }

    return {
        "regions": result_regions,
        "node_regions": sorted(node_regions),
        "timestamp": datetime.now(timezone.utc).isoformat(),
    }


def _refresh_quota_cache():
    """
    Lightweight: fetch Azure vCPU quota for all node regions and store in
    _quota_cache.  Does NOT write to the Alert DB — that is left to the
    hourly _run_quota_alerts job.  Runs every 5 min and at startup.
    """
    token = _get_azure_token()
    if not token:
        return
    node_db = SessionLocal()
    try:
        from sqlalchemy import distinct as _distinct
        regions_raw = [r[0] for r in
                       node_db.query(_distinct(Node.region))
                       .filter(Node.region.isnot(None)).all()
                       if r[0]]
    finally:
        node_db.close()

    sub_ids = _get_subscription_ids(token)
    if not sub_ids or not regions_raw:
        return

    sub_id  = sub_ids[0]
    now_ts  = time.time()
    # regions_raw are already exact ARM region names from Azure API (e.g., "southafricanorth")
    # Do NOT convert — use directly
    arm_locs = list({r for r in regions_raw if r})

    def _fetch_one(arm_loc: str):
        cache_key = (sub_id, arm_loc)
        with _quota_cache_lock:
            cached = _quota_cache.get(cache_key)
            if cached and (now_ts - cached.get("fetched_at", 0)) < _QUOTA_TTL_SECONDS:
                return  # still fresh
        try:
            url = (
                f"https://management.azure.com/subscriptions/{sub_id}"
                f"/providers/Microsoft.Compute/locations/{arm_loc}"
                f"/usages?api-version=2024-03-01"
            )
            req = urllib.request.Request(
                url, headers={"Authorization": f"Bearer {token}", "Accept": "application/json"}
            )
            ctx = ssl.create_default_context()
            ctx.check_hostname = False
            ctx.verify_mode    = ssl.CERT_NONE
            with urllib.request.urlopen(req, context=ctx, timeout=15) as r:
                usages = json.loads(r.read().decode()).get("value", [])
            with _quota_cache_lock:
                _quota_cache[cache_key] = {"usages": usages, "fetched_at": time.time()}
            print(f"[quota-cache] refreshed {arm_loc}: {len(usages)} entries")
        except Exception as e:
            print(f"[quota-cache] fetch failed {arm_loc}: {e}")

    with ThreadPoolExecutor(max_workers=min(8, len(arm_locs))) as pool:
        list(pool.map(_fetch_one, arm_locs))


@app.get("/api/quota-alerts-summary")
def get_quota_alerts_summary(_session: dict = Depends(_get_session)):
    """
    Return all quota entries currently at ≥ WARN threshold (60%) from the
    in-memory quota cache. Triggers a fast background-style refresh if the
    cache is empty (first call after startup).

    Response:
      {
        "alerts": [
          {"location": "australiaeast", "family": "standardDSv5Family",
           "local_name": "Standard DSv5 Family vCPUs",
           "current": 272, "limit": 350, "pct": 77.7, "severity": "warning"},
          ...
        ],
        "total": 1,
        "critical": 0,
        "warning": 1
      }
    """
    # If quota cache is cold (nothing fetched yet), do a quick synchronous refresh
    with _quota_cache_lock:
        cache_empty = len(_quota_cache) == 0
    if cache_empty:
        _refresh_quota_cache()

    alerts = []
    with _quota_cache_lock:
        snapshot = dict(_quota_cache)   # shallow copy while holding lock

    for (sub_id, location), entry in snapshot.items():
        for u in entry.get("usages", []):
            fam   = u.get("name", {}).get("value", "")
            local = u.get("name", {}).get("localizedValue", fam)
            cur   = u.get("currentValue", 0)
            lim   = u.get("limit", 0)
            if not lim or not fam:
                continue
            pct = round(cur / lim * 100, 1)
            if pct >= _QUOTA_ALERT_WARN:
                alerts.append({
                    "location":        location,
                    "subscription_id": sub_id,
                    "family":          fam,
                    "local_name":      local,
                    "current":         cur,
                    "limit":           lim,
                    "pct":             pct,
                    "severity":        "critical" if pct >= _QUOTA_ALERT_CRITICAL else "warning",
                })

    alerts.sort(key=lambda a: (-a["pct"], a["location"]))
    return {
        "alerts":   alerts,
        "total":    len(alerts),
        "critical": sum(1 for a in alerts if a["severity"] == "critical"),
        "warning":  sum(1 for a in alerts if a["severity"] == "warning"),
    }


@app.get("/api/skus/{sku_name}")
def get_sku(sku_name: str, region: Optional[str] = None,
            db: Session = Depends(get_sku_db)):
    """Return SKU details for a given name, optionally filtered by region.

    Region matching handles Grafana display names (e.g. "Europe", "US") as well as
    ARM region names (e.g. "westeurope", "eastus").

    If the SKU is not in the DB, it is fetched on-demand from Azure ARM API and
    stored so that newly deployed SKU families (v6, etc.) are auto-discovered.
    """
    q = db.query(VmSku).filter(VmSku.sku_name.ilike(sku_name))
    if region:
        rl = region.lower()
        row = (q.filter(VmSku.region.ilike(rl)).first()
               or q.filter(VmSku.region.ilike(f"{rl}%")).first()
               or q.filter(VmSku.region.ilike(f"%{rl}%")).first()
               or q.first())
    else:
        row = q.first()

    if not row:
        # Not in DB — resolve display name → ARM region(s) and fetch on-demand from Azure
        arm_regions: list[str] = []
        if region:
            # First try DB-resident regions for a precise match
            existing = [r[0] for r in db.query(VmSku.region).distinct().limit(500).all()]
            rl = region.lower()
            db_match = (next((r for r in existing if r.lower() == rl), None)
                        or next((r for r in existing if r.lower().startswith(rl)), None)
                        or next((r for r in existing if rl in r.lower()), None))
            if db_match:
                arm_regions = [db_match]
            else:
                # DB empty or no match — use static display-name map
                arm_regions = _resolve_arm_regions(region)
        if arm_regions:
            row = _fetch_and_store_sku(sku_name, arm_regions)
        if not row:
            raise HTTPException(404, f"SKU {sku_name} not found in Azure for region {region or 'any'}")

    return _sku_row_to_dict(row)




@app.get("/api/vmss")
def list_vmss(session: dict = Depends(_get_session)):
    """List all VMSS instances with their current VM size across all subscriptions."""
    token = _get_azure_token()
    if not token:
        raise HTTPException(503, "Azure credentials not available — enable Managed Identity on the App Service")
    sub_ids = _get_subscription_ids(token)
    if not sub_ids:
        raise HTTPException(503, "No Azure subscriptions accessible")
    vmss_list = _fetch_vmss_instances(token, sub_ids)
    return {"count": len(vmss_list), "vmss": vmss_list}



@app.get("/api/azure/identity")
def check_azure_identity(session: dict = Depends(_get_session)):
    """Check which Azure identity method is active and confirm ARM access works."""
    identity_endpoint = os.getenv("IDENTITY_ENDPOINT", "")
    method = "app-service-mi" if identity_endpoint else "imds-or-sp"
    token = _get_azure_token()
    if not token:
        return {
            "authenticated": False,
            "method": method,
            "IDENTITY_ENDPOINT": bool(identity_endpoint),
            "AZURE_TENANT_ID": bool(os.getenv("AZURE_TENANT_ID")),
            "error": "No token obtained — check MI is enabled and has Reader role on subscription",
        }
    # Verify token works by listing subscriptions
    sub_ids = _get_subscription_ids(token)
    return {
        "authenticated": True,
        "method": method,
        "IDENTITY_ENDPOINT": bool(identity_endpoint),
        "subscriptions": sub_ids,
    }


@app.get("/api/azure/sku-sizes")
def get_azure_sku_sizes(region: str, session: dict = Depends(_get_session)):
    """
    Fetch VM SKU sizes directly from Azure Compute API for a given region.
    region must be an ARM region name e.g. australiacentral, canadacentral, eastus
    """
    token = _get_azure_token()
    if not token:
        raise HTTPException(503, "Azure credentials not available")
    sub_ids = _get_subscription_ids(token)
    if not sub_ids:
        raise HTTPException(503, "No Azure subscriptions accessible")
    caps = _fetch_sku_capabilities(sub_ids, token, [region])
    sizes = []
    for (sku_name, reg), info in sorted(caps.items()):
        sizes.append({"sku_name": sku_name, "region": reg, **info})
    return {"region": region, "count": len(sizes), "sizes": sizes}



@app.post("/api/nodes/recalculate")
def trigger_recalculate(bg: BackgroundTasks,
                        session: dict = Depends(_get_session)):
    """Reapply current SKU map to all existing nodes without re-fetching from Grafana."""
    if session.get("role") not in ("admin", "editor"):
        raise HTTPException(403, "Not allowed")
    bg.add_task(_recalculate_node_recommendations)
    return {"ok": True, "message": "Recalculating recommendations in background"}


# ── AI diagnostic ─────────────────────────────────────────────────────────────
@app.get("/api/ai/test")
def test_ai():
    """
    Diagnostic: shows what AI config is active and makes a live test call.
    No auth required — safe to call directly in the browser for debugging.
    Returns config state + result or detailed error from the API.
    """
    # Re-read env vars at call time (same as _call_openai)
    _key        = OPENAI_KEY        or os.environ.get("OPENAI_KEY", "")
    _endpoint   = OPENAI_ENDPOINT   or os.environ.get("OPENAI_ENDPOINT", "")
    _deployment = OPENAI_DEPLOYMENT or os.environ.get("OPENAI_DEPLOYMENT", "")
    config = {
        "key_set":        bool(_key),
        "key_prefix":     _key[:8] + "…" if _key else None,
        "endpoint":       _endpoint or None,
        "deployment":     _deployment or None,
        "api_version":    os.environ.get("OPENAI_API_VERSION") or "2024-05-01-preview",
        "provider":       "azure" if (_endpoint and _deployment) else "openai",
    }
    if not _key:
        return {**config, "ok": False, "error": "OPENAI_KEY not set — check Key Vault secret 'openai-api-key' or App Setting OPENAI_KEY"}
    if not _endpoint:
        return {**config, "ok": False,
                "error": "OPENAI_ENDPOINT not set — add App Setting OPENAI_ENDPOINT=https://<resource>.openai.azure.com"}
    if not _deployment:
        return {**config, "ok": False,
                "error": "OPENAI_DEPLOYMENT not set — add App Setting OPENAI_DEPLOYMENT=<deployment-name>"}
    try:
        result = _call_openai("Reply with exactly: OK", max_tokens=5)
        return {**config, "ok": True, "test_response": result}
    except HTTPException as e:
        return {**config, "ok": False, "error": f"HTTP {e.status_code}: {e.detail}"}
    except Exception as e:
        return {**config, "ok": False, "error": str(e)}


# ── Config ────────────────────────────────────────────────────────────────────
_last_fetch_cache: dict = {}   # {"ts": iso_str, "at": monotonic}
_LAST_FETCH_TTL = 60           # re-read DB at most once per minute

@app.get("/api/config")
def get_config():
    global _last_fetch_cache
    import time as _time
    last_fetch = _last_fetch_cache.get("ts")
    if not last_fetch or (_time.monotonic() - _last_fetch_cache.get("at", 0)) > _LAST_FETCH_TTL:
        try:
            db = SessionLocal()
            try:
                log = db.query(FetchLog).order_by(FetchLog.started_at.desc()).first()
                last_fetch = log.finished_at.isoformat() if log and log.finished_at else None
                _last_fetch_cache = {"ts": last_fetch, "at": _time.monotonic()}
            finally:
                db.close()
        except Exception:
            pass
    return {
        "grafana_url":          GRAFANA_URL,
        "ai_enabled":           bool(OPENAI_KEY or os.environ.get("OPENAI_KEY")),
        "ai_provider":          "azure" if (OPENAI_ENDPOINT or os.environ.get("OPENAI_ENDPOINT")) else "openai",
        "ai_deployment":        OPENAI_DEPLOYMENT or os.environ.get("OPENAI_DEPLOYMENT") or "gpt-4o",
        "fetch_interval_hours": FETCH_INTERVAL_HOURS,
        "last_fetch":           last_fetch,
    }


# ── Nodes ──────────────────────────────────────────────────────────────────────
def _backfill_node_fields(nodes: list) -> list:
    """Fill missing fields from sibling nodes in the same nodepool.
    All nodes in a nodepool share the same VM SKU, cluster, and price.
    Idle/stopped nodes often have no kube_node_labels entries in Prometheus,
    so their current_sku, cluster, current_price and saving end up as zero/empty."""
    def _get(n, k, default=None):
        v = n.get(k) if isinstance(n, dict) else getattr(n, k, None)
        return v if v is not None else default
    def _set(n, k, v):
        if isinstance(n, dict): n[k] = v
        else: setattr(n, k, v)

    pool_sku:     dict[str, str]   = {}
    pool_cluster: dict[str, str]   = {}
    pool_price:   dict[str, float] = {}

    for n in nodes:
        np = _get(n, "nodepool")
        if not np:
            continue
        sku   = _get(n, "current_sku")
        cl    = _get(n, "cluster")
        price = _get(n, "current_price", 0)
        if sku:     pool_sku[np]     = sku
        if cl:      pool_cluster[np] = cl
        if price:   pool_price[np]   = price

    for n in nodes:
        np = _get(n, "nodepool")
        if not np:
            continue
        if not _get(n, "current_sku") and np in pool_sku:
            _set(n, "current_sku", pool_sku[np])
        if not _get(n, "cluster") and np in pool_cluster:
            _set(n, "cluster", pool_cluster[np])
        # For SCALE DOWN nodes with no pricing: inherit current_price and set saving = full node cost
        rec = _get(n, "rec_sku")
        if rec == "SCALE_DOWN" and not _get(n, "current_price", 0) and np in pool_price:
            inherited_price = pool_price[np]
            _set(n, "current_price", inherited_price)
            _set(n, "saving", inherited_price)   # saving the whole node cost
    return nodes


# ── Pool live SSE feed ────────────────────────────────────────────────────────
import asyncio
from fastapi import Request
from fastapi.responses import StreamingResponse

@app.get("/api/pools/live")
async def pool_live_sse(
    cluster: str, nodepool: str,
    request: Request,
    db: Session = Depends(get_db),
    _session=Depends(_get_session),
):
    """
    Server-Sent Events stream of live Grafana metrics for one pool.
    Polls every 15 s. No DB writes — pure SSE.
    Connect: GET /api/pools/live?cluster=X&nodepool=Y
    Event shape: {nodes: {name: {cpu_pct, mem_pct, pod_count}}, ts: epoch_ms}
    """
    pool_nodes = db.query(Node).filter(
        Node.cluster  == cluster,
        Node.nodepool == nodepool,
    ).all()
    node_names = [n.node_name for n in pool_nodes]
    if not node_names:
        raise HTTPException(404, f"No nodes found for {cluster}/{nodepool}")

    # Resolve Grafana datasource UID for this cluster/region
    region = next((n.region for n in pool_nodes if n.region), None)
    ds_uid: str = ""
    if GRAFANA_URL and GRAFANA_TOKEN:
        try:
            _dss = gf.list_mimir_datasources(GRAFANA_URL, GRAFANA_TOKEN)
            for _ds in _dss:
                if _ds.get("name", "").lower() == cluster.lower():
                    ds_uid = _ds["uid"]; break
            if not ds_uid and region:
                for _ds in _dss:
                    if _ds.get("region", "").lower() == (region or "").lower():
                        ds_uid = _ds["uid"]; break
            if not ds_uid and _dss:
                ds_uid = _dss[0]["uid"]
        except Exception as e:
            print(f"[SSE] datasource lookup failed: {e}")

    async def _generate():
        yield ": connected\n\n"          # SSE keep-alive comment on connect
        while True:
            if await request.is_disconnected():
                break
            payload: dict = {"ts": int(datetime.now(timezone.utc).timestamp() * 1000), "nodes": {}}
            if ds_uid:
                try:
                    live = await asyncio.get_event_loop().run_in_executor(
                        None, gf.fetch_pool_live,
                        GRAFANA_URL, GRAFANA_TOKEN, ds_uid, node_names
                    )
                    payload["nodes"] = live
                except Exception as e:
                    payload["error"] = str(e)
            yield f"data: {json.dumps(payload)}\n\n"
            await asyncio.sleep(15)

    return StreamingResponse(
        _generate(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no",
                 "Connection": "keep-alive"},
    )


@app.get("/api/nodes")
def list_nodes(
    cluster: str = None, nodepool: str = None,
    region: str = None, status: str = None,
    db: Session = Depends(get_db)
):
    if _LIVE["nodes"]:
        nodes = list(_LIVE["nodes"].values())
        if cluster:  nodes = [n for n in nodes if n.get("cluster") == cluster]
        if nodepool: nodes = [n for n in nodes if n.get("nodepool") == nodepool]
        if region:   nodes = [n for n in nodes if n.get("region") == region]
        if status:   nodes = [n for n in nodes if n.get("status") == status]
        _backfill_node_fields(nodes)
        return {"nodes": sorted(nodes, key=lambda x: x.get("node_name", ""))}
    # Fallback to DB when live store is empty (cold start before first sync)
    q = db.query(Node)
    if cluster:  q = q.filter(Node.cluster == cluster)
    if nodepool: q = q.filter(Node.nodepool == nodepool)
    if region:   q = q.filter(Node.region == region)
    if status:   q = q.filter(Node.status == status)
    nodes = q.order_by(Node.node_name).all()
    _backfill_node_fields(nodes)
    return {"nodes": [_node_dict(n) for n in nodes]}


@app.get("/api/nodes/{node_name:path}/containers")
def get_node_containers(node_name: str, db: Session = Depends(get_db)):
    """Return containers whose pods run on this node."""
    from sqlalchemy import cast, String
    # JSON array column — use LIKE for SQLite compatibility
    ctrs = db.query(Container).filter(
        cast(Container.node_names, String).contains(node_name)
    ).all()
    result = []
    for c in ctrs:
        d = _ctr_dict(c)
        pnm = c.pod_node_map or {}
        d["pod_count_on_node"] = sum(1 for v in pnm.values() if v == node_name)
        result.append(d)
    return {"node_name": node_name, "containers": result}


@app.get("/api/nodes/{node_name:path}")
def get_node(node_name: str, db: Session = Depends(get_db)):
    n = db.query(Node).filter(Node.node_name == node_name).first()
    if not n:
        raise HTTPException(404, "Node not found")
    return _node_dict(n)


class StatusBody(BaseModel):
    performed_by: str = "user"


@app.post("/api/nodes/{node_name:path}/approve")
def approve_node(node_name: str, body: StatusBody = StatusBody(),
                 db: Session = Depends(get_db)):
    return _set_node_status(node_name, "approved", body.performed_by, db)


@app.post("/api/nodes/{node_name:path}/ignore")
def ignore_node(node_name: str, body: StatusBody = StatusBody(),
                db: Session = Depends(get_db)):
    return _set_node_status(node_name, "ignored", body.performed_by, db)


@app.post("/api/nodes/{node_name:path}/schedule")
def schedule_node(node_name: str, body: StatusBody = StatusBody(),
                  db: Session = Depends(get_db)):
    return _set_node_status(node_name, "scheduled", body.performed_by, db)


@app.post("/api/nodes/{node_name:path}/revert")
def revert_node(node_name: str, body: StatusBody = StatusBody(),
                db: Session = Depends(get_db),
                _session=Depends(_get_session)):
    """Admin-only: revert an approved/ignored node back to pending."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required to revert")
    return _set_node_status(node_name, "pending", body.performed_by or _session.get("username", "admin"), db)


def _set_node_status(node_name, status, performed_by, db):
    n = db.query(Node).filter(Node.node_name == node_name).first()
    if not n:
        raise HTTPException(404, "Node not found")
    prev = n.status
    n.status = status
    db.add(ActionHistory(entity_type="node", entity_name=node_name,
                         action=status, performed_by=performed_by,
                         details={"prev_status": prev, "rec_sku": n.rec_sku}))
    db.commit()
    if node_name in _LIVE["nodes"]:
        _LIVE["nodes"][node_name]["status"] = status
    return {"ok": True, "status": status}


# ── Containers ────────────────────────────────────────────────────────────────
@app.get("/api/containers")
def list_containers(
    namespace: str = None, cluster: str = None,
    status: str = None, db: Session = Depends(get_db)
):
    from collections import Counter
    if _LIVE["containers"]:
        ctrs = list(_LIVE["containers"].values())
        if namespace: ctrs = [c for c in ctrs if c.get("namespace") == namespace]
        if cluster:   ctrs = [c for c in ctrs if c.get("cluster") == cluster]
        if status:    ctrs = [c for c in ctrs if c.get("status") == status]
        cluster_counts = dict(Counter(c.get("cluster") or "unknown" for c in ctrs))
        return {"containers": sorted(ctrs, key=lambda x: x.get("container_id", "")),
                "cluster_counts": cluster_counts}
    # Fallback to DB when live store is empty
    q = db.query(Container)
    if namespace: q = q.filter(Container.namespace == namespace)
    if cluster:   q = q.filter(Container.cluster == cluster)
    if status:    q = q.filter(Container.status == status)
    ctrs = q.order_by(Container.container_id).all()
    cluster_counts = dict(Counter(c.cluster or "unknown" for c in ctrs))
    return {"containers": [_ctr_dict(c) for c in ctrs], "cluster_counts": cluster_counts}


@app.get("/api/topology")
def get_topology(cluster: str = None, db: Session = Depends(get_db),
                 _session=Depends(_get_session)):
    """Return cluster topology: node → pods → containers hierarchy."""
    nq = db.query(Node)
    cq = db.query(Container)
    if cluster:
        nq = nq.filter(Node.cluster == cluster)
        cq = cq.filter(Container.cluster == cluster)

    all_nodes = {n.node_name: n for n in nq.all()}
    all_ctrs  = cq.all()

    # node_name → {pod_name → {"namespace": str, "containers": [], "pseudo": bool}}
    node_pods: dict = {name: {} for name in all_nodes}

    for ctr in all_ctrs:
        pnm   = ctr.pod_node_map or {}
        pns   = ctr.pod_names or []
        nns   = ctr.node_names if isinstance(ctr.node_names, list) else ([ctr.node_names] if ctr.node_names else [])
        cdata = _ctr_dict(ctr)

        if pns:
            for pod in pns:
                node = pnm.get(pod)
                targets = [node] if node and node in node_pods else nns
                for n in targets:
                    if n not in node_pods:
                        node_pods[n] = {}
                    if pod not in node_pods[n]:
                        node_pods[n][pod] = {"namespace": ctr.namespace or "", "containers": [], "pseudo": False}
                    node_pods[n][pod]["containers"].append(cdata)
        else:
            # No pod data: one pseudo-entry per container per node
            for n in nns:
                if n not in node_pods:
                    node_pods[n] = {}
                pseudo_key = f"__ctr__{ctr.container_id}"
                if pseudo_key not in node_pods[n]:
                    node_pods[n][pseudo_key] = {"namespace": ctr.namespace or "", "containers": [], "pseudo": True}
                node_pods[n][pseudo_key]["containers"].append(cdata)

    result = []
    for node_name, node in all_nodes.items():
        nd = _node_dict(node)
        pods = node_pods.get(node_name, {})
        nd["pods"] = [
            {
                "pod_name":   pname,
                "namespace":  pinfo["namespace"],
                "pseudo":     pinfo.get("pseudo", False),
                "containers": pinfo["containers"],
            }
            for pname, pinfo in sorted(pods.items())
        ]
        result.append(nd)

    return {"nodes": result}


@app.post("/api/containers/{container_id:path}/approve")
def approve_container(container_id: str, body: StatusBody = StatusBody(),
                      db: Session = Depends(get_db)):
    return _set_ctr_status(container_id, "approved", body.performed_by, db)


@app.post("/api/containers/{container_id:path}/ignore")
def ignore_container(container_id: str, body: StatusBody = StatusBody(),
                     db: Session = Depends(get_db)):
    return _set_ctr_status(container_id, "ignored", body.performed_by, db)


def _set_ctr_status(container_id, status, performed_by, db):
    c = db.query(Container).filter(Container.container_id == container_id).first()
    if not c:
        raise HTTPException(404, "Container not found")
    c.status = status
    db.add(ActionHistory(entity_type="container", entity_name=container_id,
                         action=status, performed_by=performed_by, details={}))
    db.commit()
    if container_id in _LIVE["containers"]:
        _LIVE["containers"][container_id]["status"] = status
    return {"ok": True, "status": status}


# ── Disks ─────────────────────────────────────────────────────────────────────

# Rough per-GB monthly cost estimates (USD) by SKU family
_DISK_COST_PER_GB = {
    "Standard_LRS":    0.040,   # Standard HDD
    "StandardSSD_LRS": 0.075,   # Standard SSD
    "StandardSSD_ZRS": 0.090,
    "Premium_LRS":     0.170,   # Premium SSD
    "Premium_ZRS":     0.200,
    "UltraSSD_LRS":    0.290,
}

# ── ARM bulk helper ────────────────────────────────────────────────────────────

def _arm_get_all_pages(url: str, token: str, timeout: int = 30) -> list:
    """Fetch all pages of an ARM list response (follows nextLink)."""
    results = []
    next_url = url
    while next_url:
        req = urllib.request.Request(next_url, headers={"Authorization": f"Bearer {token}"})
        with urllib.request.urlopen(req, context=_ssl_ctx, timeout=timeout) as r:
            data = json.loads(r.read().decode())
        results.extend(data.get("value", []))
        next_url = data.get("nextLink")
    return results


def _arm_fetch_sub(sub_id: str, resource_path: str, token: str, api_version: str) -> tuple:
    """Fetch all pages for one subscription. Returns (sub_id, items, error_str|None)."""
    url = f"https://management.azure.com/subscriptions/{sub_id}/{resource_path}?api-version={api_version}"
    try:
        items = _arm_get_all_pages(url, token)
        return sub_id, items, None
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        return sub_id, [], f"HTTP {e.code} — {body[:200]}"
    except Exception as e:
        return sub_id, [], str(e)


def _arm_fetch_parallel(sub_ids: list, resource_path: str, token: str,
                        api_version: str, max_workers: int = 8) -> tuple:
    """
    Fetch resource_path across all sub_ids in parallel.
    Returns (all_items, errors) where each item has subscription_id injected.
    """
    all_items, errors = [], []
    with ThreadPoolExecutor(max_workers=min(max_workers, len(sub_ids))) as pool:
        futures = {
            pool.submit(_arm_fetch_sub, sid, resource_path, token, api_version): sid
            for sid in sub_ids
        }
        for future in as_completed(futures):
            sub_id, items, err = future.result()
            if err:
                errors.append(f"{sub_id}: {err}")
            else:
                for item in items:
                    item["_sub_id"] = sub_id  # inject so parsers can read it
                all_items.extend(items)
    return all_items, errors


# ── Delta-polling cache for disks and snapshots ───────────────────────────────
# Background jobs refresh the cache every _RESOURCE_CACHE_TTL seconds.
# API endpoints serve from cache instantly; first call triggers a synchronous
# fetch when the cache is cold (app startup).

_RESOURCE_CACHE_TTL = 300          # 5 minutes
_disks_cache:     dict = {"data": None, "updated_at": 0.0, "lock": None}
_snapshots_cache: dict = {"data": None, "updated_at": 0.0, "lock": None}

# Initialise locks after import so they use the running event loop correctly
_disks_cache["lock"]     = threading.Lock()
_snapshots_cache["lock"] = threading.Lock()


def _build_disks_payload(raw_items: list, errors: list) -> dict:
    all_disks = []
    for disk in raw_items:
        props = disk.get("properties", {})
        if props.get("diskState") != "Unattached":
            continue
        sku_name = disk.get("sku", {}).get("name", "")
        size_gb  = props.get("diskSizeGB") or 0
        disk_id  = disk.get("id", "")
        rg       = disk_id.split("/")[4] if disk_id.count("/") >= 4 else ""
        all_disks.append({
            "id":                disk_id,
            "name":              disk.get("name", ""),
            "resource_group":    rg,
            "location":          disk.get("location", ""),
            "size_gb":           size_gb,
            "sku_name":          sku_name,
            "disk_state":        props.get("diskState", ""),
            "time_created":      props.get("timeCreated", ""),
            "subscription_id":   disk["_sub_id"],
            "tags":              disk.get("tags") or {},
            "estimated_cost_mo": round(size_gb * _DISK_COST_PER_GB.get(sku_name, 0.08), 2),
        })
    return {
        "disks":         all_disks,
        "total":         len(all_disks),
        "total_gb":      sum(d["size_gb"] for d in all_disks),
        "total_cost_mo": round(sum(d["estimated_cost_mo"] for d in all_disks), 2),
        "errors":        errors,
        "cached_at":     time.time(),
    }


def _refresh_disks_cache():
    """Fetch all unattached disks from Azure and update the in-memory cache."""
    token = _get_azure_token()
    if not token:
        return
    sub_ids = _get_subscription_ids(token)
    if not sub_ids:
        return
    try:
        raw_items, errors = _arm_fetch_parallel(
            sub_ids, "providers/Microsoft.Compute/disks", token, "2023-04-02"
        )
        payload = _build_disks_payload(raw_items, errors)
        with _disks_cache["lock"]:
            _disks_cache["data"]       = payload
            _disks_cache["updated_at"] = time.time()
        if errors:
            print(f"[Disks cache] Errors: {errors}")
        print(f"[Disks cache] Refreshed: {payload['total']} unattached disks")
    except Exception as e:
        print(f"[Disks cache] Refresh failed: {e}")


@app.get("/api/disks")
def list_unattached_disks(_session: dict = Depends(_get_session)):
    """
    Return unattached managed disks from cache (refreshed every 5 min by background job).
    First request after startup triggers a synchronous fetch if cache is cold.
    """
    with _disks_cache["lock"]:
        cached = _disks_cache["data"]
        age    = time.time() - _disks_cache["updated_at"]

    if cached is None or age > _RESOURCE_CACHE_TTL:
        # Cache cold or stale — refresh synchronously
        _refresh_disks_cache()
        with _disks_cache["lock"]:
            cached = _disks_cache["data"]

    if cached is None:
        raise HTTPException(503, "Azure token unavailable — check credentials in Settings")

    return cached


# ── Snapshots ─────────────────────────────────────────────────────────────────

_SNAPSHOT_COST_PER_GB = {
    "Standard_LRS": 0.050,
    "Premium_LRS":  0.070,
    "Standard_ZRS": 0.060,
    "Premium_ZRS":  0.085,
}

def _build_snapshots_payload(raw_items: list, errors: list) -> dict:
    all_snaps = []
    for snap in raw_items:
        props    = snap.get("properties", {})
        sku_name = snap.get("sku", {}).get("name", "Standard_LRS")
        size_gb  = props.get("diskSizeGB") or 0
        snap_id  = snap.get("id", "")
        rg       = snap_id.split("/")[4] if snap_id.count("/") >= 4 else ""
        all_snaps.append({
            "id":                 snap_id,
            "name":               snap.get("name", ""),
            "resource_group":     rg,
            "location":           snap.get("location", ""),
            "size_gb":            size_gb,
            "sku_name":           sku_name,
            "time_created":       props.get("timeCreated", ""),
            "source_resource_id": props.get("creationData", {}).get("sourceResourceId", ""),
            "subscription_id":    snap["_sub_id"],
            "tags":               snap.get("tags") or {},
            "estimated_cost_mo":  round(size_gb * _SNAPSHOT_COST_PER_GB.get(sku_name, 0.05), 2),
        })
    total_gb   = sum(s["size_gb"] for s in all_snaps)
    total_cost = round(sum(s["estimated_cost_mo"] for s in all_snaps), 2)
    return {
        "snapshots":     all_snaps,
        "total":         len(all_snaps),
        "total_gb":      total_gb,
        "total_cost_mo": total_cost,
        "errors":        errors,
        "cached_at":     time.time(),
    }


def _refresh_snapshots_cache():
    """Fetch all snapshots from Azure and update the in-memory cache."""
    token = _get_azure_token()
    if not token:
        return
    sub_ids = _get_subscription_ids(token)
    if not sub_ids:
        return
    try:
        raw_items, errors = _arm_fetch_parallel(
            sub_ids, "providers/Microsoft.Compute/snapshots", token, "2023-04-02"
        )
        payload = _build_snapshots_payload(raw_items, errors)
        with _snapshots_cache["lock"]:
            _snapshots_cache["data"]       = payload
            _snapshots_cache["updated_at"] = time.time()
        if errors:
            print(f"[Snapshots cache] Errors: {errors}")
        print(f"[Snapshots cache] Refreshed: {payload['total']} snapshots")
    except Exception as e:
        print(f"[Snapshots cache] Refresh failed: {e}")


@app.get("/api/snapshots")
def list_snapshots(_session: dict = Depends(_get_session)):
    """
    Return snapshots from cache (refreshed every 5 min by background job).
    First request after startup triggers a synchronous fetch if cache is cold.
    """
    with _snapshots_cache["lock"]:
        cached = _snapshots_cache["data"]
        age    = time.time() - _snapshots_cache["updated_at"]

    if cached is None or age > _RESOURCE_CACHE_TTL:
        _refresh_snapshots_cache()
        with _snapshots_cache["lock"]:
            cached = _snapshots_cache["data"]

    if cached is None:
        raise HTTPException(503, "Azure token unavailable — check credentials in Settings")

    return cached


# ── Database-backed Disk & Snapshot API (with portal links) ────────────────────

@app.get("/api/db/disks")
def list_db_disks(subscription_id: str = None, region: str = None, sku: str = None,
                  attached_only: bool = False, orphaned_only: bool = False,
                  db: Session = Depends(get_db)):
    """
    Return managed disks from database with portal deep-links and ownership tracking.
    Includes sizing, SKU, monthly cost, attachment status, and days since last use.

    Parameters:
      - subscription_id: Filter by subscription
      - region: Filter by region
      - sku: Filter by SKU type
      - attached_only: Only show attached disks
      - orphaned_only: Only show orphaned (unattached) disks
    """
    q = db.query(Disk)
    if subscription_id:
        q = q.filter(Disk.subscription_id == subscription_id)
    if region:
        q = q.filter(Disk.region == region)
    if sku:
        q = q.filter(Disk.sku == sku)
    if attached_only:
        q = q.filter(Disk.is_attached == True)
    if orphaned_only:
        q = q.filter(Disk.is_attached == False)

    disks = q.order_by(Disk.disk_name).all()
    result = []
    for d in disks:
        result.append({
            "id":                    d.id,
            "disk_name":             d.disk_name,
            "disk_id":               d.disk_id,
            "subscription_id":       d.subscription_id,
            "resource_group":        d.resource_group,
            "region":                d.region,
            "sku":                   d.sku,
            "size_gb":               d.size_gb,
            "iops":                  d.iops,
            "throughput_mbps":       d.throughput_mbps,
            "monthly_cost":          d.monthly_cost,
            "portal_url":            d.portal_url,
            "is_attached":           d.is_attached,
            "attached_vm_ids":       d.attached_vm_ids or [],
            "creation_time":         d.creation_time.isoformat() if d.creation_time else None,
            "last_attachment_time":  d.last_attachment_time.isoformat() if d.last_attachment_time else None,
            "days_since_last_use":   d.days_since_last_use,
            "deletion_eligible":     d.days_since_last_use and d.days_since_last_use > 30,
            "fetched_at":            d.fetched_at.isoformat() if d.fetched_at else None,
        })

    total_monthly_cost = sum(d.get("monthly_cost", 0) for d in result)
    orphaned_count = sum(1 for d in result if not d["is_attached"])
    deletion_eligible_count = sum(1 for d in result if d["deletion_eligible"])
    deletion_savings = sum(d["monthly_cost"] for d in result if d["deletion_eligible"])

    return {
        "disks": result,
        "total_count": len(result),
        "total_monthly_cost": round(total_monthly_cost, 2),
        "orphaned_count": orphaned_count,
        "deletion_eligible_count": deletion_eligible_count,
        "deletion_potential_savings": round(deletion_savings, 2),
    }


@app.get("/api/db/disks/cleanup")
def disks_for_cleanup(min_age_days: int = 30, db: Session = Depends(get_db)):
    """
    Return disks eligible for deletion (orphaned for >30 days or unattached).
    Shows potential cost savings from cleanup.
    """
    disks = db.query(Disk).filter(
        Disk.is_attached == False,
        Disk.days_since_last_use >= min_age_days
    ).order_by(Disk.days_since_last_use.desc()).all()

    result = []
    for d in disks:
        result.append({
            "disk_name":             d.disk_name,
            "disk_id":               d.disk_id,
            "subscription_id":       d.subscription_id,
            "region":                d.region,
            "sku":                   d.sku,
            "size_gb":               d.size_gb,
            "monthly_cost":          d.monthly_cost,
            "portal_url":            d.portal_url,
            "days_since_last_use":   d.days_since_last_use,
            "last_attachment_time":  d.last_attachment_time.isoformat() if d.last_attachment_time else None,
            "deletion_risk":         "low" if d.days_since_last_use < 90 else "medium" if d.days_since_last_use < 365 else "high",
        })

    total_savings = sum(d["monthly_cost"] for d in result)
    return {
        "disks": result,
        "total_count": len(result),
        "total_monthly_savings": round(total_savings, 2),
        "annual_savings": round(total_savings * 12, 2),
    }


@app.get("/api/db/snapshots")
def list_db_snapshots(subscription_id: str = None, region: str = None, sku: str = None,
                      min_age_days: int = None, db: Session = Depends(get_db)):
    """
    Return disk snapshots from database with portal deep-links.
    Includes sizing, SKU, monthly cost estimates, age, and clickable Azure Portal URLs.
    Useful for identifying old snapshots to archive/delete.
    """
    q = db.query(Snapshot)
    if subscription_id:
        q = q.filter(Snapshot.subscription_id == subscription_id)
    if region:
        q = q.filter(Snapshot.region == region)
    if sku:
        q = q.filter(Snapshot.sku == sku)
    if min_age_days:
        q = q.filter(Snapshot.age_days >= min_age_days)

    snapshots = q.order_by(Snapshot.snapshot_name).all()
    result = []
    for s in snapshots:
        result.append({
            "id":                  s.id,
            "snapshot_name":       s.snapshot_name,
            "snapshot_id":         s.snapshot_id,
            "subscription_id":     s.subscription_id,
            "resource_group":      s.resource_group,
            "region":              s.region,
            "sku":                 s.sku,
            "size_gb":             s.size_gb,
            "monthly_cost":        s.monthly_cost,
            "portal_url":          s.portal_url,
            "source_disk_id":      s.source_disk_id,
            "source_snapshot_id":  s.source_snapshot_id,
            "age_days":            s.age_days,
            "creation_time":       s.creation_time.isoformat() if s.creation_time else None,
            "fetched_at":          s.fetched_at.isoformat() if s.fetched_at else None,
        })

    total_monthly_cost = sum(s.get("monthly_cost", 0) for s in result)
    return {
        "snapshots": result,
        "total_count": len(result),
        "total_monthly_cost": round(total_monthly_cost, 2),
    }


# ── SKU Advisor ───────────────────────────────────────────────────────────────

class SkuAdvisorRequest(BaseModel):
    workload_type:   str = ""   # web_api | database | analytics | ml | batch | general
    cpu_intensity:   str = ""   # light | moderate | heavy | cpu_bound
    memory_need:     str = ""   # low | moderate | high | very_high
    peak_behavior:   str = ""   # steady | bursty | scheduled | always_high
    priority:        str = ""   # cost | balanced | performance
    region:          str = ""
    gpu_needed:      bool = False
    high_disk_io:    bool = False
    high_network:    bool = False
    spot_ok:         bool = False
    current_problems: str = ""  # free text: OOM, throttling, etc.
    extra_context:   str = ""   # any additional free text

@app.post("/api/sku-advisor")
def sku_advisor(body: SkuAdvisorRequest, db: Session = Depends(get_db),
                sku_db: Session = Depends(get_sku_db),
                _session: dict = Depends(_get_session)):
    """
    Ask AI to recommend the best Azure VM SKUs based on workload requirements.
    Queries the local SKU DB to ground the AI with real, available options.
    """
    # ── 1. Pull candidate SKUs from DB ────────────────────────────────────────
    q = sku_db.query(VmSku).filter(VmSku.vcpus.isnot(None), VmSku.memory_gb.isnot(None))

    # Narrow by rough CPU/memory signals to keep the prompt manageable
    cpu_min, cpu_max, mem_min, mem_max = 1, 9999, 0.0, 99999.0
    if body.cpu_intensity == "light":      cpu_max = 4
    elif body.cpu_intensity == "moderate": cpu_min, cpu_max = 2, 16
    elif body.cpu_intensity == "heavy":    cpu_min = 8
    elif body.cpu_intensity == "cpu_bound": cpu_min = 16

    if body.memory_need == "low":       mem_max = 16.0
    elif body.memory_need == "moderate": mem_min, mem_max = 4.0, 64.0
    elif body.memory_need == "high":     mem_min = 16.0
    elif body.memory_need == "very_high": mem_min = 32.0

    q = q.filter(VmSku.vcpus >= cpu_min, VmSku.vcpus <= cpu_max,
                 VmSku.memory_gb >= mem_min, VmSku.memory_gb <= mem_max)

    if body.gpu_needed:
        q = q.filter(VmSku.gpu_count.isnot(None), VmSku.gpu_count > 0)

    if body.region:
        region_rows = q.filter(VmSku.region.ilike(f"%{body.region}%")).limit(60).all()
        candidates  = region_rows or q.limit(60).all()
    else:
        candidates = q.order_by(VmSku.vcpus, VmSku.memory_gb).limit(60).all()

    if not candidates:
        candidates = sku_db.query(VmSku).filter(VmSku.vcpus.isnot(None)).limit(40).all()

    # Format SKU list for the prompt (keep it tight)
    sku_lines = []
    for s in candidates:
        price_mo = round((s.price_linux_hr or 0) * 730, 2)
        gpu_part = f"  GPU:{s.gpu_count}" if (s.gpu_count or 0) > 0 else ""
        sku_lines.append(
            f"  {s.sku_name:<28} vCPU:{s.vcpus:<3} Mem:{s.memory_gb:<6}GB"
            f"  ${price_mo:>8}/mo  region:{s.region or '?'}{gpu_part}"
        )

    # ── 2. Build the prompt ───────────────────────────────────────────────────
    req_parts = []
    _wt = {"web_api":"Web/API server","database":"Database","analytics":"Analytics/Data processing",
           "ml":"Machine learning / AI","batch":"Batch processing","general":"General purpose"}
    _ci = {"light":"Light (<20% CPU avg)","moderate":"Moderate (20–60% CPU avg)",
           "heavy":"Heavy (60–80% CPU avg)","cpu_bound":"CPU-bound (>80%)"}
    _mn = {"low":"Low (<8 GB RAM)","moderate":"Moderate (8–32 GB)","high":"High (32–64 GB)","very_high":"Very high (>64 GB)"}
    _pb = {"steady":"Steady / flat","bursty":"Bursty spikes","scheduled":"Scheduled peaks","always_high":"Consistently high"}
    _pr = {"cost":"Minimise cost","balanced":"Balance cost & performance","performance":"Maximise performance"}

    if body.workload_type:   req_parts.append(f"Workload type: {_wt.get(body.workload_type, body.workload_type)}")
    if body.cpu_intensity:   req_parts.append(f"CPU intensity: {_ci.get(body.cpu_intensity, body.cpu_intensity)}")
    if body.memory_need:     req_parts.append(f"Memory need:   {_mn.get(body.memory_need, body.memory_need)}")
    if body.peak_behavior:   req_parts.append(f"Peak pattern:  {_pb.get(body.peak_behavior, body.peak_behavior)}")
    if body.priority:        req_parts.append(f"Priority:      {_pr.get(body.priority, body.priority)}")
    if body.region:          req_parts.append(f"Azure region:  {body.region}")
    if body.gpu_needed:      req_parts.append("GPU required: yes")
    if body.high_disk_io:    req_parts.append("High disk I/O: yes")
    if body.high_network:    req_parts.append("High network throughput: yes")
    if body.spot_ok:         req_parts.append("Spot/preemptible: acceptable")
    if body.current_problems: req_parts.append(f"Current issues: {body.current_problems}")
    if body.extra_context:   req_parts.append(f"Extra context: {body.extra_context}")

    system_msg = (
        "You are an expert Azure VM SKU selection advisor. "
        "Given workload requirements and a list of available Azure VM SKUs with real pricing, "
        "recommend exactly 3 SKUs ranked best-to-third. "
        "For each recommendation return a JSON object with keys: "
        "sku_name, why, trade_offs, monthly_cost_usd, vcpus, memory_gb, rank (1/2/3). "
        "Return ONLY a JSON array of 3 objects — no markdown, no explanation outside the array."
    )

    prompt = f"""=== WORKLOAD REQUIREMENTS ===
{chr(10).join(req_parts) or 'General purpose workload, no specific constraints.'}

=== AVAILABLE SKUs (from the customer's Azure subscription) ===
{chr(10).join(sku_lines) if sku_lines else 'No SKUs in DB — recommend based on Azure general availability.'}

Recommend the 3 best-fit SKUs from the list above (or well-known Azure SKUs if the list is empty).
Return a JSON array only."""

    # ── 3. Call AI ────────────────────────────────────────────────────────────
    try:
        raw = _call_openai(prompt, max_tokens=1200, system=system_msg)
    except HTTPException as e:
        raise
    except Exception as e:
        raise HTTPException(502, f"AI call failed: {e}")

    # Parse JSON from the response (handle markdown fences)
    raw_clean = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
    try:
        recommendations = json.loads(raw_clean)
        if not isinstance(recommendations, list):
            recommendations = [recommendations]
    except Exception:
        # Return raw text if JSON parse fails
        recommendations = [{"sku_name": "See reason", "why": raw, "trade_offs": "",
                            "monthly_cost_usd": 0, "vcpus": 0, "memory_gb": 0, "rank": 1}]

    return {"recommendations": recommendations, "candidates_checked": len(candidates)}


# ── SKU Advisor Chat ───────────────────────────────────────────────────────────

class SkuChatMessage(BaseModel):
    role: str     # "user" or "assistant"
    content: str

class SkuChatRequest(BaseModel):
    messages: List[SkuChatMessage]

_SKU_CHAT_SYSTEM = """\
You are an Azure VM SKU selection advisor. Have a friendly, focused conversation to understand the user's workload needs, then recommend the 3 best-fit VM SKUs.

CONVERSATION RULES:
1. Ask clarifying questions ONE AT A TIME. Cover these topics (in a natural order):
   - Workload type (web server, database, analytics, machine learning, batch, etc.)
   - CPU intensity (light <20%, moderate 20-60%, heavy 60-80%, CPU-bound >80%)
   - Memory requirements (low <8 GB, moderate 8-32 GB, high 32-64 GB, very high >64 GB)
   - Load pattern (steady, bursty spikes, scheduled peaks, always high)
   - Priority (minimise cost, balance cost & performance, maximise performance)
   - Azure region (optional)
   - Special needs: GPU, spot/preemptible VMs, high disk I/O, high network throughput
   - Current problems (OOM kills, CPU throttling, high costs, etc.)
2. Stop asking after 5-6 exchanges OR when you have enough info to make confident recommendations.
3. ALWAYS respond with valid JSON — no text outside the JSON.

RESPONSE FORMATS (use exactly one per reply):

While gathering info:
{"type": "question", "text": "Your question here"}

When ready to recommend (you MUST include 3 ranked recommendations):
{"type": "recommendations", "text": "Brief summary of why these SKUs fit the workload", "recommendations": [{"rank": 1, "sku_name": "Standard_D4s_v5", "why": "...", "trade_offs": "...", "monthly_cost_usd": 140, "vcpus": 4, "memory_gb": 16}, ...]}

Return ONLY the JSON object — nothing else."""


@app.post("/api/sku-advisor/chat")
def sku_advisor_chat(body: SkuChatRequest,
                     sku_db: Session = Depends(get_sku_db),
                     _session: dict = Depends(_get_session)):
    """
    Conversational SKU advisor: AI asks clarifying questions then recommends 3 SKUs.
    After enough user responses, real SKU pricing data is injected as context.
    """
    user_msgs = [m for m in body.messages if m.role == "user"]

    # Build the system prompt, injecting SKU inventory after 2+ user responses
    system_msg = _SKU_CHAT_SYSTEM
    if len(user_msgs) >= 2:
        try:
            candidates = (sku_db.query(VmSku)
                          .filter(VmSku.vcpus.isnot(None), VmSku.memory_gb.isnot(None))
                          .order_by(VmSku.vcpus, VmSku.memory_gb)
                          .limit(50).all())
            if candidates:
                sku_lines = []
                for s in candidates:
                    price_mo = round((s.price_linux_hr or 0) * 730, 2)
                    gpu_part = f"  GPU:{s.gpu_count}" if (s.gpu_count or 0) > 0 else ""
                    sku_lines.append(
                        f"  {s.sku_name:<28} vCPU:{s.vcpus:<3} Mem:{s.memory_gb:<6}GB"
                        f"  ${price_mo:>8}/mo  region:{s.region or '?'}{gpu_part}"
                    )
                system_msg += (
                    "\n\nAVAILABLE SKUs FROM CUSTOMER'S AZURE INVENTORY "
                    "(use these for recommendations — pick from this list when possible):\n"
                    + "\n".join(sku_lines)
                )
        except Exception:
            pass  # If SKU DB unavailable, proceed without it

    # Assemble messages for the AI call
    messages = [{"role": "system", "content": system_msg}]
    for m in body.messages:
        messages.append({"role": m.role, "content": m.content})

    try:
        raw = _call_openai_messages(messages, max_tokens=1500)
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(502, f"AI call failed: {e}")

    raw_clean = re.sub(r"```(?:json)?", "", raw).strip().rstrip("`").strip()
    try:
        parsed = json.loads(raw_clean)
    except Exception:
        # Treat unparseable response as a question
        parsed = {"type": "question", "text": raw_clean}

    return parsed


# ── AI assessment ─────────────────────────────────────────────────────────────
_ssl_ctx = ssl.create_default_context()
_ssl_ctx.check_hostname = False
_ssl_ctx.verify_mode = ssl.CERT_NONE


def _call_openai_messages(messages: list, max_tokens: int = 800) -> str:
    """Send a pre-built messages list to the configured AI provider and return the reply text."""
    _endpoint   = OPENAI_ENDPOINT   or os.environ.get("OPENAI_ENDPOINT", "")
    _deployment = OPENAI_DEPLOYMENT or os.environ.get("OPENAI_DEPLOYMENT", "")
    _key        = OPENAI_KEY        or os.environ.get("OPENAI_KEY", "")
    if not _key:
        raise HTTPException(503, "OpenAI key not configured")

    if _endpoint and _deployment:
        api_version = os.environ.get("OPENAI_API_VERSION") or "2024-05-01-preview"
        url = (
            f"{_endpoint.rstrip('/')}/openai/deployments"
            f"/{_deployment}/chat/completions?api-version={api_version}"
        )
        payload = json.dumps({"messages": messages, "max_tokens": max_tokens, "temperature": 0.4}).encode()
        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("api-key", _key)
    else:
        payload = json.dumps({"model": "gpt-4o", "messages": messages, "max_tokens": max_tokens, "temperature": 0.4}).encode()
        req = urllib.request.Request("https://api.openai.com/v1/chat/completions", data=payload, method="POST")
        req.add_header("Authorization", f"Bearer {_key}")

    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, context=_ssl_ctx, timeout=180) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body_text = e.read().decode(errors="replace")
        try:
            err_msg = json.loads(body_text).get("error", {}).get("message", body_text)
        except Exception:
            err_msg = body_text
        raise HTTPException(502, f"AI error {e.code}: {err_msg}")
    except urllib.error.URLError as e:
        raise HTTPException(502, f"AI unreachable: {e.reason}")
    choices = data.get("choices") or []
    if not choices:
        raise HTTPException(502, f"OpenAI returned no choices: {data}")
    return choices[0]["message"]["content"].strip()


def _call_openai(prompt: str, max_tokens: int = 400, system: str = "") -> str:
    messages = []
    if system:
        messages.append({"role": "system", "content": system})
    messages.append({"role": "user", "content": prompt})

    # ── Azure OpenAI ──────────────────────────────────────────────────────────
    # Uses: https://<resource>.openai.azure.com/openai/deployments/<deployment>/chat/completions
    # Auth: api-key header (NOT Bearer token)
    # Model field: omitted (deployment name IS the model selector in Azure OpenAI)
    # Always re-read from env at call time so App Setting changes take effect
    # without a full redeploy (restart is enough)
    _endpoint   = OPENAI_ENDPOINT   or os.environ.get("OPENAI_ENDPOINT", "")
    _deployment = OPENAI_DEPLOYMENT or os.environ.get("OPENAI_DEPLOYMENT", "")
    _key        = OPENAI_KEY        or os.environ.get("OPENAI_KEY", "")
    if not _key:
        raise HTTPException(503, "OpenAI key not configured")
    print(f"[AI] provider={'azure' if (_endpoint and _deployment) else 'openai.com'}  endpoint={_endpoint or '(none)'}  deployment={_deployment or '(none)'}")
    if _endpoint and _deployment:
        api_version = os.environ.get("OPENAI_API_VERSION") or "2024-05-01-preview"
        url = (
            f"{_endpoint.rstrip('/')}/openai/deployments"
            f"/{_deployment}/chat/completions?api-version={api_version}"
        )
        print(f"[AI] url={url}")
        payload = json.dumps({
            "messages":   messages,
            "max_tokens": max_tokens,
            "temperature": 0.1,
        }).encode()
        req = urllib.request.Request(url, data=payload, method="POST")
        req.add_header("api-key", _key)
    # ── Standard OpenAI ───────────────────────────────────────────────────────
    else:
        payload = json.dumps({
            "model":      "gpt-4o",
            "messages":   messages,
            "max_tokens": max_tokens,
            "temperature": 0.1,
        }).encode()
        req = urllib.request.Request(
            "https://api.openai.com/v1/chat/completions", data=payload, method="POST")
        req.add_header("Authorization", f"Bearer {_key}")

    req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, context=_ssl_ctx, timeout=180) as resp:
            data = json.loads(resp.read())
    except urllib.error.HTTPError as e:
        body = e.read().decode(errors="replace")
        try:
            err_detail = json.loads(body)
            err_msg = err_detail.get("error", {}).get("message", body)
        except Exception:
            err_msg = body
        print(f"[AI] Azure/OpenAI HTTP {e.code}: {err_msg}")
        raise HTTPException(502, f"AI error {e.code}: {err_msg}")
    except urllib.error.URLError as e:
        print(f"[AI] Azure/OpenAI unreachable: {e.reason}")
        raise HTTPException(502, f"AI unreachable: {e.reason}")
    except Exception as e:
        print(f"[AI] call failed: {e}")
        raise HTTPException(502, f"AI call failed: {e}")
    choices = data.get("choices") or []
    if not choices:
        raise HTTPException(502, f"OpenAI returned no choices: {data}")
    return choices[0]["message"]["content"].strip()


class AssessBody(BaseModel):
    performed_by: str = "user"


@app.post("/api/nodes/assess-all")
def assess_all_nodes(db: Session = Depends(get_db)):
    """Send all node + container data to OpenAI for a holistic cluster analysis."""
    if not (OPENAI_KEY or os.environ.get("OPENAI_KEY")):
        raise HTTPException(503, "OpenAI key not configured")

    nodes = db.query(Node).order_by(Node.saving.desc().nullslast()).all()
    if not nodes:
        return {"assessed": 0, "summary": "No nodes found in database."}

    pending    = [n for n in nodes if n.status == "pending" and n.rec_sku]
    clusters   = sorted({n.cluster for n in nodes if n.cluster})
    nodepools  = sorted({f"{n.cluster}/{n.nodepool}" for n in nodes if n.cluster and n.nodepool})
    total_save = sum(n.saving or 0 for n in pending)

    ctrs = db.query(Container).all()
    ns_counts: dict = {}
    for c in ctrs:
        ns_counts[c.namespace or "—"] = ns_counts.get(c.namespace or "—", 0) + 1

    # Build per-node summary (cap at 80 nodes to stay within token limits)
    node_lines = []
    for n in nodes[:80]:
        node_lines.append(
            f"  [{n.status or 'pending'}] {n.node_name} "
            f"({n.cluster}/{n.nodepool}, {n.region}): "
            f"{n.current_sku} → {n.rec_sku or 'optimal'} | "
            f"CPU {n.cpu_avg_pct or 0:.0f}%avg/{n.cpu_max_pct or 0:.0f}%peak | "
            f"Mem {n.mem_avg_pct or 0:.0f}%avg/{n.mem_max_pct or 0:.0f}%peak | "
            f"saves ${n.saving or 0:.0f}/mo"
        )

    # Build full container details (cap at 60 to stay within token limits)
    def _mfmt(v): return f"{v or 0:.0f}Mi"
    def _cfmt(v): return f"{(v or 0)*1000:.0f}m"
    ctr_lines = []
    for c in ctrs[:60]:
        lim_cpu = _cfmt(c.cpu_limit)  if c.cpu_limit  else "none"
        lim_mem = _mfmt(c.mem_limit_mib) if c.mem_limit_mib else "none"
        rec_str = ""
        if c.rec_cpu_request or c.rec_mem_req:
            rec_str = f" → rec CPU={_cfmt(c.rec_cpu_request)}/Mem={_mfmt(c.rec_mem_req)}"
        ctr_lines.append(
            f"  [{c.status or 'pending'}] {c.container_name} ({c.namespace},{c.cluster},{c.pod_count or 0}pods): "
            f"CPU req={_cfmt(c.cpu_request)}/lim={lim_cpu}/avg={_cfmt(c.cpu_avg)}({c.cpu_util_pct or 0:.0f}%) | "
            f"Mem req={_mfmt(c.mem_request_mib)}/lim={lim_mem}/avg={_mfmt(c.mem_avg_mib)}({c.mem_util_pct or 0:.0f}%)"
            + rec_str
        )
    ns_list = sorted({c.namespace for c in ctrs if c.namespace})

    batch_system = (
        "You are an expert AKS infrastructure engineer specialising in cost optimisation. "
        "Analyse the full cluster holistically. Apply this decision hierarchy for every recommendation:\n"
        "  1. Container health (throttling / OOMKill) — fix before any SKU change.\n"
        "  2. Container right-sizing — over-provisioned requests make nodes look under-utilised. Fix first.\n"
        "  3. SKU family fitness — wrong series wastes money regardless of size.\n"
        "  4. SKU downsize/upsize — only after 1-3 are addressed.\n"
        "  5. Always preserve ≥30% headroom above peak on recommended SKU.\n"
        "Sequence matters: recommend containers before nodes."
    )

    prompt = f"""=== CLUSTER OVERVIEW ===
Clusters: {', '.join(clusters)}
Total nodes: {len(nodes)}  |  Pending rightsizing: {len(pending)}  |  Total potential saving: ${total_save:.0f}/mo
Nodepools: {', '.join(nodepools)}

=== NODE DETAILS ({min(len(nodes),80)} of {len(nodes)}) ===
Format: [status] name (cluster/pool, region): current→rec | CPU avg/peak | Mem avg/peak | saving
{chr(10).join(node_lines)}

=== CONTAINER DETAILS ({min(len(ctrs),60)} of {len(ctrs)} across {len(ns_list)} namespaces) ===
Format: [status] name (namespace, cluster, pods): CPU req/lim/avg(util%) max(%) | Mem req/lim/avg(util%) max(%) → rec
{chr(10).join(ctr_lines)}

=== ANALYSIS REQUIRED ===

AT_RISK_CONTAINERS:
List every container with OOMKill risk (mem peak ≥80% of limit) or CPU throttling (cpu peak ≥95% of limit).
Give specific remediation for each.

CONTAINER_RIGHTSIZING_FIRST:
List nodes where container over-provisioning is masking the real node utilisation.
For each: what container requests should change, and what does the effective node utilisation become after that change?

SKU_FAMILY_MISMATCHES:
Identify nodes where the workload CPU:memory ratio doesn't match the SKU series type.
Suggest the correct family with justification.

PRIORITY_ACTIONS:
Top 5 actions ranked by monthly saving × confidence, in order:
1. [container/node] specific action → $X/mo saving, risk: low/medium/high
(repeat for 2-5)

RISKS:
Nodes or containers where any change carries medium/high risk. Explain why.

SUMMARY:
3-4 sentences: total realizable saving after sequencing, biggest risk, recommended first step.

Output the following line EXACTLY at the end (integer dollar value):
TOTAL_SAVING_ESTIMATE: $<integer>/mo
"""

    result = _call_openai(prompt, max_tokens=2000, system=batch_system)
    # Parse AI-estimated total saving from the structured output line
    ai_saving_match = re.search(r"TOTAL_SAVING_ESTIMATE:\s*\$?([\d,]+)", result, re.I)
    ai_total_saving = int(ai_saving_match.group(1).replace(",", "")) if ai_saving_match else None
    return {
        "assessed": len(nodes),
        "pending":  len(pending),
        "total_saving": round(total_save, 2),
        "ai_total_saving": ai_total_saving,
        "clusters": clusters,
        "summary": result,
    }


@app.post("/api/nodes/{node_name:path}/assess")
def assess_node(node_name: str, body: AssessBody = AssessBody(),
                db: Session = Depends(get_db)):
    n = db.query(Node).filter(Node.node_name == node_name).first()
    if not n:
        raise HTTPException(404, "Node not found")

    # Build SKU price map for saving calculations
    _sdb = SkuSessionLocal()
    try:
        sku_map = _build_sku_map(_sdb, region=n.region)
    finally:
        _sdb.close()

    # Enrich with containers running on this node
    all_ctrs = db.query(Container).filter(Container.cluster == n.cluster).all()
    node_ctrs = [
        c for c in all_ctrs
        if (isinstance(c.node_names, list) and n.node_name in c.node_names)
        or c.node_names == n.node_name
    ]
    ctr_text = ""
    if node_ctrs:
        ctr_lines = [
            f"    - {c.container_name} ({c.namespace or '—'}): "
            f"CPU req={c.cpu_request or 0:.2f}/avg={c.cpu_avg or 0:.2f} cores, "
            f"Mem req={c.mem_request_mib or 0:.0f}/avg={c.mem_avg_mib or 0:.0f} MiB, "
            f"util CPU={c.cpu_util_pct or 0:.0f}%/Mem={c.mem_util_pct or 0:.0f}%"
            for c in node_ctrs[:12]
        ]
        ctr_text = f"\nContainers on this node ({len(node_ctrs)} total):\n" + "\n".join(ctr_lines)
        if len(node_ctrs) > 12:
            ctr_text += f"\n    ... and {len(node_ctrs) - 12} more"

    # Enrich with full SKU specs from SKU DB
    def _sku_detail(sku_name):
        if not sku_name:
            return {}
        try:
            sku_db = SkuSessionLocal()
            try:
                row = (sku_db.query(VmSku)
                       .filter(VmSku.sku_name == sku_name)
                       .order_by(VmSku.last_fetched_at.desc().nullslast())
                       .first())
            finally:
                sku_db.close()
        except Exception as e:
            print(f"assess_node: SKU lookup failed for {sku_name}: {e}")
            return {}
        if not row:
            return {}
        return {
            "vcpus":    row.vcpus,
            "mem_gb":   row.memory_gb,
            "type":     row.sku_type or "General purpose",
            "local_gb": row.local_storage_gb or 0,
            "prem_ssd": bool(row.premium_io),
            "accel_net":bool(row.accelerated_networking),
            "gpu":      row.gpu_count or 0,
            "rdma":     bool(row.rdma_enabled),
            "price_mo": round((row.price_linux_hr or 0) * 730, 0),
        }

    def _sku_line(sku_name):
        d = _sku_detail(sku_name)
        if not d:
            return sku_name or "—"
        flags = []
        if d["prem_ssd"]:   flags.append("PremSSD")
        if d["accel_net"]:  flags.append("AccelNet")
        if d["gpu"]:        flags.append(f"{d['gpu']}GPU")
        if d["rdma"]:       flags.append("RDMA")
        if d["local_gb"]:   flags.append(f"{d['local_gb']}GiB-local")
        return (f"{sku_name} [{d['type']}, {d['vcpus']}vCPU, {d['mem_gb']}GiB, "
                f"${d['price_mo']:.0f}/mo{(', ' + ', '.join(flags)) if flags else ''}]")

    # Identify containers at risk to surface as hard constraints
    at_risk_ctrs    = []
    over_req_ctrs   = []
    no_limits_ctrs  = []
    for c in node_ctrs:
        mem_pct  = c.mem_util_pct  or 0
        cpu_pct  = c.cpu_util_pct  or 0
        cpu_max  = c.cpu_max_pct   or 0
        mem_max  = c.mem_max_pct   or 0
        if mem_max >= 80 or (c.mem_limit_mib and c.mem_max_mib and c.mem_max_mib >= c.mem_limit_mib * 0.9):
            at_risk_ctrs.append(f"{c.container_name} (OOMKill risk: mem_max={c.mem_max_mib or 0:.0f}/{c.mem_limit_mib or 0:.0f}MiB)")
        if cpu_max >= 95 and c.cpu_limit:
            at_risk_ctrs.append(f"{c.container_name} (CPU throttled: cpu_max={cpu_max:.0f}% of limit)")
        if cpu_pct < 20 and mem_pct < 30:
            over_req_ctrs.append(f"{c.container_name} (CPU util={cpu_pct:.0f}%, Mem util={mem_pct:.0f}%)")
        if not c.cpu_limit or not c.mem_limit_mib:
            no_limits_ctrs.append(c.container_name)

    # Effective utilisation after hypothetical container right-sizing
    total_cpu_req = sum(c.cpu_request or 0 for c in node_ctrs)
    total_mem_req = sum(c.mem_request_mib or 0 for c in node_ctrs) / 1024  # GiB
    total_cpu_act = sum(c.cpu_avg or 0 for c in node_ctrs)
    total_mem_act = sum(c.mem_avg_mib or 0 for c in node_ctrs) / 1024
    node_cpu_cores = (n.cpu_alloc or 0)
    node_mem_gb    = (n.mem_alloc_gb or 0)

    # Recommended SKU spec for ratio analysis
    rec_d   = _sku_detail(n.rec_sku)
    cur_d   = _sku_detail(n.current_sku)
    workload_cpu_mem_ratio = round(total_mem_act / total_cpu_act, 1) if total_cpu_act > 0 else 0

    # QoS class per container (derived from request/limit relationship)
    guaranteed_ctrs = []   # request == limit (both CPU and mem) — can't burst, conservative downsize
    best_effort_ctrs = []  # no request AND no limit — first evicted under pressure
    for c in node_ctrs:
        has_req = bool(c.cpu_request or c.mem_request_mib)
        has_lim = bool(c.cpu_limit or c.mem_limit_mib)
        if not has_req and not has_lim:
            best_effort_ctrs.append(c.container_name)
        elif (c.cpu_request and c.cpu_limit and abs(c.cpu_request - c.cpu_limit) < 0.001 and
              c.mem_request_mib and c.mem_limit_mib and abs(c.mem_request_mib - c.mem_limit_mib) < 1):
            guaranteed_ctrs.append(c.container_name)

    # Burstiness ratio: peak / avg — high ratio = spiky workload
    cpu_burst_ratio = round((n.cpu_max_pct or 0) / (n.cpu_avg_pct or 1), 1)
    mem_burst_ratio = round((n.mem_max_pct or 0) / (n.mem_avg_pct or 1), 1)

    # Unaccounted node resource (likely daemonsets + system pods overhead)
    # = node allocatable - sum of all container requests on this node
    node_cpu_overhead_cores = max(0, round(node_cpu_cores - total_cpu_req, 2))
    node_mem_overhead_gb    = max(0, round(node_mem_gb - total_mem_req, 2))
    overhead_cpu_pct = round(node_cpu_overhead_cores / node_cpu_cores * 100, 0) if node_cpu_cores > 0 else 0
    overhead_mem_pct = round(node_mem_overhead_gb / node_mem_gb * 100, 0) if node_mem_gb > 0 else 0

    # Pod density
    total_pods = sum(c.pod_count or 1 for c in node_ctrs)

    # Projected utilisation if we downsize to rec_sku
    proj_cpu_pct = None
    proj_mem_pct = None
    if rec_d and rec_d.get("vcpus") and rec_d.get("mem_gb"):
        proj_cpu_pct = round((n.cpu_max_cores or 0) / rec_d["vcpus"] * 100, 0)
        proj_mem_pct = round((n.mem_max_gb or 0) / rec_d["mem_gb"] * 100, 0)

    # Single-container node (poor bin-packing)
    single_ctr_node = len(node_ctrs) == 1

    # Can containers' over-provisioning be fixed to unlock a smaller SKU?
    # Effective CPU if all over-provisioned container requests are corrected to 120% of their actual peak
    effective_cpu_after_rightsizing = sum(
        max(c.cpu_request or 0, (c.cpu_max or 0) * 1.2) for c in node_ctrs
    )
    effective_mem_after_rightsizing = sum(
        max(c.mem_request_mib or 0, (c.mem_max_mib or 0) * 1.2) for c in node_ctrs
    ) / 1024  # GiB
    effective_cpu_pct = round(effective_cpu_after_rightsizing / node_cpu_cores * 100, 0) if node_cpu_cores > 0 else 0
    effective_mem_pct = round(effective_mem_after_rightsizing / node_mem_gb * 100, 0) if node_mem_gb > 0 else 0

    system_msg = (
        "You are an expert AKS infrastructure engineer specialising in Kubernetes cost optimisation. "
        "Your goal is to maximise cost savings WITHOUT degrading workload performance or reliability. "
        "Follow this strict decision hierarchy:\n"
        "  1. CONTAINER HEALTH FIRST — if any container is throttled or at OOMKill risk, that must be fixed before any SKU change.\n"
        "  2. CONTAINER RIGHT-SIZING — if containers are over-provisioned, the SKU may appear under-utilised; recommend fixing requests first.\n"
        "  3. SKU FAMILY FITNESS — check if the CPU:memory ratio of the workload matches the SKU series type before recommending a within-family downsize.\n"
        "  4. SKU DOWNSIZE/UPSIZE — only after the above, recommend a specific SKU if the saving is justified and headroom is sufficient.\n"
        "  5. PERFORMANCE BUFFER — always preserve ≥30% headroom above peak utilisation on the recommended SKU.\n"
        "Never recommend a SKU change if containers have no resource limits — the burst ceiling is unknown.\n"
        "Always output structured sections exactly as requested."
    )

    ctr_section = ""
    if node_ctrs:
        lines = []
        for c in node_ctrs[:15]:
            lim_cpu = f"{(c.cpu_limit or 0)*1000:.0f}m" if c.cpu_limit else "none"
            lim_mem = f"{c.mem_limit_mib or 0:.0f}MiB" if c.mem_limit_mib else "none"
            restart_note = f" restarts={c.restart_count}" if c.restart_count else ""
        exit_note    = f" exit={c.last_exit_reason}" if c.last_exit_reason else ""
        lines.append(
                f"  • {c.container_name} ({c.namespace or '—'}, {c.pod_count or 0} pods{restart_note}{exit_note})\n"
                f"    CPU  req={c.cpu_request or 0:.3f}c / lim={lim_cpu} / avg={c.cpu_avg or 0:.3f}c ({c.cpu_util_pct or 0:.0f}%) / p90={c.cpu_p90 or 0:.3f}c / p95={c.cpu_p95 or 0:.3f}c / peak={c.cpu_max or 0:.3f}c ({c.cpu_max_pct or 0:.0f}%)\n"
                f"    Mem  req={c.mem_request_mib or 0:.0f}MiB / lim={lim_mem} / avg={c.mem_avg_mib or 0:.0f}MiB ({c.mem_util_pct or 0:.0f}%) / p90={c.mem_p90_mib or 0:.0f}MiB / p95={c.mem_p95_mib or 0:.0f}MiB / peak={c.mem_max_mib or 0:.0f}MiB ({c.mem_max_pct or 0:.0f}%)"
            )
        if len(node_ctrs) > 15:
            lines.append(f"  ... and {len(node_ctrs) - 15} more containers")
        ctr_section = "\n".join(lines)
    else:
        ctr_section = "  (no container data available)"

    pod_count_live = n.pod_count_30d_max or 0
    # Distinguish truly-empty nodes from nodes that have workloads beyond kube daemonsets
    # infra/default pools host kube daemonsets only — other pools have actual workloads
    _INFRA_POOL_KEYWORDS = ("infra", "default", "system", "agentpool")
    is_infra_pool = any(k in (n.nodepool or "").lower() for k in _INFRA_POOL_KEYWORDS)
    pod_note = ("⚠ Pod count is 0 — node appears truly idle (no workloads detected)."
                if pod_count_live == 0
                else f"Live pod count: {pod_count_live} pods"
                     + (" (infra/default pool — likely only kube daemonsets)" if is_infra_pool else " (includes workload pods)"))

    prompt = f"""=== NODE UNDER ANALYSIS ===
Node:    {n.node_name}
Cluster: {n.cluster}  |  Pool: {n.nodepool}  |  Region: {n.region}
Current SKU:     {_sku_line(n.current_sku)}  →  recorded ${n.current_price or 0:.0f}/mo
Rule-based rec:  {_sku_line(n.rec_sku) if n.rec_sku else 'No change recommended'}  →  potential saving ${n.saving or 0:.0f}/mo
Pod context:     {pod_note}
IMPORTANT: Only recommend SCALE_DOWN / decommission if pod count is 0 AND CPU+Mem are both <5%. If the node has active pods or is an infra pool with daemonsets, do NOT recommend SCALE_DOWN.

=== NODE UTILISATION (30-DAY) ===
CPU:  {node_cpu_cores:.1f} cores allocatable  |  avg {n.cpu_avg_pct or 0:.1f}%  |  peak {n.cpu_max_pct or 0:.1f}%  |  avg cores used {n.cpu_avg_cores or 0:.2f}  |  peak {n.cpu_max_cores or 0:.2f}
Mem:  {node_mem_gb:.1f} GiB allocatable      |  avg {n.mem_avg_pct or 0:.1f}%  |  peak {n.mem_max_pct or 0:.1f}%  |  avg GiB used {n.mem_avg_gb or 0:.2f}  |  peak {n.mem_max_gb or 0:.2f}

=== CONTAINER WORKLOAD ON THIS NODE ({len(node_ctrs)} containers) ===
Aggregate:  CPU requested={total_cpu_req:.2f}c / actual-avg={total_cpu_act:.2f}c  |  Mem requested={total_mem_req:.1f}GiB / actual-avg={total_mem_act:.1f}GiB
Workload avg mem:CPU ratio = {workload_cpu_mem_ratio} GiB/core

Per-container breakdown:
{ctr_section}

=== RISK FLAGS (pre-computed) ===
Containers at risk (OOMKill / CPU throttled): {', '.join(at_risk_ctrs) if at_risk_ctrs else 'None'}
Over-provisioned containers (util <20% CPU AND <30% Mem): {', '.join(over_req_ctrs) if over_req_ctrs else 'None'}
Containers missing limits (unknown burst ceiling): {', '.join(no_limits_ctrs) if no_limits_ctrs else 'None'}
Guaranteed QoS containers (req=lim, no burst possible): {', '.join(guaranteed_ctrs) if guaranteed_ctrs else 'None'}
BestEffort QoS containers (no req/lim, evicted first): {', '.join(best_effort_ctrs) if best_effort_ctrs else 'None'}
CPU burstiness ratio (peak/avg): {cpu_burst_ratio}x  |  Mem burstiness ratio: {mem_burst_ratio}x
Unaccounted node overhead (daemonsets/system): CPU={node_cpu_overhead_cores}c ({overhead_cpu_pct:.0f}%)  Mem={node_mem_overhead_gb}GiB ({overhead_mem_pct:.0f}%)
Total pods on node: {total_pods}  |  Unique containers: {len(node_ctrs)}  |  Single-container node: {'YES' if single_ctr_node else 'No'}
Effective utilisation AFTER container right-sizing: CPU={effective_cpu_pct:.0f}%  Mem={effective_mem_pct:.0f}%
Projected utilisation ON RECOMMENDED SKU (at peak): CPU={proj_cpu_pct if proj_cpu_pct is not None else '?'}%  Mem={proj_mem_pct if proj_mem_pct is not None else '?'}%

=== SKU FAMILY CONTEXT ===
Current SKU type: {cur_d.get('type', '—')}  |  Recommended SKU type: {rec_d.get('type', '—') if rec_d else '—'}
Workload CPU:Mem ratio suggests: {'Memory optimized' if workload_cpu_mem_ratio >= 8 else 'Compute optimized' if workload_cpu_mem_ratio <= 2 else 'General purpose'}

=== ANALYSIS REQUIRED ===
Work through each step in order. Be specific — name containers and SKUs.

STEP_1_CONTAINER_HEALTH:
Check: OOMKill risk, CPU throttling, BestEffort containers under memory pressure.
List each issue and the specific fix (increase limit to X, set request to Y).
If none, write "None".

STEP_2_CONTAINER_RIGHTSIZING:
Check: over-provisioned containers (util <20%/30%), Guaranteed QoS over-requests, large limit gaps.
For each: give new request and limit values.
State the effective node utilisation AFTER these changes (use pre-computed values above).
State whether container right-sizing alone avoids the need for a SKU change.
If none needed, write "None".

STEP_3_DAEMONSET_OVERHEAD:
The unaccounted overhead ({overhead_cpu_pct:.0f}% CPU, {overhead_mem_pct:.0f}% Mem) is likely daemonsets/system pods.
Does this overhead change the safe downsize headroom? Account for it in your SKU recommendation.

STEP_4_WORKLOAD_PATTERN:
CPU burstiness {cpu_burst_ratio}x, Mem burstiness {mem_burst_ratio}x.
- If CPU burst ratio > 3: consider B-series (burstable) instead of general purpose.
- If only 1 container on node: flag bin-packing waste.
- If workload mem:CPU ratio {workload_cpu_mem_ratio} mismatches current SKU type: recommend correct series.

STEP_5_SKU_RECOMMENDATION:
Using the projected utilisation on the recommended SKU (CPU={proj_cpu_pct if proj_cpu_pct is not None else '?'}%, Mem={proj_mem_pct if proj_mem_pct is not None else '?'}%):
- Is headroom ≥30% above peak on both CPU and memory? If not, reject the downsize.
- Does the overhead from daemonsets still fit?
- State: recommended SKU, projected utilisation (%), monthly saving vs current.
- If recommending a new SKU family, name it and justify.

STEP_6_DATA_GAPS:
Flag any scenario you CANNOT assess with available data:
- HPA present? (if so, min_replicas × request must fit — cannot verify without HPA config)
- PodDisruptionBudget? (could block node drain)
- ReadWriteOnce PVCs? (pod cannot move to a different node)
- Node taints/specialised workload? (check nodepool name)
State "Cannot assess X — verify manually before proceeding."

VERDICT: <one of: Fix containers first | Downsize to <SKU> | Change family to <SKU> | Keep current | Upsize to <SKU> | Scale down (decommission) | Needs manual verification>
REASON: 3-4 sentences summarising the decision, covering cost saving, performance headroom, and any risks that need human verification.

Output the following line EXACTLY at the end (Azure VM SKU name, KEEP_CURRENT, or SCALE_DOWN only if pod count is 0 AND cpu/mem <5%):
REC_SKU: <Azure VM SKU name, e.g. Standard_D8s_v5, or KEEP_CURRENT, or SCALE_DOWN>
"""

    result   = _call_openai(prompt, max_tokens=1900, system=system_msg)
    vm       = re.search(r"VERDICT:\s*(.+)",    result, re.I)
    rs       = re.search(r"REC_SKU:\s*(\S+)",   result, re.I)
    n.ai_reason      = result
    n.ai_verdict     = vm.group(1).strip() if vm else None
    n.ai_assessed_at = datetime.now(timezone.utc)
    if rs:
        ai_sku = rs.group(1).strip().upper()
        if ai_sku == "SCALE_DOWN":
            # AI confirmed node is truly idle — only accept if metrics back this up
            if pod_count_live == 0 and (n.cpu_avg_pct or 0) < 5 and (n.mem_avg_pct or 0) < 5:
                cur_s = sku_map.get(n.current_sku or "", {})
                n.rec_sku   = "SCALE_DOWN"
                n.rec_price = 0
                n.saving    = cur_s.get("price", 0)
                n.saved_pct = 100.0
            else:
                # AI said SCALE_DOWN but node has workload — ignore, keep current
                print(f"assess_node: AI returned SCALE_DOWN for {node_name} but node has pods={pod_count_live} cpu={n.cpu_avg_pct:.1f}% — ignoring")
        elif ai_sku and ai_sku not in ("KEEP_CURRENT", "NONE", "N/A", "NA"):
            candidate = rs.group(1).strip()  # preserve original casing
            if not re.match(r"^Standard_[A-Za-z0-9_]+$", candidate):
                print(f"assess_node: rejected malformed rec_sku: {candidate!r}")
                n.rec_sku = None; n.rec_price = None; n.saving = 0; n.saved_pct = 0
            else:
                n.rec_sku = candidate
            rec_s = sku_map.get(n.rec_sku or "", {})
            cur_s = sku_map.get(n.current_sku or "", {})
            if rec_s.get("price") is not None:
                n.rec_price = rec_s["price"]
                n.saving    = max(0, (cur_s.get("price") or 0) - rec_s["price"])
                n.saved_pct = (n.saving / cur_s["price"] * 100) if cur_s.get("price") else 0
        else:
            n.rec_sku   = None
            n.rec_price = None
            n.saving    = 0
            n.saved_pct = 0
    db.add(ActionHistory(entity_type="node", entity_name=node_name,
                         action="ai_assessed", performed_by=body.performed_by,
                         details={"verdict": n.ai_verdict, "rec_sku": n.rec_sku}))
    db.commit()
    if node_name in _LIVE["nodes"]:
        _LIVE["nodes"][node_name].update({
            "ai_reason": n.ai_reason, "ai_verdict": n.ai_verdict,
            "rec_sku": n.rec_sku, "rec_price": n.rec_price,
            "saving": n.saving or 0, "saved_pct": n.saved_pct or 0,
        })
    return {"verdict": n.ai_verdict, "reason": result, "rec_sku": n.rec_sku}


class AssessPoolBody(BaseModel):
    cluster:      str
    nodepool:     str
    performed_by: str = "user"


@app.post("/api/nodepools/assess")
def assess_nodepool(body: AssessPoolBody, db: Session = Depends(get_db)):
    """
    Assess all nodes in a nodepool as a single unit.
    All nodes in a pool share the same VM SKU — the recommendation applies to the entire pool.
    Saves the same rec_sku / saving to every node in the pool.
    """
    if not (OPENAI_KEY or os.environ.get("OPENAI_KEY")):
        raise HTTPException(503, "OpenAI key not configured")

    pool_nodes = db.query(Node).filter(
        Node.cluster  == body.cluster,
        Node.nodepool == body.nodepool,
    ).all()
    if not pool_nodes:
        raise HTTPException(404, f"No nodes found for pool {body.cluster}/{body.nodepool}")

    # All nodes share the same SKU — take from first non-null
    current_sku = next((n.current_sku for n in pool_nodes if n.current_sku), None)
    region      = next((n.region      for n in pool_nodes if n.region), None)
    node_count  = len(pool_nodes)

    # Build SKU map
    _sdb = SkuSessionLocal()
    try:
        sku_map = _build_sku_map(_sdb, region=region)
    finally:
        _sdb.close()

    def _sku_detail(sku_name):
        if not sku_name: return {}
        try:
            sdb = SkuSessionLocal()
            try:
                row = sdb.query(VmSku).filter(VmSku.sku_name == sku_name) \
                         .order_by(VmSku.last_fetched_at.desc().nullslast()).first()
            finally:
                sdb.close()
        except Exception:
            return {}
        if not row: return {}
        return {"vcpus": row.vcpus, "mem_gb": row.memory_gb,
                "type": row.sku_type or "General purpose",
                "price_mo": round((row.price_linux_hr or 0) * 730, 0)}

    def _sku_line(sku_name):
        d = _sku_detail(sku_name)
        if not d: return sku_name or "—"
        return f"{sku_name} [{d['type']}, {d['vcpus']}vCPU, {d['mem_gb']}GiB, ${d['price_mo']:.0f}/mo]"

    # Aggregate metrics across all nodes
    cpu_avg  = sum(n.cpu_avg_pct  or 0 for n in pool_nodes) / node_count
    cpu_max  = sum(n.cpu_max_pct  or 0 for n in pool_nodes) / node_count
    mem_avg  = sum(n.mem_avg_pct  or 0 for n in pool_nodes) / node_count
    mem_max  = sum(n.mem_max_pct  or 0 for n in pool_nodes) / node_count
    cpu_alloc = pool_nodes[0].cpu_alloc   or 0
    mem_alloc = pool_nodes[0].mem_alloc_gb or 0
    price_per_node = (sku_map.get(current_sku or "", {}).get("price") or
                      next((n.current_price for n in pool_nodes if n.current_price), 0))

    # Pod counts — only nodes with actual workload pods (non-zero)
    total_pods   = sum(n.pod_count_30d_max or 0 for n in pool_nodes)
    empty_nodes  = sum(1 for n in pool_nodes if (n.pod_count_30d_max or 0) == 0)
    active_nodes = node_count - empty_nodes

    # ── Workload hourly pattern ────────────────────────────────────────────────
    workload_pattern: dict = {}
    if GRAFANA_URL and GRAFANA_TOKEN:
        try:
            _dss = gf.list_mimir_datasources(GRAFANA_URL, GRAFANA_TOKEN)
            # Match datasource by cluster name first, then fall back to region
            _ds_uid = None
            for _ds in _dss:
                if _ds.get("name", "").lower() == body.cluster.lower():
                    _ds_uid = _ds["uid"]
                    break
            if not _ds_uid and region:
                for _ds in _dss:
                    if _ds.get("region", "").lower() == region.lower():
                        _ds_uid = _ds["uid"]
                        break
            if not _ds_uid and _dss:
                _ds_uid = _dss[0]["uid"]  # last resort: first datasource
            if _ds_uid:
                workload_pattern = gf.fetch_node_hourly_pattern(
                    GRAFANA_URL, GRAFANA_TOKEN, _ds_uid,
                    [n.node_name for n in pool_nodes]
                )
        except Exception as _e:
            print(f"  [assess_nodepool] workload pattern fetch failed: {_e}")

    # Containers running on nodes in this pool
    all_ctrs = db.query(Container).filter(Container.cluster == body.cluster).all()
    pool_ctrs = []
    pool_node_names = {n.node_name for n in pool_nodes}
    for c in all_ctrs:
        nns = c.node_names if isinstance(c.node_names, list) else ([c.node_names] if c.node_names else [])
        if any(nn in pool_node_names for nn in nns):
            pool_ctrs.append(c)
    # Deduplicate by container_name (same workload runs on multiple nodes)
    seen_ctrs = {}
    for c in pool_ctrs:
        if c.container_name not in seen_ctrs:
            seen_ctrs[c.container_name] = c
    unique_ctrs = list(seen_ctrs.values())

    # Container tier classification
    _HIGH_PERF_SET = {"core", "ui", "rds", "pgprimary-core", "pgprimary-ui"}
    hp_ctr_names  = sorted({c.container_name for c in unique_ctrs if c.container_name in _HIGH_PERF_SET})
    opt_ctr_names = sorted({c.container_name for c in unique_ctrs if c.container_name not in _HIGH_PERF_SET})

    ctr_lines = []
    for c in unique_ctrs[:20]:
        tier = "HIGH-PERF" if c.container_name in _HIGH_PERF_SET else "OPTIMIZE"
        ctr_lines.append(
            f"  • [{tier}] {c.container_name} ({c.namespace or '—'}): "
            f"CPU req={c.cpu_request or 0:.3f}c avg={c.cpu_avg or 0:.3f}c ({c.cpu_util_pct or 0:.0f}%) "
            f"Mem req={c.mem_request_mib or 0:.0f}MiB avg={c.mem_avg_mib or 0:.0f}MiB ({c.mem_util_pct or 0:.0f}%)"
        )
    ctr_section = "\n".join(ctr_lines) if ctr_lines else "  (no container data)"

    cur_s   = sku_map.get(current_sku or "", {})
    cur_d   = _sku_detail(current_sku)

    system_msg = (
        "You are an expert AKS infrastructure engineer specialising in cost optimisation. "
        "CRITICAL CONSTRAINT: In AKS, ALL nodes in a nodepool share the SAME VM SKU. "
        "You CANNOT recommend a different SKU for individual nodes — any SKU change applies to the ENTIRE pool. "
        "If only some nodes are under-utilised, consider whether the pool should be scaled down in node count instead. "
        "Follow this decision hierarchy:\n"
        "  1. If empty_nodes > 0: recommend reducing pool node count (scale-in), not SKU change.\n"
        "  2. If all nodes have workloads: aggregate utilisation across ALL nodes to decide SKU.\n"
        "  3. Only recommend a SKU downsize if ALL nodes in the pool are consistently under-utilised.\n"
        "  4. Preserve ≥30% headroom above peak on recommended SKU.\n\n"
        "CONTAINER TIERS:\n"
        "  HIGH-PERF containers (core, ui, rds, pgprimary-core, pgprimary-ui): "
        "These run critical business workloads. NEVER downsize headroom for these. "
        "Maintain burst capacity — use peak utilisation (not average) when sizing for this tier.\n"
        "  OPTIMIZE containers (all others): "
        "Cost/performance balance is acceptable. Average utilisation is the primary sizing signal. "
        "These containers can tolerate tighter resource headroom.\n\n"
        "WORKLOAD TIME AWARENESS:\n"
        "  If workload pattern data is provided, use it to determine whether low average utilisation "
        "reflects genuine under-provisioning or predictable off-peak troughs. "
        "Do NOT recommend downsizing if peak hours drive consistent high utilisation on HIGH-PERF containers. "
        "Weekend vs weekday differences can justify autoscaling or scheduled scaling recommendations."
    )

    # Workload pattern section for prompt
    _wp = workload_pattern
    if _wp:
        _wday = _wp.get("weekday_avg_pct", 0)
        _wend = _wp.get("weekend_avg_pct", 0)
        _ph   = _wp.get("raw_summary", "")
        workload_section = f"""
=== WORKLOAD TIME PATTERN (last 7 days, hourly CPU) ===
{_ph}
Weekday avg: {_wday:.1f}%  |  Weekend avg: {_wend:.1f}%
Note: Use peak hours utilisation for HIGH-PERF containers when assessing headroom.
      Off-peak troughs should NOT drive a downsize recommendation if peak demand is high.
"""
    else:
        workload_section = "\n=== WORKLOAD TIME PATTERN ===\n  (not available — use avg/peak metrics above)\n"

    # Container tier summary
    ctr_tier_section = (
        f"\nCONTAINER TIERS IN THIS POOL:\n"
        f"  HIGH-PERF (protect headroom): {', '.join(hp_ctr_names) or 'none'}\n"
        f"  OPTIMIZE  (cost-balance OK):  {', '.join(opt_ctr_names) or 'none'}\n"
    )

    prompt = f"""=== NODEPOOL UNDER ANALYSIS ===
Cluster:   {body.cluster}
Node Pool: {body.nodepool}
Region:    {region or '—'}
Node count: {node_count} nodes  ({active_nodes} with workloads, {empty_nodes} empty/idle)
Current SKU (shared by ALL nodes): {_sku_line(current_sku)}  →  ${price_per_node:.0f}/node/mo  →  ${price_per_node * node_count:.0f}/mo total pool cost
Total pods across pool: {total_pods}

=== POOL-WIDE UTILISATION (avg across {node_count} nodes) ===
CPU:  {cpu_alloc:.1f} cores/node  |  avg {cpu_avg:.1f}%  |  peak {cpu_max:.1f}%
Mem:  {mem_alloc:.1f} GiB/node   |  avg {mem_avg:.1f}%  |  peak {mem_max:.1f}%
{workload_section}
=== WORKLOAD CONTAINERS (unique, across pool) ===
{ctr_tier_section}
{ctr_section}
{"  ... and " + str(len(unique_ctrs) - 20) + " more" if len(unique_ctrs) > 20 else ""}

=== PER-NODE DETAIL ===
{"".join(f"  {n.node_name}: cpu_avg={n.cpu_avg_pct or 0:.1f}% cpu_max={n.cpu_max_pct or 0:.1f}% mem_avg={n.mem_avg_pct or 0:.1f}% mem_max={n.mem_max_pct or 0:.1f}% pods={n.pod_count_30d_max or 0}{chr(10)}" for n in pool_nodes)}

=== ANALYSIS REQUIRED ===

STEP_1_SCALE_IN:
Are any nodes empty (0 pods, cpu/mem <5%)? If yes, recommend reducing pool node count by how many.
State the saving from scale-in alone (removed nodes × ${price_per_node:.0f}/mo).

STEP_2_SKU_FIT:
Based on aggregate CPU:Mem utilisation across ALL active nodes, is the current SKU family correct?
Consider peak hours especially for HIGH-PERF containers. Remember: the entire pool must use the same SKU.

STEP_3_SKU_RECOMMENDATION:
Can the pool be downsized to a smaller SKU? Only if ALL nodes are consistently under-utilised at peak
AND no HIGH-PERF containers will be resource-constrained on the smaller SKU.
State the recommended SKU, projected utilisation on ALL nodes, and saving per node.

STEP_4_TOTAL_SAVING:
Calculate total monthly saving = (scale-in saving) + (SKU change saving × remaining node count).

VERDICT: <one of: Scale in (reduce node count) | Downsize SKU to <SKU> | Scale in + Downsize to <SKU> | Keep current | Upsize to <SKU> | Needs manual review>
REASON: 3-4 sentences covering scale-in potential, SKU fit, workload time pattern, total saving, and risk.

Output EXACTLY (SKU name or KEEP_CURRENT; SCALE_DOWN only if ALL nodes are empty):
REC_SKU: <Azure VM SKU name, or KEEP_CURRENT, or SCALE_DOWN>
REC_NODE_COUNT: <integer — recommended number of nodes, or KEEP_CURRENT>
"""

    result = _call_openai(prompt, max_tokens=1800, system=system_msg)
    vm  = re.search(r"VERDICT:\s*(.+)",          result, re.I)
    rs  = re.search(r"REC_SKU:\s*(\S+)",          result, re.I)
    rnc = re.search(r"REC_NODE_COUNT:\s*(\S+)",   result, re.I)

    ai_verdict = vm.group(1).strip() if vm else None
    ai_sku_raw = rs.group(1).strip().upper() if rs else None
    rec_node_count_str = rnc.group(1).strip().upper() if rnc else "KEEP_CURRENT"
    rec_node_count = None
    if rec_node_count_str != "KEEP_CURRENT":
        try: rec_node_count = int(rec_node_count_str)
        except ValueError: pass

    now = datetime.now(timezone.utc)

    # Apply recommendation to ALL nodes in pool
    for n in pool_nodes:
        n.ai_reason      = result
        n.ai_verdict     = ai_verdict
        n.ai_assessed_at = now

        if ai_sku_raw == "SCALE_DOWN":
            # Only accept SCALE_DOWN if ALL nodes are empty
            if empty_nodes == node_count:
                cur_s_n = sku_map.get(n.current_sku or "", {})
                n.rec_sku   = "SCALE_DOWN"
                n.rec_price = 0
                n.saving    = cur_s_n.get("price", 0)
                n.saved_pct = 100.0
            # else: ignore SCALE_DOWN if pool has active nodes
        elif ai_sku_raw and ai_sku_raw not in ("KEEP_CURRENT", "NONE", "N/A", "NA"):
            ai_sku = rs.group(1).strip()  # preserve original casing
            # Only accept properly-formed Azure SKU names; reject AI hallucinations
            if not re.match(r"^Standard_[A-Za-z0-9_]+$", ai_sku):
                print(f"  [assess_nodepool] rejected malformed rec_sku from AI: {ai_sku!r}")
                n.rec_sku = None; n.rec_price = None; n.saving = 0; n.saved_pct = 0
                continue
            n.rec_sku = ai_sku
            rec_s = sku_map.get(ai_sku, {})
            cur_s_n = sku_map.get(n.current_sku or "", {})
            if rec_s.get("price") is not None:
                n.rec_price = rec_s["price"]
                n.saving    = max(0, (cur_s_n.get("price") or 0) - rec_s["price"])
                n.saved_pct = (n.saving / cur_s_n["price"] * 100) if cur_s_n.get("price") else 0
        else:
            n.rec_sku   = None
            n.rec_price = None
            n.saving    = 0
            n.saved_pct = 0

        db.add(ActionHistory(entity_type="node", entity_name=n.node_name,
                             action="ai_assessed_pool", performed_by=body.performed_by,
                             details={"verdict": ai_verdict, "rec_sku": n.rec_sku,
                                      "pool": body.nodepool, "rec_node_count": rec_node_count}))
        if n.node_name in _LIVE["nodes"]:
            _LIVE["nodes"][n.node_name].update({
                "ai_reason": n.ai_reason, "ai_verdict": n.ai_verdict,
                "rec_sku": n.rec_sku, "rec_price": n.rec_price,
                "saving": n.saving or 0, "saved_pct": n.saved_pct or 0,
            })

    db.commit()

    total_saving = sum(n.saving or 0 for n in pool_nodes)
    final_sku = pool_nodes[0].rec_sku if pool_nodes else None
    return {
        "cluster": body.cluster, "nodepool": body.nodepool,
        "node_count": node_count, "assessed": node_count,
        "verdict": ai_verdict, "reason": result,
        "rec_sku": final_sku,
        "rec_node_count": rec_node_count,
        "total_saving": round(total_saving, 2),
    }


@app.post("/api/containers/assess-all")
def assess_all_containers(db: Session = Depends(get_db)):
    """Send full container usage/limits/requests to OpenAI for batch analysis."""
    if not (OPENAI_KEY or os.environ.get("OPENAI_KEY")):
        raise HTTPException(503, "OpenAI key not configured")

    ctrs = db.query(Container).all()
    if not ctrs:
        return {"assessed": 0, "summary": "No containers found in database."}

    pending    = [c for c in ctrs if c.status == "pending"]
    namespaces = sorted({c.namespace for c in ctrs if c.namespace})
    clusters   = sorted({c.cluster   for c in ctrs if c.cluster})

    def _cfmt(v): return f"{(v or 0)*1000:.0f}m"
    def _mfmt(v): return f"{v or 0:.0f}Mi"

    ctr_lines = []
    for c in ctrs[:80]:
        lim_cpu = _cfmt(c.cpu_limit)     if c.cpu_limit     else "none"
        lim_mem = _mfmt(c.mem_limit_mib) if c.mem_limit_mib else "none"
        rec_str = ""
        if c.rec_cpu_request or c.rec_mem_req:
            rec_str = f" → rec CPU={_cfmt(c.rec_cpu_request)}/Mem={_mfmt(c.rec_mem_req)}"
        ctr_lines.append(
            f"  [{c.status or 'pending'}] {c.container_name} ({c.namespace}, {c.pod_count or 0} pods): "
            f"CPU req={_cfmt(c.cpu_request)}/lim={lim_cpu}/avg={_cfmt(c.cpu_avg)}({c.cpu_util_pct or 0:.0f}%) "
            f"max={_cfmt(c.cpu_max)}({c.cpu_max_pct or 0:.0f}%) | "
            f"Mem req={_mfmt(c.mem_request_mib)}/lim={lim_mem}/avg={_mfmt(c.mem_avg_mib)}({c.mem_util_pct or 0:.0f}%) "
            f"max={_mfmt(c.mem_max_mib)}({c.mem_max_pct or 0:.0f}%)"
            + rec_str
        )

    prompt = (
        f"You are a Kubernetes resource optimization expert.\n\n"
        f"=== OVERVIEW ===\n"
        f"Clusters: {', '.join(clusters)}\n"
        f"Total containers: {len(ctrs)} | Pending: {len(pending)}\n"
        f"Namespaces ({len(namespaces)}): {', '.join(namespaces)}\n\n"
        f"=== CONTAINER RESOURCE DETAILS ({min(len(ctrs),80)} of {len(ctrs)}) ===\n"
        "Format: [status] name (namespace, pods): CPU req/lim/avg(util%) max(%) | Mem req/lim/avg(util%) max(%) → recommendation\n"
        + "\n".join(ctr_lines) +
        "\n\n=== ANALYSIS REQUIRED ===\n"
        "OVER_PROVISIONED: Containers with requests >> actual usage (safe to reduce)\n"
        "UNDER_PROVISIONED: Containers with usage near/over limits (risk of OOMKill/throttling)\n"
        "MISSING_LIMITS: Containers with no CPU or Mem limits (noisy neighbours risk)\n"
        "QUICK_WINS: Top 3 specific rightsizing actions with expected impact\n"
        "SUMMARY: 2-3 sentence executive summary\n"
    )

    result = _call_openai(prompt, max_tokens=1200)
    return {
        "assessed":   len(ctrs),
        "pending":    len(pending),
        "namespaces": namespaces,
        "summary":    result,
    }


@app.post("/api/containers/{container_id:path}/assess")
def assess_container(container_id: str, body: AssessBody = AssessBody(),
                     db: Session = Depends(get_db)):
    c = db.query(Container).filter(Container.container_id == container_id).first()
    if not c:
        raise HTTPException(404, "Container not found")

    def _cfmt(v): return f"{(v or 0)*1000:.0f}m"
    def _mfmt(v): return f"{v or 0:.0f}MiB"

    # Get the node this container runs on (for VM context)
    node_context = ""
    if c.node_names:
        nn = c.node_names if isinstance(c.node_names, list) else [c.node_names]
        nodes = db.query(Node).filter(Node.node_name.in_(nn)).all()
        if nodes:
            node_context = "\nNode context:\n" + "\n".join(
                f"  {n.node_name} ({n.current_sku}): "
                f"CPU {n.cpu_avg_pct or 0:.0f}%avg/{n.cpu_max_pct or 0:.0f}%peak, "
                f"Mem {n.mem_avg_pct or 0:.0f}%avg/{n.mem_max_pct or 0:.0f}%peak"
                for n in nodes
            )

    # Derived risk signals
    cpu_throttled  = (c.cpu_max_pct or 0) >= 95 and bool(c.cpu_limit)
    oom_risk       = (c.mem_limit_mib and c.mem_max_mib and
                      c.mem_max_mib >= (c.mem_limit_mib * 0.80))
    cpu_over       = (c.cpu_util_pct or 0) < 20
    mem_over       = (c.mem_util_pct or 0) < 30
    no_cpu_limit   = not c.cpu_limit
    no_mem_limit   = not c.mem_limit_mib
    # Gap between limit and actual: large gap = limit can come down
    cpu_limit_gap  = (((c.cpu_limit or 0) - (c.cpu_max or 0)) / (c.cpu_limit or 1) * 100) if c.cpu_limit else 0
    mem_limit_gap  = (((c.mem_limit_mib or 0) - (c.mem_max_mib or 0)) / (c.mem_limit_mib or 1) * 100) if c.mem_limit_mib else 0

    # QoS class
    _has_cpu_req = bool(c.cpu_request)
    _has_mem_req = bool(c.mem_request_mib)
    _has_cpu_lim = bool(c.cpu_limit)
    _has_mem_lim = bool(c.mem_limit_mib)
    if not _has_cpu_req and not _has_mem_req and not _has_cpu_lim and not _has_mem_lim:
        qos_class = "BestEffort"
    elif (_has_cpu_req and _has_cpu_lim and abs(c.cpu_request - c.cpu_limit) < 0.001 and
          _has_mem_req and _has_mem_lim and abs(c.mem_request_mib - c.mem_limit_mib) < 1):
        qos_class = "Guaranteed"
    else:
        qos_class = "Burstable"

    # Burstiness
    cpu_burst_ratio = round((c.cpu_max or 0) / (c.cpu_avg or 0.001), 1)
    mem_burst_ratio = round((c.mem_max_mib or 0) / (c.mem_avg_mib or 1), 1)

    # Safe minimum request = max(120% of p95, 110% of peak) — anchored to p95 not just peak
    # p95 is less noisy than absolute peak and avoids over-engineering for once-off spikes
    cpu_p95_v  = c.cpu_p95 or c.cpu_max or 0
    mem_p95_v  = c.mem_p95_mib or c.mem_max_mib or 0
    safe_cpu_req = round(max((cpu_p95_v) * 1.2, (c.cpu_max or 0) * 1.1), 3)
    safe_mem_req = round(max((mem_p95_v) * 1.2, (c.mem_max_mib or 0) * 1.1), 0)

    # Safe minimum limit = 150% of p95 (allow headroom above normal peak without following one-off spikes)
    safe_cpu_lim = round((cpu_p95_v) * 1.5, 3)
    safe_mem_lim = round((mem_p95_v) * 1.5, 0)

    # Savings multiplier: pod_count matters — saving per pod × pod_count
    pod_multiplier = c.pod_count or 1

    # Aggregate node headroom freed if requests are reduced
    freed_cpu = round(max(0, (c.cpu_request or 0) - safe_cpu_req) * pod_multiplier, 3)
    freed_mem = round(max(0, (c.mem_request_mib or 0) - safe_mem_req) * pod_multiplier, 0)

    container_system_msg = (
        "You are an expert Kubernetes SRE specialising in container resource optimisation. "
        "Balance cost savings with reliability. Follow this priority order:\n"
        "  1. Fix At Risk containers first (throttling / OOMKill) — this is a reliability issue.\n"
        "  2. Set missing limits — a container without limits is an unknown risk.\n"
        "  3. Reduce over-provisioned requests — this frees scheduler headroom on the node.\n"
        "  4. Reduce limits where the gap between limit and actual peak is large (>60%) — limits are not wasted cost but affect scheduling.\n"
        "  5. If requests and limits are already close to actual usage, mark as Optimal.\n"
        "Always give specific numeric values. Never recommend reducing memory request below 120% of peak usage."
    )

    prompt = f"""=== CONTAINER: {c.container_name} ===
Namespace: {c.namespace or '—'}  |  Cluster: {c.cluster or '—'}  |  Pods: {c.pod_count or 0}
Restarts (30d): {c.restart_count or 0}  |  Last exit reason: {c.last_exit_reason or 'none'}

=== RESOURCE CONFIGURATION ===
CPU   request: {_cfmt(c.cpu_request)}  |  limit: {_cfmt(c.cpu_limit) if c.cpu_limit else 'NOT SET ⚠'}
Mem   request: {_mfmt(c.mem_request_mib)}  |  limit: {_mfmt(c.mem_limit_mib) if c.mem_limit_mib else 'NOT SET ⚠'}

=== ACTUAL USAGE (30-DAY PERCENTILES) ===
CPU   avg: {_cfmt(c.cpu_avg)} ({c.cpu_util_pct or 0:.1f}% of req)  |  p50: {_cfmt(c.cpu_p50)}  |  p90: {_cfmt(c.cpu_p90)}  |  p95: {_cfmt(c.cpu_p95)}  |  peak: {_cfmt(c.cpu_max)} ({c.cpu_max_pct or 0:.1f}% of req)
Mem   avg: {_mfmt(c.mem_avg_mib)} ({c.mem_util_pct or 0:.1f}% of req)  |  p50: {_mfmt(c.mem_p50_mib)}  |  p90: {_mfmt(c.mem_p90_mib)}  |  p95: {_mfmt(c.mem_p95_mib)}  |  peak: {_mfmt(c.mem_max_mib)} ({c.mem_max_pct or 0:.1f}% of req)
CPU   limit utilisation at peak: {(c.cpu_max or 0)/(c.cpu_limit or 1)*100:.0f}% of limit  |  gap to limit: {cpu_limit_gap:.0f}%
Mem   limit utilisation at peak: {(c.mem_max_mib or 0)/(c.mem_limit_mib or 1)*100:.0f}% of limit  |  gap to limit: {mem_limit_gap:.0f}%

=== PRE-COMPUTED SIGNALS ===
QoS Class: {qos_class}  (Guaranteed=no burst, Burstable=partial burst, BestEffort=evicted first)
CPU throttled (peak ≥95% of limit): {'YES ⚠' if cpu_throttled else 'No'}
OOMKill risk (mem peak ≥80% of limit): {'YES ⚠' if oom_risk else 'No'}
OOMKilled history: {'YES ⚠ — last_exit_reason=' + c.last_exit_reason if c.last_exit_reason == 'OOMKilled' else 'No'}
Restart count (30d): {c.restart_count or 0}{'  ⚠ HIGH — investigate before reducing limits' if (c.restart_count or 0) >= 5 else ''}
CPU over-provisioned (avg util <20%): {'YES' if cpu_over else 'No'}
Mem over-provisioned (avg util <30%): {'YES' if mem_over else 'No'}
CPU limit missing: {'YES ⚠' if no_cpu_limit else 'No'}
Mem limit missing: {'YES ⚠' if no_mem_limit else 'No'}
CPU burstiness (peak/avg): {cpu_burst_ratio}x  |  Mem burstiness: {mem_burst_ratio}x
Pod count: {pod_multiplier} pods  (rightsizing impact multiplied by pod count)

Safe minimums (anchored to p95, with 120% buffer for requests and 150% for limits):
  CPU  safe_request={safe_cpu_req}c (based on p95={_cfmt(cpu_p95_v)})  safe_limit={safe_cpu_lim}c
  Mem  safe_request={safe_mem_req:.0f}MiB (based on p95={mem_p95_v:.0f}MiB)  safe_limit={safe_mem_lim:.0f}MiB
Note: If OOMKilled or restarts≥5, do NOT reduce memory limits — increase them instead.

Node scheduling headroom freed if requests reduced to safe minimum (× {pod_multiplier} pods):
  CPU freed: {freed_cpu}c  |  Mem freed: {freed_mem:.0f}MiB

=== RULE-BASED RECOMMENDATION ===
CPU   rec request: {_cfmt(c.rec_cpu_request)}  |  rec limit: {_cfmt(c.rec_cpu_limit) if c.rec_cpu_limit else 'none'}
Mem   rec request: {_mfmt(c.rec_mem_req)}  |  rec limit: {_mfmt(c.rec_mem_lim) if c.rec_mem_lim else 'none'}
{node_context}

=== ANALYSIS REQUIRED ===

SCENARIO: Which scenarios apply? List all:
  C1-CPU_THROTTLED | C2-OOM_RISK | C3-CPU_OVER | C4-MEM_OVER |
  C5-NO_LIMITS | C6-LIMIT_GAP_LARGE | C7-GUARANTEED_QOS_OVER_REQ |
  C8-BEST_EFFORT_AT_RISK | C9-HIGH_BURSTINESS | C10-SINGLE_POD | C11-HIGH_POD_COUNT | OPTIMAL

CPU_ANALYSIS:
Current state and throttle risk. Use p95 ({_cfmt(cpu_p95_v)}) as the anchor for recommendations.
Recommended request and limit values with justification.
If Guaranteed QoS and over-provisioned: reducing request also reduces limit — double saving.
If burstiness > 3x: keep limit at least 2× p95; lowering risks throttling.
If BestEffort: urgently needs request and limit set to avoid eviction.
If restarts ≥ 5 and last_exit != OOMKilled: possible CPU starvation — do NOT reduce CPU limit.

MEM_ANALYSIS:
Current state and OOMKill risk. Use p95 ({mem_p95_v:.0f}MiB) as the anchor for recommendations.
Recommended request and limit values with justification.
Never recommend memory request below {safe_mem_req:.0f}MiB (120% of p95).
If OOMKilled or restarts ≥ 5: INCREASE memory limit to at least {safe_mem_lim:.0f}MiB (150% of p95).
If Guaranteed QoS: request = limit, so any reduction saves double.
Explain the p90→p95→peak spread: wide spread = spiky workload, keep higher limit.

QOS_IMPACT:
Current QoS class: {qos_class}. What is the impact?
- BestEffort: pod will be killed first under any node memory pressure — set limits urgently.
- Guaranteed: request=limit means no CPU/mem burst possible — is this intentional or wasteful?
- Burstable: check if burst headroom (limit - avg) is appropriate for the workload pattern.

NODE_IMPACT:
Freeing {freed_cpu}c CPU and {freed_mem:.0f}MiB memory across {pod_multiplier} pods.
Does this freed headroom allow the node to be downsized? Yes/No + reasoning.

DATA_GAPS:
Cannot fully assess: HPA min-replicas × request headroom | PDB constraints | init container overhead.
Flag any of these that apply.

VERDICT: <one of: At Risk | Over-provisioned | Under-provisioned | Optimal | Set Limits First | BestEffort Critical>
REASON: 3-4 sentences covering CPU, memory, QoS class impact, and node-level cascading effect.

Output the following lines EXACTLY at the end (numeric values only, no units):
REC_CPU_REQUEST: <cores, e.g. 0.250>
REC_CPU_LIMIT: <cores, e.g. 0.500>
REC_MEM_REQUEST: <MiB integer, e.g. 512>
REC_MEM_LIMIT: <MiB integer, e.g. 1024>
"""

    result = _call_openai(prompt, max_tokens=1500, system=container_system_msg)
    vm  = re.search(r"VERDICT:\s*(.+)",       result, re.I)
    rcr = re.search(r"REC_CPU_REQUEST:\s*([\d.]+)", result, re.I)
    rcl = re.search(r"REC_CPU_LIMIT:\s*([\d.]+)",   result, re.I)
    rmr = re.search(r"REC_MEM_REQUEST:\s*([\d.]+)", result, re.I)
    rml = re.search(r"REC_MEM_LIMIT:\s*([\d.]+)",   result, re.I)
    c.ai_reason     = result
    c.ai_verdict    = vm.group(1).strip() if vm else None
    c.ai_assessed_at = datetime.now(timezone.utc)
    if rcr: c.rec_cpu_request = float(rcr.group(1))
    if rcl: c.rec_cpu_limit   = float(rcl.group(1))
    if rmr: c.rec_mem_req     = float(rmr.group(1))
    if rml: c.rec_mem_lim     = float(rml.group(1))
    db.add(ActionHistory(entity_type="container", entity_name=container_id,
                         action="ai_assessed", performed_by=body.performed_by,
                         details={"verdict": c.ai_verdict}))
    db.commit()
    if container_id in _LIVE["containers"]:
        _LIVE["containers"][container_id].update({
            "ai_reason": c.ai_reason, "ai_verdict": c.ai_verdict,
            "rec_cpu_request": c.rec_cpu_request, "rec_cpu_limit": c.rec_cpu_limit,
            "rec_mem_request_mib": c.rec_mem_req, "rec_mem_limit_mib": c.rec_mem_lim,
        })
    return {"verdict": c.ai_verdict, "reason": result}


# ── Refresh ───────────────────────────────────────────────────────────────────
@app.post("/api/refresh")
def manual_refresh(background_tasks: BackgroundTasks):
    background_tasks.add_task(_run_fetch, "user")
    return {"ok": True, "message": "Fetch started in background"}


@app.get("/api/sync/status")
def sync_status():
    return {
        "running":     _sync_state["running"],
        "finished_at": _sync_state["finished_at"],
        "error":       _sync_state["error"],
    }


@app.get("/api/ai-assess/status")
def ai_assess_status():
    return {
        "running":     _ai_assess_state["running"],
        "finished_at": _ai_assess_state["finished_at"],
        "last_count":  _ai_assess_state["last_count"],
        "error":       _ai_assess_state["error"],
    }


@app.post("/api/ai-assess/trigger")
def ai_assess_trigger(background_tasks: BackgroundTasks):
    """Manually trigger an AI assessment run on all nodes."""
    background_tasks.add_task(_run_ai_assess_all_nodes)
    return {"ok": True, "message": "AI assessment started in background"}


# ── Webjob2 (manual trigger for DB repopulation) ───────────────────────────────
@app.post("/api/webjob2/trigger")
def webjob2_trigger(background_tasks: BackgroundTasks,
                    _session=Depends(_get_session)):
    """Manually trigger webjob2 to collect metrics and repopulate database. Admin only."""
    if _session.get("role") != "admin":
        raise HTTPException(403, "Admin role required")

    def _run_webjob2():
        """Run webjob2_collector in background."""
        try:
            import webjob2_collector
            webjob2_collector.run()
            print("[admin] Webjob2 manual trigger completed successfully")
        except Exception as e:
            print(f"[admin] Webjob2 manual trigger failed: {e}")

    background_tasks.add_task(_run_webjob2)
    return {"ok": True, "message": "Webjob2 data collection started in background"}


# ── Preview (fetch from Grafana, return without writing to DB) ────────────────
@app.get("/api/debug/prom")
def debug_prom_queries(db: Session = Depends(get_db)):
    """
    Diagnostic endpoint — runs a small set of Prometheus queries against each
    Mimir datasource and returns raw label samples so you can verify label names
    and whether data is actually returned.  Does NOT write to DB.
    """
    if not GRAFANA_URL or not GRAFANA_TOKEN:
        raise HTTPException(503, "GRAFANA_URL / GRAFANA_TOKEN not configured")

    _CPU = 'container_cpu_usage_seconds_total{container!="",container!="POD"}'
    _MEM = 'container_memory_working_set_bytes{container!="",container!="POD"}'

    report = []
    try:
        datasources = gf.list_mimir_datasources(GRAFANA_URL, GRAFANA_TOKEN)
    except Exception as e:
        raise HTTPException(502, f"Could not reach Grafana: {e}")

    for ds in datasources:
        uid = ds["uid"]
        entry: dict = {"datasource": ds["name"], "uid": uid, "queries": []}

        def _probe(label: str, expr: str):
            try:
                results = gf.query_prom_instant(GRAFANA_URL, GRAFANA_TOKEN, uid, expr)
                samples = [r.get("metric", {}) for r in results[:3]]
                values  = [r.get("value", [None, None])[1] for r in results[:3]]
                entry["queries"].append({
                    "label": label,
                    "expr": expr[:120],
                    "total_series": len(results),
                    "sample_labels": samples,
                    "sample_values": values,
                })
            except Exception as e:
                entry["queries"].append({"label": label, "error": str(e)})

        # 1. Simplest possible queries — verify metric + label presence
        _probe("cpu_instant_raw",
               f'container_cpu_usage_seconds_total{{container="coredns"}}')
        _probe("mem_instant_raw",
               f'container_memory_working_set_bytes{{container="coredns"}}')
        # 2. Aggregated by namespace+container (what _usage_map does)
        _probe("cpu_rate_30d",
               f'sum by(namespace,container)(rate({_CPU}[30d]))')
        _probe("mem_avg_30d",
               f'avg by(namespace,container)(avg_over_time({_MEM}[30d]))')
        # 3. kube_pod_info — confirms pod→namespace mapping works
        _probe("kube_pod_info_sample",
               'kube_pod_info{namespace="kube-system"}')

        report.append(entry)

    return {"datasources_checked": len(datasources), "results": report}


@app.get("/api/preview")
def preview_grafana():
    """Fetch live data from Grafana and return it — no DB writes."""
    if not GRAFANA_URL or not GRAFANA_TOKEN:
        raise HTTPException(503, "GRAFANA_URL / GRAFANA_TOKEN not configured")
    try:
        datasources = gf.list_mimir_datasources(GRAFANA_URL, GRAFANA_TOKEN)
    except Exception as e:
        raise HTTPException(502, f"Could not reach Grafana: {e}")

    nodes_out = []
    ctrs_out = []
    errors = []

    _preview_db = SkuSessionLocal()
    try:
        sku_map = _build_sku_map(_preview_db)
    finally:
        _preview_db.close()

    for ds in datasources:
        try:
            raw_nodes = gf.fetch_node_metrics(GRAFANA_URL, GRAFANA_TOKEN, ds)
            for n in raw_nodes:
                sku = n.get("current_sku") or ""
                rec = recommend_sku(sku, n["cpu_alloc"], n["cpu_avg_pct"], n["mem_avg_pct"], sku_map)
                cur_s = sku_map.get(sku, {})
                rec_s = rec or {}
                saving = cur_s.get("price", 0) - rec_s.get("price", 0) if rec else 0
                nodes_out.append({
                    "node_name":    n["node_name"],
                    "cluster":      n["cluster"],
                    "nodepool":     n["nodepool"],
                    "region":       n["region"],
                    "current_sku":  sku,
                    "rec_sku":      rec_s.get("sku"),
                    "cpu_alloc":    n["cpu_alloc"],
                    "mem_alloc_gb": n["mem_alloc_gb"],
                    "cpu_avg_pct":  n["cpu_avg_pct"],
                    "cpu_max_pct":  n["cpu_max_pct"],
                    "mem_avg_pct":  n["mem_avg_pct"],
                    "mem_max_pct":  n["mem_max_pct"],
                    "current_price": cur_s.get("price", 0),
                    "rec_price":    rec_s.get("price"),
                    "saving":       saving,
                    "datasource":   ds["name"],
                })
        except Exception as e:
            errors.append(f"nodes/{ds['name']}: {e}")

        try:
            raw_ctrs = gf.fetch_container_metrics(GRAFANA_URL, GRAFANA_TOKEN, ds)
            for c in raw_ctrs:
                ctrs_out.append({**c, "datasource": ds["name"]})
        except Exception as e:
            errors.append(f"containers/{ds['name']}: {e}")

    return {
        "datasources": [ds["name"] for ds in datasources],
        "nodes":      nodes_out,
        "containers": ctrs_out,
        "errors":     errors,
    }


# ── Stats ─────────────────────────────────────────────────────────────────────
@app.get("/api/stats")
def get_stats(db: Session = Depends(get_db)):
    nodes = db.query(Node).all()
    ctrs  = db.query(Container).all()
    saving = sum(n.saving or 0 for n in nodes if n.status == "pending")
    return {
        "nodes": {
            "total": len(nodes),
            "pending":  sum(1 for n in nodes if n.status == "pending"),
            "approved": sum(1 for n in nodes if n.status == "approved"),
            "ignored":  sum(1 for n in nodes if n.status == "ignored"),
            "monthly_saving": saving,
            "annual_saving":  saving * 12,
        },
        "containers": {
            "total":   len(ctrs),
            "pending": sum(1 for c in ctrs if c.status == "pending"),
        },
    }


# ── History ───────────────────────────────────────────────────────────────────
@app.get("/api/history")
def get_history(entity_type: str = None, limit: int = 200,
                db: Session = Depends(get_db)):
    q = db.query(ActionHistory)
    if entity_type:
        q = q.filter(ActionHistory.entity_type == entity_type)
    rows = q.order_by(ActionHistory.created_at.desc()).limit(limit).all()
    return {"history": [
        {"id": r.id, "entity_type": r.entity_type, "entity_name": r.entity_name,
         "action": r.action, "performed_by": r.performed_by,
         "details": r.details, "created_at": r.created_at.isoformat()}
        for r in rows
    ]}


# ── Bulk approve ──────────────────────────────────────────────────────────────
class BulkApproveBody(BaseModel):
    node_names: Optional[List[str]] = None   # if None → approve all pending
    performed_by: str = "user"


@app.post("/api/nodes/bulk/approve")
def bulk_approve_nodes(body: BulkApproveBody, db: Session = Depends(get_db)):
    q = db.query(Node).filter(Node.status == "pending", Node.rec_sku.isnot(None))
    if body.node_names:
        q = q.filter(Node.node_name.in_(body.node_names))
    nodes = q.all()
    for n in nodes:
        n.status = "approved"
        db.add(ActionHistory(entity_type="node", entity_name=n.node_name,
                             action="approved", performed_by=body.performed_by, details={}))
    db.commit()
    return {"ok": True, "approved": len(nodes)}


# ── Helpers ───────────────────────────────────────────────────────────────────
def _node_dict(n: Node) -> dict:
    return {
        "node_name":     n.node_name,
        "cluster":       n.cluster,
        "nodepool":      n.nodepool,
        "region":        n.region,
        "current_sku":   n.current_sku,
        "rec_sku":       n.rec_sku,
        "cpu_alloc":     n.cpu_alloc,
        "mem_alloc_gb":  n.mem_alloc_gb,
        "cpu_avg_pct":   n.cpu_avg_pct,
        "cpu_max_pct":   n.cpu_max_pct,
        "mem_avg_pct":   n.mem_avg_pct,
        "mem_max_pct":   n.mem_max_pct,
        "cpu_avg_cores": n.cpu_avg_cores,
        "cpu_max_cores": n.cpu_max_cores,
        "mem_avg_gb":    n.mem_avg_gb,
        "mem_max_gb":    n.mem_max_gb,
        "current_price": n.current_price,
        "rec_price":     n.rec_price,
        "saving":        n.saving or 0,
        "saved_pct":     n.saved_pct or 0,
        "confidence":        n.confidence,
        "pod_count_30d_max": n.pod_count_30d_max,
        "status":            n.status,
        "ai_reason":         n.ai_reason,
        "ai_verdict":        n.ai_verdict,
        "last_fetched_at":   n.last_fetched_at.isoformat() if n.last_fetched_at else None,
    }


def _ctr_dict(c: Container) -> dict:
    return {
        "container_id":      c.container_id,
        "container_name":    c.container_name,
        "namespace":         c.namespace,
        "cluster":           c.cluster,
        "region":            c.region,
        "pod_count":         c.pod_count,
        "cpu_request":       c.cpu_request,
        "cpu_limit":         c.cpu_limit,
        "mem_request_mib":   c.mem_request_mib,
        "mem_limit_mib":     c.mem_limit_mib,
        "cpu_avg":           c.cpu_avg,
        "cpu_p50":           c.cpu_p50,
        "cpu_p90":           c.cpu_p90,
        "cpu_p95":           c.cpu_p95,
        "cpu_max":           c.cpu_max,
        "mem_avg_mib":       c.mem_avg_mib,
        "mem_p50_mib":       c.mem_p50_mib,
        "mem_p90_mib":       c.mem_p90_mib,
        "mem_p95_mib":       c.mem_p95_mib,
        "mem_max_mib":       c.mem_max_mib,
        "cpu_util_pct":      c.cpu_util_pct,
        "mem_util_pct":      c.mem_util_pct,
        "cpu_max_pct":       c.cpu_max_pct,
        "mem_max_pct":       c.mem_max_pct,
        "rec_cpu_request":   c.rec_cpu_request,
        "rec_cpu_limit":     c.rec_cpu_limit,
        "rec_mem_request_mib": c.rec_mem_req,
        "rec_mem_limit_mib":   c.rec_mem_lim,
        "pod_names":         c.pod_names or [],
        "pod_node_map":      c.pod_node_map or {},
        "node_names":        c.node_names or [],
        "last_exit_reason":  c.last_exit_reason,
        "restart_count":     c.restart_count,
        "status":            c.status,
        "ai_reason":         c.ai_reason,
        "ai_verdict":        c.ai_verdict,
        "ai_assessed_at":    c.ai_assessed_at.isoformat() if c.ai_assessed_at else None,
        "last_fetched_at":   c.last_fetched_at.isoformat() if c.last_fetched_at else None,
    }
