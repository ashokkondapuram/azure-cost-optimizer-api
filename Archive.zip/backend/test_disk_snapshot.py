"""
Test suite for disk and snapshot functionality
Tests model creation, portal URLs, cost calculations, and bulk operations
"""

import sys
from pathlib import Path
from datetime import datetime, timezone

sys.path.insert(0, str(Path(__file__).parent))

from database import SessionLocal, init_db
from models import Disk, Snapshot
from sqlalchemy import delete


def test_disk_model():
    """Test Disk model and portal URL generation."""
    init_db()
    db = SessionLocal()

    try:
        db.execute(delete(Disk).where(Disk.subscription_id == "test-sub"))
        db.commit()

        sub_id = "test-sub"
        disk_id = "/subscriptions/test-sub/resourceGroups/test-rg/providers/Microsoft.Compute/disks/test-disk"
        portal_url = f"https://portal.azure.com/#@microsoft.onmicrosoft.com/resource{disk_id}"

        disk = Disk(
            subscription_id=sub_id,
            disk_id=disk_id,
            disk_name="test-disk",
            resource_group="test-rg",
            region="eastus",
            sku="Premium_LRS",
            size_gb=256,
            iops=5000,
            throughput_mbps=200,
            attached_vm_ids=[],
            monthly_cost=16.64,  # 256 * 0.065
            portal_url=portal_url,
        )
        db.add(disk)
        db.commit()

        # Verify portal URL format
        assert "portal.azure.com" in disk.portal_url, "Portal URL invalid"
        assert disk.disk_id in disk.portal_url, "Portal URL missing resource ID"
        print(f"✓ Disk model: portal_url = {disk.portal_url[:80]}…")

        # Verify cost calculation
        assert disk.monthly_cost == 16.64, f"Expected cost 16.64, got {disk.monthly_cost}"
        print(f"✓ Disk cost: {disk.size_gb}GB × Premium_LRS = ${disk.monthly_cost}/mo")

        db.execute(delete(Disk).where(Disk.subscription_id == "test-sub"))
        db.commit()

    finally:
        db.close()


def test_snapshot_model():
    """Test Snapshot model with age calculation and portal URLs."""
    init_db()
    db = SessionLocal()

    try:
        db.execute(delete(Snapshot).where(Snapshot.subscription_id == "test-sub"))
        db.commit()

        sub_id = "test-sub"
        snap_id = "/subscriptions/test-sub/resourceGroups/test-rg/providers/Microsoft.Compute/snapshots/test-snap"
        portal_url = f"https://portal.azure.com/#@microsoft.onmicrosoft.com/resource{snap_id}"

        # Create snapshot from 30 days ago
        creation_time = datetime.now(timezone.utc)
        age_days = 30

        snapshot = Snapshot(
            subscription_id=sub_id,
            snapshot_id=snap_id,
            snapshot_name="test-snap",
            resource_group="test-rg",
            region="eastus",
            sku="Standard_LRS",
            size_gb=512,
            source_disk_id="/subscriptions/test-sub/resourceGroups/test-rg/providers/Microsoft.Compute/disks/source-disk",
            monthly_cost=2.56,  # 512 * 0.005
            portal_url=portal_url,
            creation_time=creation_time,
            age_days=age_days,
        )
        db.add(snapshot)
        db.commit()

        # Verify portal URL
        assert "portal.azure.com" in snapshot.portal_url, "Portal URL invalid"
        assert snapshot.snapshot_id in snapshot.portal_url, "Portal URL missing resource ID"
        print(f"✓ Snapshot model: portal_url = {snapshot.portal_url[:80]}…")

        # Verify age calculation
        assert snapshot.age_days == 30, f"Expected age 30 days, got {snapshot.age_days}"
        print(f"✓ Snapshot age: {snapshot.age_days} days (created {snapshot.creation_time.isoformat()})")

        # Verify cost
        assert snapshot.monthly_cost == 2.56, f"Expected cost 2.56, got {snapshot.monthly_cost}"
        print(f"✓ Snapshot cost: {snapshot.size_gb}GB × Standard_LRS = ${snapshot.monthly_cost}/mo")

        db.execute(delete(Snapshot).where(Snapshot.subscription_id == "test-sub"))
        db.commit()

    finally:
        db.close()


def test_bulk_disk_insertion():
    """Test bulk insertion of disks with different SKUs."""
    init_db()
    db = SessionLocal()

    try:
        db.execute(delete(Disk).where(Disk.subscription_id == "test-bulk"))
        db.commit()

        skus = ["Premium_LRS", "StandardSSD_LRS", "Standard_LRS"]
        prices = {
            "Premium_LRS": 0.065,
            "StandardSSD_LRS": 0.025,
            "Standard_LRS": 0.010,
        }

        disks = [
            {
                "subscription_id": "test-bulk",
                "disk_id": f"/subscriptions/test-bulk/resourceGroups/rg/providers/Microsoft.Compute/disks/disk-{i}",
                "disk_name": f"disk-{i}",
                "resource_group": "rg",
                "region": "eastus",
                "sku": skus[i % len(skus)],
                "size_gb": 100 + (i * 50),
                "iops": 3000 + (i * 100),
                "throughput_mbps": 125 + (i * 10),
                "attached_vm_ids": [],
                "monthly_cost": round((100 + (i * 50)) * prices[skus[i % len(skus)]], 2),
                "portal_url": f"https://portal.azure.com/#@microsoft.onmicrosoft.com/resource/subscriptions/test-bulk/resourceGroups/rg/providers/Microsoft.Compute/disks/disk-{i}",
            }
            for i in range(12)
        ]

        db.bulk_insert_mappings(Disk, disks)
        db.commit()

        count = db.query(Disk).filter(Disk.subscription_id == "test-bulk").count()
        assert count == 12, f"Expected 12 disks, got {count}"
        print(f"✓ Bulk insert: {count} disks with mixed SKUs")

        # Verify total cost
        disk_list = db.query(Disk).filter(Disk.subscription_id == "test-bulk").all()
        total_cost = sum(d.monthly_cost for d in disk_list)
        print(f"✓ Total monthly cost: ${total_cost:.2f}")

        db.execute(delete(Disk).where(Disk.subscription_id == "test-bulk"))
        db.commit()

    finally:
        db.close()


def test_snapshot_filtering():
    """Test snapshot filtering by age for cleanup recommendations."""
    init_db()
    db = SessionLocal()

    try:
        db.execute(delete(Snapshot).where(Snapshot.subscription_id == "test-filter"))
        db.commit()

        now = datetime.now(timezone.utc)

        snapshots = [
            {
                "subscription_id": "test-filter",
                "snapshot_id": f"/subscriptions/test-filter/resourceGroups/rg/providers/Microsoft.Compute/snapshots/snap-{i}",
                "snapshot_name": f"snap-{i}",
                "resource_group": "rg",
                "region": "eastus",
                "sku": "Standard_LRS",
                "size_gb": 100,
                "monthly_cost": 5.0,
                "portal_url": f"https://portal.azure.com/#@microsoft.onmicrosoft.com/resource/snap-{i}",
                "age_days": i * 10,  # 0, 10, 20, 30, 40, 50, 60, 70, 80, 90
                "creation_time": now,
            }
            for i in range(10)
        ]

        db.bulk_insert_mappings(Snapshot, snapshots)
        db.commit()

        # Find old snapshots (older than 60 days)
        old_snaps = db.query(Snapshot).filter(
            Snapshot.subscription_id == "test-filter",
            Snapshot.age_days >= 60
        ).all()

        assert len(old_snaps) == 4, f"Expected 4 old snapshots, got {len(old_snaps)}"
        old_cost = sum(s.monthly_cost for s in old_snaps)
        print(f"✓ Snapshot cleanup: {len(old_snaps)} snapshots older than 60 days = ${old_cost:.2f}/mo potential savings")

        db.execute(delete(Snapshot).where(Snapshot.subscription_id == "test-filter"))
        db.commit()

    finally:
        db.close()


if __name__ == "__main__":
    print("=" * 70)
    print("DISK & SNAPSHOT TESTS")
    print("=" * 70)

    try:
        test_disk_model()
        print()
        test_snapshot_model()
        print()
        test_bulk_disk_insertion()
        print()
        test_snapshot_filtering()
        print()
        print("=" * 70)
        print("✅ ALL TESTS PASSED (4/4)")
        print("=" * 70)
    except AssertionError as e:
        print(f"\n❌ TEST FAILED: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"\n❌ ERROR: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
