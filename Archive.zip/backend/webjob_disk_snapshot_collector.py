"""
WebJob — Disk & Snapshot Collector (Every 5 days)
===================================================
Schedule : every 5 days  (App_Data/jobs/triggered/webjob_disk_snapshot_collector/settings.job)
Local run : python webjob_disk_snapshot_collector.py [--force]

Responsibilities:
  1. Obtain Azure Management token via Managed Identity (cached)
  2. Bulk-fetch all managed disks and snapshots via Azure Compute API
  3. Calculate attachment status, cost estimates, and days since use
  4. Upsert Disk and Snapshot table rows (new data overrides old)
  5. Update webjob state with fetch timestamp and counts
"""

import json
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from sqlalchemy import delete
from database import SessionLocal, DATA_WRITE_LOCK, init_db
from azure_auth import _get_azure_token, _get_subscription_ids, _load_azure_db_creds
from models import Disk, Snapshot, WebjobState
import urllib.request


# ── SKU pricing lookup ─────────────────────────────────────────────────────────
_DISK_PRICING = {
    # Premium_LRS (per GB/month, varies by size but using average)
    "Premium_LRS": {
        "base_per_gb": 0.07,  # ~$70 per 1GB for small sizes, less for large
        "per_disk": 2.0,       # Minimum $2/month per disk
    },
    # StandardSSD_LRS
    "StandardSSD_LRS": {
        "base_per_gb": 0.012,
        "per_disk": 0.5,
    },
    # Standard_LRS
    "Standard_LRS": {
        "base_per_gb": 0.005,
        "per_disk": 0.25,
    },
}

_SNAPSHOT_PRICING = {
    "Premium_LRS": 0.035,      # $/GB/month
    "StandardSSD_LRS": 0.006,
    "Standard_LRS": 0.002,
}


def _estimate_disk_cost(sku: str, size_gb: int) -> float:
    """Estimate monthly cost for a managed disk."""
    pricing = _DISK_PRICING.get(sku, _DISK_PRICING.get("StandardSSD_LRS"))
    return max(size_gb * pricing.get("base_per_gb", 0.012), pricing.get("per_disk", 0.5))


def _estimate_snapshot_cost(sku: str, size_gb: int) -> float:
    """Estimate monthly cost for a snapshot."""
    per_gb = _SNAPSHOT_PRICING.get(sku, _SNAPSHOT_PRICING.get("StandardSSD_LRS"))
    return size_gb * per_gb


def _fetch_disks(subscription_id: str, access_token: str) -> list[dict]:
    """Fetch all managed disks in a subscription."""
    url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Compute/disks?api-version=2023-04-02"
    req = urllib.request.Request(url, method="GET")
    req.add_header("Authorization", f"Bearer {access_token}")

    results = []
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
            for disk in data.get("value", []):
                disk_id = disk.get("id", "")
                sku_obj = disk.get("sku", {})
                results.append({
                    "subscription_id": subscription_id,
                    "disk_id": disk_id,
                    "disk_name": disk.get("name", ""),
                    "resource_group": disk_id.split("/resourceGroups/")[1].split("/")[0] if "/resourceGroups/" in disk_id else "",
                    "region": disk.get("location", ""),
                    "sku": sku_obj.get("name", "Standard_LRS"),
                    "size_gb": disk.get("properties", {}).get("diskSizeGB", 0),
                    "tier": sku_obj.get("name", "").split("_")[0],
                    "iops": disk.get("properties", {}).get("diskIops"),
                    "throughput_mbps": disk.get("properties", {}).get("diskMBpsReadWrite"),
                    "attached_vm_ids": disk.get("properties", {}).get("managedBy") and [disk.get("properties", {}).get("managedBy")] or [],
                    "is_attached": bool(disk.get("properties", {}).get("managedBy")),
                    "creation_time": disk.get("properties", {}).get("timeCreated"),
                    "portal_url": f"https://portal.azure.com/#@/resource{disk_id}",
                })
    except urllib.error.HTTPError as e:
        error_body = e.read().decode(errors="replace")
        print(f"[disk-snap] {subscription_id} disks HTTP {e.code}: {error_body[:200]}")
    except Exception as e:
        print(f"[disk-snap] {subscription_id} disks failed: {e}")

    return results


def _fetch_snapshots(subscription_id: str, access_token: str) -> list[dict]:
    """Fetch all snapshots in a subscription."""
    url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Compute/snapshots?api-version=2023-04-02"
    req = urllib.request.Request(url, method="GET")
    req.add_header("Authorization", f"Bearer {access_token}")

    results = []
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            data = json.loads(r.read().decode())
            for snap in data.get("value", []):
                snap_id = snap.get("id", "")
                sku_obj = snap.get("sku", {})
                source_disk = snap.get("properties", {}).get("sourceResourceId", "")
                results.append({
                    "subscription_id": subscription_id,
                    "snapshot_id": snap_id,
                    "snapshot_name": snap.get("name", ""),
                    "resource_group": snap_id.split("/resourceGroups/")[1].split("/")[0] if "/resourceGroups/" in snap_id else "",
                    "region": snap.get("location", ""),
                    "sku": sku_obj.get("name", "Standard_LRS"),
                    "size_gb": snap.get("properties", {}).get("diskSizeGB", 0),
                    "tier": sku_obj.get("name", "").split("_")[0],
                    "source_disk_id": source_disk if "disks" in source_disk else None,
                    "source_snapshot_id": source_disk if "snapshots" in source_disk else None,
                    "portal_url": f"https://portal.azure.com/#@/resource{snap_id}",
                })
    except urllib.error.HTTPError as e:
        error_body = e.read().decode(errors="replace")
        print(f"[disk-snap] {subscription_id} snapshots HTTP {e.code}: {error_body[:200]}")
    except Exception as e:
        print(f"[disk-snap] {subscription_id} snapshots failed: {e}")

    return results


def _upsert_disks_and_snapshots(db, disks: list[dict], snapshots: list[dict]) -> tuple[int, int]:
    """Upsert disk and snapshot rows. Returns (disks_count, snapshots_count)."""
    now = datetime.now(timezone.utc)

    # Add cost estimates to disks
    for disk in disks:
        disk["monthly_cost"] = _estimate_disk_cost(disk["sku"], disk.get("size_gb", 0))
        disk["fetched_at"] = now

    # Add cost estimates to snapshots
    for snap in snapshots:
        snap["monthly_cost"] = _estimate_snapshot_cost(snap["sku"], snap.get("size_gb", 0))
        snap["fetched_at"] = now

    # Clear old disks and snapshots for these subscriptions (regenerate each run)
    sub_ids = list(set(d["subscription_id"] for d in disks) | set(s["subscription_id"] for s in snapshots))
    if sub_ids:
        db.execute(delete(Disk).where(Disk.subscription_id.in_(sub_ids)))
        db.execute(delete(Snapshot).where(Snapshot.subscription_id.in_(sub_ids)))
        db.commit()

    # Bulk insert
    if disks:
        db.bulk_insert_mappings(Disk, disks)
    if snapshots:
        db.bulk_insert_mappings(Snapshot, snapshots)
    db.commit()

    return len(disks), len(snapshots)


def run(force: bool = False):
    """
    force=True skips webjob_state check — useful for local testing:
      python webjob_disk_snapshot_collector.py --force
    """
    init_db()
    db = SessionLocal()

    try:
        print(f"[disk-snap] Starting disk/snapshot collector — {datetime.now(timezone.utc).isoformat()}")

        if not force:
            row = db.query(WebjobState).filter(WebjobState.job_name == "webjob_disk_snapshot_collector").first()
            if row and row.flag != 1:
                print("[disk-snap] Flag not set — nothing to do")
                return

        # Load Azure DB config
        _load_azure_db_creds()

        # Get token and subscriptions
        access_token = _get_azure_token()
        if not access_token:
            print("[disk-snap] ERROR: Failed to get access token")
            return

        subscription_ids = _get_subscription_ids(access_token)
        if not subscription_ids:
            print("[disk-snap] ERROR: No subscription IDs found")
            return

        print(f"[disk-snap] Fetching disks and snapshots for {len(subscription_ids)} subscriptions…")

        # Parallel fetch
        all_disks = []
        all_snapshots = []

        def _fetch_sub(sub_id):
            disks = _fetch_disks(sub_id, access_token)
            snapshots = _fetch_snapshots(sub_id, access_token)
            return disks, snapshots

        with ThreadPoolExecutor(max_workers=5) as pool:
            futures = [pool.submit(_fetch_sub, sub_id) for sub_id in subscription_ids]
            for f in as_completed(futures):
                disks, snapshots = f.result()
                all_disks.extend(disks)
                all_snapshots.extend(snapshots)

        print(f"[disk-snap] Fetched {len(all_disks)} disks, {len(all_snapshots)} snapshots from Azure")

        # Upsert with write lock
        with DATA_WRITE_LOCK:
            disk_count, snap_count = _upsert_disks_and_snapshots(db, all_disks, all_snapshots)
            print(f"[disk-snap] ✓ DB write done: {disk_count} disks, {snap_count} snapshots upserted")

        # Update webjob state
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob_disk_snapshot_collector").first()
        if not row:
            row = WebjobState(job_name="webjob_disk_snapshot_collector")
            db.add(row)
        row.last_run_at = datetime.now(timezone.utc)
        row.last_run_ok = True
        row.flag = 0
        row.context = {
            "disks_upserted": disk_count,
            "snapshots_upserted": snap_count,
        }
        db.commit()
        print(f"[disk-snap] ✓ DB write done: Collector state updated")
        print("[disk-snap] Done")

    except Exception as e:
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob_disk_snapshot_collector").first()
        if row:
            row.last_run_ok = False
            row.last_error = str(e)
            db.commit()
            print(f"[disk-snap] ✓ DB write done: Error recorded")
        print(f"[disk-snap] ERROR: {e}")
        raise

    finally:
        db.close()


if __name__ == "__main__":
    force = "--force" in sys.argv
    run(force=force)
