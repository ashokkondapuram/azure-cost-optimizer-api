"""
Mimir / Prometheus query helpers — server-side equivalents of the JS
queryPromProxy / queryRange / queryInstant functions in the dashboard.
"""

import json
import ssl
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from typing import Any

# Shared SSL context — Azure Managed Grafana cert chain may not verify cleanly
_SSL = ssl.create_default_context()
_SSL.check_hostname = False
_SSL.verify_mode = ssl.CERT_NONE


def _gf_get(grafana_url: str, token: str, path: str, timeout: int = 60) -> Any:
    url = grafana_url.rstrip("/") + path
    req = urllib.request.Request(url)
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Accept", "application/json")
    with urllib.request.urlopen(req, context=_SSL, timeout=timeout) as resp:
        raw = resp.read()
        data = json.loads(raw)
        if isinstance(data, dict) and data.get("status") == "error":
            print(f"  Prometheus error: {data.get('error','')[:200]}")
        return data


def _gf_post(grafana_url: str, token: str, path: str, body: dict, timeout: int = 90) -> Any:
    url = grafana_url.rstrip("/") + path
    data = json.dumps(body).encode()
    req = urllib.request.Request(url, data=data, method="POST")
    req.add_header("Authorization", f"Bearer {token}")
    req.add_header("Content-Type", "application/json")
    req.add_header("Accept", "application/json")
    with urllib.request.urlopen(req, context=_SSL, timeout=timeout) as resp:
        return json.loads(resp.read())


def list_mimir_datasources(grafana_url: str, token: str) -> list[dict]:
    all_ds = _gf_get(grafana_url, token, "/api/datasources")
    return [
        {"name": d["name"], "uid": d["uid"],
         "region": _ds_region(d["name"])}
        for d in all_ds
        if d.get("type") == "prometheus" and
           ("mimir" in d["name"].lower() or
            d.get("jsonData", {}).get("prometheusType") == "Mimir")
    ]


def _ds_region(name: str) -> str:
    import re
    m = re.search(r"[-_]([A-Za-z]+)$", name)
    return m.group(1) if m else name


# ── Native Prometheus instant query (returns full label set) ─────────────────
def query_prom_instant(grafana_url: str, token: str, uid: str, promql: str) -> list[dict]:
    ts = int(datetime.now(timezone.utc).timestamp())
    path = (f"/api/datasources/uid/{uid}/resources/api/v1/query"
            f"?query={urllib.parse.quote(promql)}&time={ts}")
    data = _gf_get(grafana_url, token, path, timeout=90)
    results = data.get("data", {}).get("result", [])
    print(f"  [prom] {promql[:80]} → {len(results)} series"
          + (f" | sample labels: {results[0].get('metric',{})}" if results else " | EMPTY"))
    return results


# ── Grafana /api/ds/query range (returns avg + max per label key) ─────────────
def query_range(grafana_url: str, token: str, uid: str, expr: str,
                label_key: str = "node") -> dict[str, dict]:
    body = {
        "queries": [{"refId": "A", "datasource": {"type": "prometheus", "uid": uid},
                     "expr": expr, "instant": False, "range": True,
                     "intervalMs": 86400000, "maxDataPoints": 30}],  # daily, 30 pts
        "from": "now-30d", "to": "now",
    }
    data = _gf_post(grafana_url, token, "/api/ds/query", body, timeout=120)
    out = {}
    for f in data.get("results", {}).get("A", {}).get("frames", []):
        labels = f.get("schema", {}).get("fields", [{}])[1].get("labels", {}) \
                 if len(f.get("schema", {}).get("fields", [])) > 1 else {}
        # Support compound key for containers: namespace/container
        if isinstance(label_key, (list, tuple)):
            key = "/".join(labels.get(k, "") for k in label_key)
        else:
            key = labels.get(label_key, "")
        if not key:
            continue
        vals = [v for v in (f.get("data", {}).get("values", [[]])[1] or [])
                if v is not None and isinstance(v, (int, float))]
        if vals:
            out[key] = {"avg": sum(vals) / len(vals), "max": max(vals)}
    return out


def fetch_node_hourly_pattern(grafana_url: str, token: str, uid: str,
                              node_names: list[str]) -> dict:
    """
    Fetch hourly CPU usage over the last 7 days for the given nodes.
    Returns comprehensive percentile analysis for AI assessment.

    Returns dict with:
      - 'by_hour': {hour(0-23): avg_cpu_pct}
      - 'percentiles': {p1, p5, p10, p25, p50, p75, p90, p95, p99, p99_9} - all percentile levels
      - 'peak_hours': list of hours where usage > 70% of max
      - 'off_peak_hours': list of hours consistently < 30% of max
      - 'weekday_vs_weekend': avg usage comparison
      - 'raw_summary': human-readable string for the AI prompt
    """
    if not node_names:
        return {}

    # Build node selector — use regex to match all nodes in pool
    node_sel = "|".join(n.replace(".", "\\.") for n in node_names[:20])  # cap for query size
    expr = (f'avg by(node)(rate(container_cpu_usage_seconds_total'
            f'{{container!="",container!="POD",node=~"{node_sel}"}}[5m]))')

    body = {
        "queries": [{"refId": "A", "datasource": {"type": "prometheus", "uid": uid},
                     "expr": expr, "instant": False, "range": True,
                     "intervalMs": 3600000, "maxDataPoints": 168}],  # hourly, 7 days (168 hours)
        "from": "now-7d", "to": "now",
    }
    try:
        data = _gf_post(grafana_url, token, "/api/ds/query", body, timeout=90)
    except Exception as e:
        print(f"  fetch_node_hourly_pattern failed: {e}")
        return {}

    # Collect all timestamped values into DataFrame for vectorized aggregation
    import pandas as pd

    all_times = []
    all_values = []
    for f in data.get("results", {}).get("A", {}).get("frames", []):
        times  = f.get("data", {}).get("values", [[]])[0] or []
        values = f.get("data", {}).get("values", [[]])[1] or []
        for ts_ms, v in zip(times, values):
            if v is None or not isinstance(v, (int, float)):
                continue
            all_times.append(ts_ms)
            all_values.append(float(v))

    if not all_times:
        return {}

    # Create DataFrame with datetime index and value column
    df = pd.DataFrame({
        'timestamp': pd.to_datetime(all_times, unit='ms', utc=True),
        'value': all_values
    })

    # Hourly aggregation: group by hour of day
    by_hour = df.groupby(df['timestamp'].dt.hour)['value'].mean().round(3).to_dict()

    # Calculate ALL percentile levels for comprehensive AI analysis
    percentile_levels = [0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 0.999]
    percentiles_raw = df['value'].quantile(percentile_levels)

    percentiles = {
        "p1": round(percentiles_raw[0.01] * 100, 1),      # 1st percentile
        "p5": round(percentiles_raw[0.05] * 100, 1),      # 5th percentile
        "p10": round(percentiles_raw[0.10] * 100, 1),     # 10th percentile
        "p25": round(percentiles_raw[0.25] * 100, 1),     # 1st quartile
        "p50": round(percentiles_raw[0.50] * 100, 1),     # Median
        "p75": round(percentiles_raw[0.75] * 100, 1),     # 3rd quartile
        "p90": round(percentiles_raw[0.90] * 100, 1),     # 90th percentile
        "p95": round(percentiles_raw[0.95] * 100, 1),     # SLA threshold
        "p99": round(percentiles_raw[0.99] * 100, 1),     # 99th percentile
        "p99_9": round(percentiles_raw[0.999] * 100, 1),  # 99.9th percentile
        "min": round(df['value'].min() * 100, 1),
        "max": round(df['value'].max() * 100, 1),
        "avg": round(df['value'].mean() * 100, 1),
    }

    max_val  = max(by_hour.values()) if by_hour else 0

    # Peak/off-peak detection with configurable thresholds
    PEAK_THRESHOLD = 0.70
    OFF_PEAK_THRESHOLD = 0.30
    peak_hours    = sorted([h for h, v in by_hour.items() if max_val > 0 and v >= max_val * PEAK_THRESHOLD])
    off_pk_hours  = sorted([h for h, v in by_hour.items() if max_val > 0 and v <= max_val * OFF_PEAK_THRESHOLD])

    # Weekday/weekend split using dt accessor
    weekday_avg   = df[df['timestamp'].dt.weekday < 5]['value'].mean()
    weekend_avg   = df[df['timestamp'].dt.weekday >= 5]['value'].mean()

    def _fmt_hours(hours):
        if not hours: return "none"
        ranges, start, prev = [], hours[0], hours[0]
        for h in hours[1:]:
            if h == prev + 1: prev = h
            else:
                ranges.append(f"{start:02d}:00–{prev+1:02d}:00" if start != prev else f"{start:02d}:00")
                start = prev = h
        ranges.append(f"{start:02d}:00–{prev+1:02d}:00" if start != prev else f"{start:02d}:00")
        return ", ".join(ranges)

    summary = (
        f"7-day usage distribution: p50(median)={percentiles['p50']}%, "
        f"p95={percentiles['p95']}%, p99={percentiles['p99']}%, p99.9={percentiles['p99_9']}% | "
        f"Peak hours {_fmt_hours(peak_hours)} | "
        f"Weekday {weekday_avg*100:.1f}% vs Weekend {weekend_avg*100:.1f}%"
    )

    return {
        "by_hour":            by_hour,
        "percentiles":        percentiles,  # All 10 percentile levels + min/max/avg
        "peak_hours":         peak_hours,
        "off_peak_hours":     off_pk_hours,
        "weekday_avg_pct":    round(weekday_avg * 100, 1),
        "weekend_avg_pct":    round(weekend_avg * 100, 1),
        "raw_summary":        summary,
    }


# ── Live pool instant feed (SSE / WebJob 1) ──────────────────────────────────
def fetch_pool_live(grafana_url: str, token: str, uid: str,
                   node_names: list[str]) -> dict:
    """
    Instant snapshot of CPU%, Mem%, and pod count for nodes in a pool.
    Used by the SSE endpoint — no DB writes, called every 15 s.
    Returns: {node_name: {cpu_pct, mem_pct, pod_count}}
    """
    if not node_names:
        return {}

    sel = "|".join(n.replace(".", "\\.") for n in node_names[:30])

    def _instant(expr: str) -> dict[str, float]:
        try:
            rows = query_prom_instant(grafana_url, token, uid, expr)
            return {r["metric"].get("node", ""): float(r["value"][1])
                    for r in rows if r.get("value")}
        except Exception:
            return {}

    # CPU: cores used → percent of allocatable
    alloc_cpu  = _instant(f'kube_node_status_allocatable{{resource="cpu",node=~"{sel}"}}')
    used_cpu   = _instant(f'sum by(node)(rate(container_cpu_usage_seconds_total{{container!="",container!="POD",node=~"{sel}"}}[2m]))')
    alloc_mem  = _instant(f'kube_node_status_allocatable{{resource="memory",node=~"{sel}"}} / 1073741824')
    used_mem   = _instant(f'sum by(node)(container_memory_working_set_bytes{{container!="",container!="POD",node=~"{sel}"}}) / 1073741824')
    pods       = _instant(f'count by(node)(kube_pod_info{{node=~"{sel}"}})')

    result = {}
    for node in node_names:
        a_cpu = alloc_cpu.get(node, 0) or 1  # avoid /0
        a_mem = alloc_mem.get(node, 0) or 1
        result[node] = {
            "cpu_pct":   round(used_cpu.get(node, 0) / a_cpu * 100, 1),
            "mem_pct":   round(used_mem.get(node, 0) / a_mem * 100, 1),
            "pod_count": int(pods.get(node, 0)),
        }
    return result


# ── Node-level data ──────────────────────────────────────────────────────────
def fetch_node_labels(grafana_url: str, token: str, uid: str) -> dict[str, dict]:
    """Returns {node: {sku, cluster, nodepool}} from kube_node_labels."""
    out: dict[str, dict] = {}

    import re as _re

    def absorb(node, labels):
        if not node:
            return
        sku = (labels.get("label_node_kubernetes_io_instance_type") or
               labels.get("label_beta_kubernetes_io_instance_type") or
               labels.get("label_kubernetes_azure_com_sku_name") or
               labels.get("label_cloud_google_com_machine_family") or
               labels.get("label_node_gke_io_accelerator"))
        cluster = labels.get("cluster") or labels.get("node_kubernetes_io_cluster", "")
        np_label = (labels.get("label_agentpool") or
                    labels.get("label_kubernetes_azure_com_agentpool", ""))
        m = _re.match(r"^aks-([^-]+)-", node)
        nodepool = np_label or (m.group(1) if m else node.split("-")[1] if "-" in node else "")

        if node not in out:
            out[node] = {"sku": None, "cluster": "", "nodepool": ""}
        if sku and not out[node]["sku"]:
            out[node]["sku"] = sku
        if cluster and not out[node]["cluster"]:
            out[node]["cluster"] = cluster
        if nodepool and not out[node]["nodepool"]:
            out[node]["nodepool"] = nodepool

    for label_key in ["label_node_kubernetes_io_instance_type",
                      "label_beta_kubernetes_io_instance_type"]:
        results = query_prom_instant(
            grafana_url, token, uid,
            f'kube_node_labels{{{label_key}!=""}}'
        )
        for r in results:
            absorb(r.get("metric", {}).get("node"), r.get("metric", {}))
        if out:
            break
    return out


def fetch_node_metrics(grafana_url: str, token: str, ds: dict) -> list[dict]:
    """Fetch all node metrics from one datasource. Returns list of node dicts."""
    uid = ds["uid"]

    def _safe(fn, *args, default=None, **kwargs):
        try:
            return fn(*args, **kwargs)
        except Exception as e:
            print(f"  Node metric query failed ({ds['name']}): {e}")
            return default if default is not None else {}

    cpu_alloc   = _safe(_instant_by_node, grafana_url, token, uid,
        'sum by(node)(kube_node_status_allocatable{resource="cpu"})')
    mem_alloc   = _safe(_instant_by_node, grafana_url, token, uid,
        'sum by(node)(kube_node_status_allocatable{resource="memory"}) / 1073741824')
    cpu_range   = _safe(query_range, grafana_url, token, uid,
        'sum by(node)(rate(container_cpu_usage_seconds_total{container!="",container!="POD"}[5m]))')
    mem_range   = _safe(query_range, grafana_url, token, uid,
        'sum by(node)(container_memory_working_set_bytes{container!="",container!="POD"}) / 1073741824')
    node_labels = _safe(fetch_node_labels, grafana_url, token, uid)

    # Current pod count per node — simpler instant query, no subquery (avoids 400/500)
    pod_activity: dict[str, int] = {}
    try:
        for r in query_prom_instant(grafana_url, token, uid,
                'count by(node)(kube_pod_info{node!=""})'):
            node = r.get("metric", {}).get("node", "")
            if node:
                pod_activity[node] = int(float(r.get("value", [0, 0])[1] or 0))
    except Exception as e:
        print(f"  pod_activity query failed ({ds['name']}): {e}")

    nodes = []
    for node in set(list(cpu_alloc) + list(mem_alloc)):
        cpu_a = cpu_alloc.get(node, 0)
        mem_a = mem_alloc.get(node, 0)
        cs = cpu_range.get(node, {"avg": 0, "max": 0})
        ms = mem_range.get(node, {"avg": 0, "max": 0})
        cpu_avg_pct = (cs["avg"] / cpu_a * 100) if cpu_a else 0
        cpu_max_pct = (cs["max"] / cpu_a * 100) if cpu_a else 0
        mem_avg_pct = (ms["avg"] / mem_a * 100) if mem_a else 0
        mem_max_pct = (ms["max"] / mem_a * 100) if mem_a else 0
        lbl = node_labels.get(node, {})
        import re
        m = re.match(r"^aks-([^-]+)-", node)
        nodepool = lbl.get("nodepool") or (m.group(1) if m else "")
        cluster = lbl.get("cluster") or ""
        nodes.append({
            "node_name": node, "cluster": cluster, "nodepool": nodepool,
            "region": ds["region"],
            "cpu_alloc": cpu_a, "mem_alloc_gb": mem_a,
            "cpu_avg_cores": cs["avg"], "cpu_max_cores": cs["max"],
            "mem_avg_gb": ms["avg"], "mem_max_gb": ms["max"],
            "cpu_avg_pct": cpu_avg_pct, "cpu_max_pct": cpu_max_pct,
            "mem_avg_pct": mem_avg_pct, "mem_max_pct": mem_max_pct,
            "current_sku": lbl.get("sku"),
            "pod_count_30d_max": pod_activity.get(node, 0),
        })

    return nodes


def _instant_by_node(grafana_url, token, uid, expr) -> dict[str, float]:
    """Instant query returning {node: value}."""
    body = {
        "queries": [{"refId": "A", "datasource": {"type": "prometheus", "uid": uid},
                     "expr": expr, "instant": True, "intervalMs": 60000, "maxDataPoints": 1}],
        "from": "now-5m", "to": "now",
    }
    data = _gf_post(grafana_url, token, "/api/ds/query", body)
    out = {}
    for f in data.get("results", {}).get("A", {}).get("frames", []):
        fields = f.get("schema", {}).get("fields", [])
        labels = fields[1].get("labels", {}) if len(fields) > 1 else {}
        node = labels.get("node", "")
        vals = f.get("data", {}).get("values", [[]])[1] or []
        if node and vals:
            out[node] = vals[-1]
    return out


# ── Container-level data ─────────────────────────────────────────────────────
def fetch_container_metrics(grafana_url: str, token: str, ds: dict) -> list[dict]:
    """
    Fetch container request/limit/usage metrics for one datasource.

    Key design decisions
    ────────────────────
    1.  cmap is keyed by "namespace/container" internally (no cluster prefix)
        because usage queries aggregate by namespace+container only.
        The final container_id written to DB is "cluster|namespace/container"
        to ensure uniqueness across clusters. Cluster prefix falls back to
        datasource name if no cluster label is present in the metrics.
        Previously
        into the cmap key causes every usage lookup to return 0.

    2.  kube_pod_info is used for pod→node mapping because KSM ≥2.0 removed the
        `node` label from kube_pod_container_resource_requests/limits.
    """
    uid = ds["uid"]
    region = ds["region"]

    # ── Step 1: pod → node mapping via kube_pod_info ──────────────────────────
    pod_to_node: dict[tuple, str] = {}   # (namespace, pod) → node_name
    pod_to_cluster: dict[tuple, str] = {}
    try:
        for r in query_prom_instant(grafana_url, token, uid, "kube_pod_info"):
            lbl = r.get("metric", {})
            ns, pod, node = lbl.get("namespace",""), lbl.get("pod",""), lbl.get("node","")
            if ns and pod and node:
                pod_to_node[(ns, pod)] = node
                pod_to_cluster[(ns, pod)] = lbl.get("cluster","")
    except Exception as e:
        print(f"  kube_pod_info query failed ({ds['name']}): {e}")

    # ── Step 2: resource requests/limits (instant queries) ────────────────────
    def _safe_instant(expr: str) -> list:
        try:
            return query_prom_instant(grafana_url, token, uid, expr)
        except Exception as e:
            print(f"  Resource query failed ({ds['name']}): {e}")
            return []

    cpu_reqs = _safe_instant('kube_pod_container_resource_requests{resource="cpu",container!="",container!="POD"}')
    mem_reqs = _safe_instant('kube_pod_container_resource_requests{resource="memory",container!="",container!="POD"}')
    cpu_lims = _safe_instant('kube_pod_container_resource_limits{resource="cpu",container!="",container!="POD"}')
    mem_lims = _safe_instant('kube_pod_container_resource_limits{resource="memory",container!="",container!="POD"}')

    # cmap key = "cluster|namespace/container" — includes cluster so same ns/container
    # from different clusters within a federated datasource are stored separately.
    # Falls back to "ds_name|namespace/container" when cluster label is absent.
    ds_name = ds.get("name", "")
    cmap: dict[str, dict] = {}

    def _resolve_cluster(explicit: str) -> str:
        return explicit or ds_name

    def ensure(ns: str, ct: str, cluster: str = "") -> dict:
        cl = _resolve_cluster(cluster)
        k = f"{cl}|{ns}/{ct}"
        if k not in cmap:
            cmap[k] = {"namespace": ns, "container": ct, "cluster": cl,
                       "_ns_ct": f"{ns}/{ct}",
                       "pods": set(), "nodes": set(), "pod_node_map": {},
                       "cpu_request": 0, "cpu_limit": 0,
                       "mem_request_mib": 0, "mem_limit_mib": 0}
        elif cluster and not cmap[k]["cluster"]:
            cmap[k]["cluster"] = cl
        return cmap[k]

    for r in cpu_reqs:
        lbl = r.get("metric", {})
        ns, ct, pod = lbl.get("namespace"), lbl.get("container"), lbl.get("pod")
        if not ns or not ct:
            continue
        # Cluster: prefer explicit label, fall back to what kube_pod_info told us
        cluster = lbl.get("cluster","") or pod_to_cluster.get((ns, pod or ""), "")
        c = ensure(ns, ct, cluster)
        if pod:
            c["pods"].add(pod)
            # Use kube_pod_info mapping; fall back to label if KSM still provides it
            node = pod_to_node.get((ns, pod)) or lbl.get("node","")
            if node:
                c["pod_node_map"][pod] = node
                c["nodes"].add(node)
        c["cpu_request"] = max(c["cpu_request"], float(r.get("value",[0,0])[1] or 0))

    for r in mem_reqs:
        lbl = r.get("metric", {})
        ns, ct, pod = lbl.get("namespace",""), lbl.get("container",""), lbl.get("pod","")
        if not ns or not ct:
            continue
        cluster = lbl.get("cluster","") or pod_to_cluster.get((ns, pod or ""), "")
        k = f"{_resolve_cluster(cluster)}|{ns}/{ct}"
        if k in cmap:
            cmap[k]["mem_request_mib"] = max(
                cmap[k]["mem_request_mib"],
                float(r.get("value",[0,0])[1] or 0) / 1048576)

    for r in cpu_lims:
        lbl = r.get("metric", {})
        ns, ct, pod = lbl.get("namespace",""), lbl.get("container",""), lbl.get("pod","")
        if not ns or not ct:
            continue
        cluster = lbl.get("cluster","") or pod_to_cluster.get((ns, pod or ""), "")
        k = f"{_resolve_cluster(cluster)}|{ns}/{ct}"
        if k in cmap:
            cmap[k]["cpu_limit"] = max(
                cmap[k]["cpu_limit"],
                float(r.get("value",[0,0])[1] or 0))

    for r in mem_lims:
        lbl = r.get("metric", {})
        ns, ct, pod = lbl.get("namespace",""), lbl.get("container",""), lbl.get("pod","")
        if not ns or not ct:
            continue
        cluster = lbl.get("cluster","") or pod_to_cluster.get((ns, pod or ""), "")
        k = f"{_resolve_cluster(cluster)}|{ns}/{ct}"
        if k in cmap:
            cmap[k]["mem_limit_mib"] = max(
                cmap[k]["mem_limit_mib"],
                float(r.get("value",[0,0])[1] or 0) / 1048576)

    # ── Step 3: usage — 30-day lookback via Grafana range-query API ──────────────
    # Avoid instant-query subqueries entirely (Mimir 422/500 limits).
    # Use /api/ds/query with range=true at daily intervals (30 data points).
    # Grafana's range endpoint handles large series counts without hitting
    # max_fetched_series/chunks limits that subqueries hit.
    # Stats (avg, max, p50, p90, p95) are computed client-side from the 30 points.
    _CPU = 'container_cpu_usage_seconds_total{container!="",container!="POD"}'
    _MEM = 'container_memory_working_set_bytes{container!="",container!="POD"}'

    def _range_stats() -> dict[str, dict]:
        """Two range-query calls over last 30 days → {ns/ct: {cpu_avg,cpu_max,
                                             cpu_p1,p5,p10,p25,p50,p75,p90,p95,p99,p99.9,
                                             mem_avg,mem_max,
                                             mem_p1,p5,p10,p25,p50,p75,p90,p95,p99,p99.9}}"""
        stats: dict[str, dict] = {}

        def _collect(expr: str, key_prefix: str, scale: float = 1.0):
            body = {
                "queries": [{"refId": "A",
                              "datasource": {"type": "prometheus", "uid": uid},
                              "expr": expr, "instant": False, "range": True,
                              "intervalMs": 86400000, "maxDataPoints": 30}],
                "from": "now-30d", "to": "now",  # Fetch last 30 days from Mimir
            }
            try:
                data = _gf_post(grafana_url, token, "/api/ds/query", body)
                frames = data.get("results", {}).get("A", {}).get("frames", [])
                print(f"    [range] {expr[:70]} → {len(frames)} frames (30-day lookback)")
                for f in frames:
                    fields = f.get("schema", {}).get("fields", [])
                    lbl = fields[1].get("labels", {}) if len(fields) > 1 else {}
                    ns = lbl.get("namespace", "")
                    ct = lbl.get("container", "") or lbl.get("container_name", "")
                    if not ns or not ct:
                        continue
                    k = f"{ns}/{ct}"
                    import pandas as pd
                    vals_raw = [v * scale
                                for v in (f.get("data", {}).get("values", [[]])[1] or [])
                                if v is not None and isinstance(v, (int, float))]
                    if not vals_raw:
                        continue
                    series = pd.Series(vals_raw)

                    # Calculate all percentile levels for comprehensive analysis
                    percentile_levels = [0.01, 0.05, 0.10, 0.25, 0.50, 0.75, 0.90, 0.95, 0.99, 0.999]
                    percentiles = series.quantile(percentile_levels)

                    if k not in stats:
                        stats[k] = {}

                    stats[k].update({
                        f"{key_prefix}_avg": series.mean(),
                        f"{key_prefix}_max": series.max(),
                        f"{key_prefix}_min": series.min(),
                        # All percentile levels
                        f"{key_prefix}_p1": percentiles[0.01],
                        f"{key_prefix}_p5": percentiles[0.05],
                        f"{key_prefix}_p10": percentiles[0.10],
                        f"{key_prefix}_p25": percentiles[0.25],
                        f"{key_prefix}_p50": percentiles[0.50],
                        f"{key_prefix}_p75": percentiles[0.75],
                        f"{key_prefix}_p90": percentiles[0.90],
                        f"{key_prefix}_p95": percentiles[0.95],
                        f"{key_prefix}_p99": percentiles[0.99],
                        f"{key_prefix}_p99_9": percentiles[0.999],  # p99.9
                    })
            except Exception as e:
                print(f"  Container range stats failed ({ds['name']}/{key_prefix}): {e}")

        _collect(f'sum by(namespace,container)(rate({_CPU}[1d]))', "cpu")
        _collect(f'max by(namespace,container)({_MEM})', "mem", scale=1.0/1048576)
        print(f"    → range stats for {len(stats)} containers")
        return stats

    if not cmap:
        print(f"  [{ds['name']}] cmap is empty — no containers with cpu_request found, skipping usage queries")
        return []

    _stats = _range_stats()

    # Convert usage stats to DataFrame for cleaner lookup (replaces 10 parallel dicts)
    import pandas as pd
    if _stats:
        stats_df = pd.DataFrame(_stats).T  # transpose so keys are row indices
        stats_df = stats_df.fillna(0)  # Missing metrics default to 0
    else:
        stats_df = pd.DataFrame()

    # ── Step 3b: termination reason + restart count ───────────────────────────
    # last_exit_reason: prefer OOMKilled (most critical) over other reasons
    exit_reason_map: dict[str, str] = {}
    try:
        for r in query_prom_instant(grafana_url, token, uid,
                'kube_pod_container_status_last_terminated_reason'
                '{container!="",container!="POD"}'):
            lbl = r.get("metric", {})
            ns, ct, reason = lbl.get("namespace",""), lbl.get("container",""), lbl.get("reason","")
            if ns and ct and reason:
                k2 = f"{ns}/{ct}"
                if k2 not in exit_reason_map or reason == "OOMKilled":
                    exit_reason_map[k2] = reason
    except Exception as e:
        print(f"  Last terminated reason query failed ({ds['name']}): {e}")

    restart_map: dict[str, float] = {}
    try:
        for r in query_prom_instant(grafana_url, token, uid,
                'sum by(namespace,container)'
                '(kube_pod_container_status_restarts_total{container!="",container!="POD"})'):
            lbl = r.get("metric", {})
            ns, ct = lbl.get("namespace", ""), lbl.get("container", "")
            if ns and ct:
                restart_map[f"{ns}/{ct}"] = float(r.get("value", [0, 0])[1] or 0)
    except Exception as e:
        print(f"  Restart count query failed ({ds['name']}): {e}")

    # ── Step 4: assemble results ───────────────────────────────────────────────
    # cmap key is "cluster|ns/ct"; stats_df is indexed by "ns/ct" only
    # (cluster was dropped from usage queries to avoid Mimir 422 limits).
    results = []
    for k, c in cmap.items():
        if not c["cpu_request"]:
            continue
        u = c["_ns_ct"]   # "namespace/container" — usage lookup key

        # Look up stats row (all metrics in one row)
        if u in stats_df.index:
            stats_row = stats_df.loc[u]
        else:
            stats_row = pd.Series({"cpu_avg": 0, "cpu_p50": 0, "cpu_p90": 0, "cpu_p95": 0, "cpu_max": 0,
                                   "mem_avg": 0, "mem_p50": 0, "mem_p90": 0, "mem_p95": 0, "mem_max": 0})

        cpu_avg_v = stats_row.get("cpu_avg", 0) or 0
        cpu_p50_v = stats_row.get("cpu_p50", 0) or 0
        cpu_p90_v = stats_row.get("cpu_p90", 0) or 0
        cpu_p95_v = stats_row.get("cpu_p95", 0) or 0
        cpu_max_v = stats_row.get("cpu_max", 0) or 0
        mem_avg_v = stats_row.get("mem_avg", 0) or 0
        mem_p50_v = stats_row.get("mem_p50", 0) or 0
        mem_p90_v = stats_row.get("mem_p90", 0) or 0
        mem_p95_v = stats_row.get("mem_p95", 0) or 0
        mem_max_v = stats_row.get("mem_max", 0) or 0
        cpu_util    = (cpu_avg_v / c["cpu_request"]     * 100) if c["cpu_request"]     else 0
        mem_util    = (mem_avg_v / c["mem_request_mib"] * 100) if c["mem_request_mib"] else 0
        cpu_max_pct = (cpu_max_v / c["cpu_request"]     * 100) if c["cpu_request"]     else 0
        mem_max_pct = (mem_max_v / c["mem_request_mib"] * 100) if c["mem_request_mib"] else 0
        # container_id = cmap key (already "cluster|ns/ct") — unique across clusters
        cid = k
        results.append({
            "container_id":     cid,
            "container_name":   c["container"],
            "namespace":        c["namespace"],
            "cluster":          c["cluster"],
            "region":           region,
            "pod_count":        len(c["pods"]),
            "pod_names":        sorted(c["pods"]),
            "pod_node_map":     c["pod_node_map"],
            "node_names":       sorted(c["nodes"]),
            "cpu_request":      c["cpu_request"],
            "cpu_limit":        c["cpu_limit"],
            "mem_request_mib":  c["mem_request_mib"],
            "mem_limit_mib":    c["mem_limit_mib"],
            "cpu_avg":          cpu_avg_v,
            "cpu_p50":          cpu_p50_v,
            "cpu_p90":          cpu_p90_v,
            "cpu_p95":          cpu_p95_v,
            "cpu_max":          cpu_max_v,
            "mem_avg_mib":      mem_avg_v,
            "mem_p50_mib":      mem_p50_v,
            "mem_p90_mib":      mem_p90_v,
            "mem_p95_mib":      mem_p95_v,
            "mem_max_mib":      mem_max_v,
            "cpu_util_pct":     cpu_util,
            "mem_util_pct":     mem_util,
            "cpu_max_pct":      cpu_max_pct,
            "mem_max_pct":      mem_max_pct,
            "last_exit_reason": exit_reason_map.get(u),
            "restart_count":    int(restart_map.get(u, 0)),
        })
    clusters_seen = {c["cluster"] for c in cmap.values()}
    print(f"  [{ds['name']}] cmap={len(cmap)} entries, {len(results)} with cpu_request>0, clusters={clusters_seen}")
    return results
