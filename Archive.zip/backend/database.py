"""
database.py — Three-database design: auth / skus / data are fully isolated.

  rightsizing_auth.db   → User, UserSession         (login/logout, always fast)
  rightsizing_skus.db   → VmSku                     (SKU sync, independent)
  rightsizing.db        → Node, Container, Policy,   (main data — fetch writes here)
                           Alert, ActionHistory, FetchLog

Each file has:
  • Its own SQLAlchemy engine + DeclarativeBase
  • Its own threading write-lock (long background tasks only)
  • NullPool — each session gets a fresh OS connection (no shared-pool deadlocks)
  • PRAGMA busy_timeout=60000 — SQLite waits 60 s rather than failing on lock

Result:
  • Login/logout never blocked by a Grafana fetch or SKU sync
  • SKU sync and Grafana fetch can run simultaneously (different files)
  • Read APIs (GET /api/nodes, etc.) hold no Python lock — just SQLite read
"""

import os
import threading
from sqlalchemy import create_engine, event
from sqlalchemy.orm import sessionmaker, DeclarativeBase
from sqlalchemy.pool import NullPool

# Azure App Service: persistent writable storage is under /home/site/wwwroot.
# Writing to /home root directly may be blocked by the container runtime.
# Fallback to the directory of this file (works locally and in containers).
def _find_db_dir() -> str:
    candidates = [
        "/home/site/wwwroot/backend",   # App Service — same dir as main.py
        "/home/site/wwwroot",           # App Service — root
        "/home",                        # legacy fallback
        os.path.dirname(os.path.abspath(__file__)),  # same dir as database.py
    ]
    for path in candidates:
        if os.path.isdir(path) and os.access(path, os.W_OK):
            return path
    return "."

_base = _find_db_dir()

_PG_URL = os.environ.get("DATABASE_URL", "")
_IS_SQLITE = not (_PG_URL and not _PG_URL.startswith("sqlite"))

if _IS_SQLITE:
    DATA_URL = f"sqlite:///{_base}/rightsizing.db"
    AUTH_URL = f"sqlite:///{_base}/rightsizing_auth.db"
    SKU_URL  = f"sqlite:///{_base}/rightsizing_skus.db"
else:
    DATA_URL = AUTH_URL = SKU_URL = _PG_URL


# ── Per-file write-serialisation locks (long background tasks only) ────────────
DATA_WRITE_LOCK = threading.Lock()   # _run_fetch, _recalculate
AUTH_WRITE_LOCK = threading.Lock()   # (reserved — auth writes are tiny/fast)
SKU_WRITE_LOCK  = threading.Lock()   # _sync_vm_skus


# ── Engine factory ─────────────────────────────────────────────────────────────
def _sqlite_engine(url: str):
    eng = create_engine(
        url,
        connect_args={"check_same_thread": False, "timeout": 60},
        poolclass=NullPool,
    )

    @event.listens_for(eng, "connect")
    def _pragmas(dbapi_conn, _):
        dbapi_conn.execute("PRAGMA journal_mode=WAL")
        dbapi_conn.execute("PRAGMA busy_timeout=60000")
        dbapi_conn.execute("PRAGMA synchronous=NORMAL")

    return eng


def _pg_engine(url: str):
    return create_engine(url, pool_pre_ping=True, pool_size=5, max_overflow=10)


_mk = _sqlite_engine if _IS_SQLITE else _pg_engine

_data_engine = _mk(DATA_URL)
_auth_engine = _mk(AUTH_URL)
_sku_engine  = _mk(SKU_URL)


# ── Session factories ──────────────────────────────────────────────────────────
_DataFactory = sessionmaker(bind=_data_engine, autocommit=False, autoflush=False)
_AuthFactory = sessionmaker(bind=_auth_engine, autocommit=False, autoflush=False)
_SkuFactory  = sessionmaker(bind=_sku_engine,  autocommit=False, autoflush=False)


def SessionLocal():     return _DataFactory()
def AuthSessionLocal(): return _AuthFactory()
def SkuSessionLocal():  return _SkuFactory()


# ── FastAPI Depends ────────────────────────────────────────────────────────────
def get_db():
    db = _DataFactory()
    try:    yield db
    finally: db.close()

def get_auth_db():
    db = _AuthFactory()
    try:    yield db
    finally: db.close()

def get_sku_db():
    db = _SkuFactory()
    try:    yield db
    finally: db.close()


# ── Declarative bases (one per DB file) ───────────────────────────────────────
class Base(DeclarativeBase):
    """Data models: Node, Container, Policy, Alert, ActionHistory, FetchLog."""
    pass

class AuthBase(DeclarativeBase):
    """Auth models: User, UserSession."""
    pass

class SkuBase(DeclarativeBase):
    """SKU models: VmSku."""
    pass


def init_db():
    """Create all tables on all three engines (idempotent).
    Also runs lightweight ALTER TABLE migrations for columns added after the
    initial schema so existing DBs don't need a manual drop-and-recreate.
    """
    import models  # noqa: F401
    Base.metadata.create_all(bind=_data_engine)
    AuthBase.metadata.create_all(bind=_auth_engine)
    SkuBase.metadata.create_all(bind=_sku_engine)
    _migrate_sku_db()
    _seed_webjob_state()


def _seed_webjob_state():
    """Ensure one WebjobState row exists per job (idempotent)."""
    from sqlalchemy import text
    jobs = ["webjob_quota_collector", "webjob_disk_snapshot_collector", "webjob2_collector", "webjob3_prescorer", "webjob4_alerter"]

    with _data_engine.connect() as conn:
        for job in jobs:
            exists = conn.execute(
                text("SELECT 1 FROM webjob_state WHERE job_name = :n"), {"n": job}
            ).fetchone()
            if not exists:
                # Use parameterized boolean value - SQLAlchemy handles conversion for both PostgreSQL and SQLite
                conn.execute(
                    text("INSERT INTO webjob_state (job_name, flag, last_run_ok) VALUES (:n, :f, :ok)"),
                    {"n": job, "f": 0, "ok": True},
                )
        conn.commit()


def _migrate_sku_db():
    """Ensure vm_skus schema matches the current model.

    If ANY required column is missing, drop the table and recreate it.
    SKU data comes entirely from Azure and is re-synced on startup so
    losing stale rows is safe and preferable to a broken schema.
    """
    from sqlalchemy import text
    import models  # ensure SkuBase has VmSku registered

    required_columns = [
        "sku_type", "local_storage_gb", "rdma_enabled", "gpu_count",
        "gpu_memory_gb", "confidential_compute", "vcpus_available",
        "max_uncached_disk_iops", "max_uncached_disk_mbps", "cpu_arch", "hyper_v_gen",
    ]

    with _sku_engine.connect() as conn:
        # Check if using PostgreSQL or SQLite
        is_postgres = "postgresql" in str(_sku_engine.url)

        if is_postgres:
            # PostgreSQL: use information_schema
            rows = conn.execute(text(
                "SELECT column_name FROM information_schema.columns WHERE table_name = 'vm_skus'"
            )).fetchall()
            existing = {row[0] for row in rows}
        else:
            # SQLite: use PRAGMA
            rows = conn.execute(text("PRAGMA table_info(vm_skus)")).fetchall()
            existing = {row[1] for row in rows}

        # Table doesn't exist yet — create_all already handles it
        if not existing:
            return

        missing = [c for c in required_columns if c not in existing]
        if not missing:
            return  # schema is up to date

        print(f"DB migration: vm_skus missing columns {missing} — dropping and recreating")
        conn.execute(text("DROP TABLE IF EXISTS vm_skus"))
        conn.commit()

    # Recreate outside the connection context so SQLite releases the file lock
    SkuBase.metadata.create_all(bind=_sku_engine)
    print("DB migration: vm_skus recreated with current schema")
