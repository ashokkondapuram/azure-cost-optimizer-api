"""
WebJob 4 — Alert Dispatcher
=============================
Trigger : webjob_state.flag = 1 for 'webjob4_alerter' (set by webjob3)
Schedule : poll every 5 min  (App_Data/jobs/triggered/webjob4_alerter/settings.job)
Local run : python webjob4_alerter.py [--force]

Current mode: DB-only — writes Alert rows to the alerts table.
Channels (Teams webhook, SMTP email) are configured via the dashboard
at /alerts → Alert Settings, and will activate automatically once enabled.
"""

import base64
import json
import os
import smtplib
import ssl
import sys
import urllib.request
from datetime import datetime, timezone
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from database import SessionLocal, init_db
from models import PoolRecommendation, WebjobState, Alert, AlertConfig


def _get_flag(db, job_name: str) -> int:
    row = db.query(WebjobState).filter(WebjobState.job_name == job_name).first()
    return row.flag if row else 0


def _set_flag(db, job_name: str, flag: int):
    row = db.query(WebjobState).filter(WebjobState.job_name == job_name).first()
    if row:
        row.flag = flag
        row.updated_at = datetime.now(timezone.utc)
    db.commit()
    print(f"[wj4] ✓ DB write done: WebjobState flag set for {job_name}")


def _load_config(db) -> AlertConfig | None:
    return db.query(AlertConfig).filter(AlertConfig.id == 1).first()


# ── Channel senders (activated when config is enabled) ────────────────────────

def _send_teams(cfg: AlertConfig, recs: list[PoolRecommendation]) -> int:
    """POST each recommendation as a Teams MessageCard. Returns sent count."""
    if not cfg.teams_enabled or not cfg.teams_webhook_url:
        return 0
    sent = 0
    for rec in recs:
        sev_color = {"critical": "FF0000", "medium": "FFA500"}.get(rec.severity, "00AA00")
        payload = {
            "@type":    "MessageCard",
            "@context": "http://schema.org/extensions",
            "themeColor": sev_color,
            "summary":  f"AKS Cost Alert: {rec.cluster}/{rec.nodepool}",
            "sections": [{
                "activityTitle":    f"**{rec.cluster} / {rec.nodepool}**",
                "activitySubtitle": f"Severity: {rec.severity.upper()}  |  Saving: ${rec.saving or 0:.0f}/mo",
                "facts": [
                    {"name": "Region",       "value": rec.region or "—"},
                    {"name": "Current SKU",  "value": rec.current_sku or "—"},
                    {"name": "Nodes",        "value": str(rec.node_count or 0)},
                    {"name": "Empty nodes",  "value": str(rec.empty_nodes or 0)},
                    {"name": "CPU avg",      "value": f"{rec.cpu_avg_pct or 0:.1f}%"},
                    {"name": "Mem avg",      "value": f"{rec.mem_avg_pct or 0:.1f}%"},
                    {"name": "Pre-score",    "value": f"{rec.pre_score or 0:.1f}/10"},
                    {"name": "Recommended",  "value": rec.rec_sku or "—"},
                    {"name": "Verdict",      "value": rec.verdict or "Pre-score only"},
                ],
                "markdown": True,
            }],
        }
        if cfg.app_url:
            payload["potentialAction"] = [{
                "@type": "OpenUri", "name": "Open Dashboard",
                "targets": [{"os": "default", "uri": cfg.app_url.rstrip("/") + "/alerts"}],
            }]
        data = json.dumps(payload).encode()
        req  = urllib.request.Request(cfg.teams_webhook_url, data=data, method="POST")
        req.add_header("Content-Type", "application/json")
        ctx = ssl.create_default_context(); ctx.check_hostname = False; ctx.verify_mode = ssl.CERT_NONE
        try:
            with urllib.request.urlopen(req, context=ctx, timeout=15):
                pass
            print(f"  [wj4] Teams: sent {rec.cluster}/{rec.nodepool}")
            sent += 1
        except Exception as e:
            print(f"  [wj4] Teams failed {rec.cluster}/{rec.nodepool}: {e}")
    return sent


def _send_smtp(cfg: AlertConfig, recs: list[PoolRecommendation]) -> bool:
    """Send one summary email for all recommendations. Returns True on success."""
    if not cfg.smtp_enabled or not (cfg.smtp_host and cfg.smtp_user and cfg.smtp_pass_enc and cfg.smtp_to):
        return False
    recipients = [e.strip() for e in (cfg.smtp_to or "").split(",") if e.strip()]
    if not recipients:
        return False
    smtp_pass = base64.b64decode(cfg.smtp_pass_enc.encode()).decode()

    rows = "".join(
        f"<tr><td>{'🔴' if r.severity=='critical' else '🟡'} {r.severity.upper()}</td>"
        f"<td>{r.cluster}</td><td>{r.nodepool}</td>"
        f"<td>{r.current_sku or '—'}</td>"
        f"<td>{r.cpu_avg_pct or 0:.1f}%</td><td>{r.mem_avg_pct or 0:.1f}%</td>"
        f"<td>${r.saving or 0:.0f}/mo</td><td>{r.verdict or '—'}</td></tr>"
        for r in recs
    )
    link = f'<p><a href="{cfg.app_url}/alerts">Open Dashboard →</a></p>' if cfg.app_url else ""
    html = f"""<html><body>
<h2>AKS Cost Optimisation Alert</h2>
<table border="1" cellpadding="5" cellspacing="0" style="border-collapse:collapse">
  <tr style="background:#f0f0f0">
    <th>Severity</th><th>Cluster</th><th>Nodepool</th><th>SKU</th>
    <th>CPU Avg</th><th>Mem Avg</th><th>Saving</th><th>Verdict</th>
  </tr>{rows}
</table>{link}</body></html>"""

    msg          = MIMEMultipart("alternative")
    msg["Subject"] = f"[AKS Cost Alert] {len(recs)} pool(s) need attention"
    msg["From"]    = cfg.smtp_from or cfg.smtp_user
    msg["To"]      = ", ".join(recipients)
    msg.attach(MIMEText(html, "html"))
    try:
        with smtplib.SMTP(cfg.smtp_host, cfg.smtp_port or 587) as s:
            s.starttls(context=ssl.create_default_context())
            s.login(cfg.smtp_user, smtp_pass)
            s.sendmail(cfg.smtp_user, recipients, msg.as_string())
        print(f"  [wj4] SMTP: sent to {recipients}")
        return True
    except Exception as e:
        print(f"  [wj4] SMTP failed: {e}")
        return False


# ── Main ──────────────────────────────────────────────────────────────────────

def run(force: bool = False):
    init_db()
    db = SessionLocal()
    try:
        if not force:
            if _get_flag(db, "webjob4_alerter") != 1:
                print("[wj4] Flag not set — nothing to do")
                return
            _set_flag(db, "webjob4_alerter", 0)

        print(f"[wj4] Starting — {datetime.now(timezone.utc).isoformat()}")

        new_recs = (db.query(PoolRecommendation)
                    .filter(PoolRecommendation.alert_status == "new")
                    .order_by(PoolRecommendation.pre_score.desc())
                    .all())

        if not new_recs:
            print("[wj4] No new recommendations — nothing to dispatch")
            return

        cfg  = _load_config(db)
        now  = datetime.now(timezone.utc)

        # ── Send to configured channels (no-ops if not enabled) ──────────────
        if cfg:
            _send_teams(cfg, new_recs)
            _send_smtp(cfg,  new_recs)
        else:
            print("[wj4] No alert config found — DB-only mode")

        # ── Always write Alert rows to DB ─────────────────────────────────────
        for rec in new_recs:
            db.add(Alert(
                title        = f"{rec.severity.upper()}: {rec.cluster}/{rec.nodepool}",
                message      = (rec.verdict or
                                f"Pre-score {rec.pre_score:.1f}/10 · "
                                f"CPU {rec.cpu_avg_pct or 0:.1f}% · "
                                f"Mem {rec.mem_avg_pct or 0:.1f}% · "
                                f"Saving ${rec.saving or 0:.0f}/mo"),
                severity     = rec.severity,
                entity_type  = "nodepool",
                entity_name  = f"{rec.cluster}/{rec.nodepool}",
                cluster      = rec.cluster,
                triggered_by = "webjob4_alerter",
            ))
            rec.alert_status  = "sent"
            rec.alert_sent_at = now

        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob4_alerter").first()
        if row:
            row.last_run_at = now
            row.last_run_ok = True
        db.commit()
        print(f"[wj4] ✓ DB write done: Alerter state updated")
        print(f"[wj4] Done — {len(new_recs)} alert(s) written to DB")

    except Exception as e:
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob4_alerter").first()
        if row:
            row.last_run_ok = False
            row.last_error  = str(e)
            db.commit()
            print(f"[wj4] ✓ DB write done: Error recorded")
        print(f"[wj4] ERROR: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    run(force="--force" in sys.argv)
