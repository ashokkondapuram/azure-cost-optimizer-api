"""
WebJob — Quota Collector (Hourly)
==================================
Schedule : every 1 hour  (App_Data/jobs/triggered/webjob_quota_collector/settings.job)
Local run : python webjob_quota_collector.py

Responsibilities:
  1. Obtain Azure Management token via Managed Identity (cached)
  2. Bulk-fetch regional quota limits and usage via Azure Compute API (parallel threads)
  3. Bulk-upsert Quota table rows (new data overrides old)
  4. Store fetch timestamp for monitoring
"""

import json
import os
import sys
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

from sqlalchemy import delete
from database import SessionLocal, init_db
from azure_auth import _get_azure_token, _get_subscription_ids, _load_azure_db_creds
from models import Quota, WebjobState

# ── Config ─────────────────────────────────────────────────────────────────

_AZURE_REGIONS = [
    "eastus", "westus", "centralus", "northeurope", "westeurope",
    "eastasia", "southeastasia", "australiaeast", "canadacentral", "japaneast",
    "koreacentral", "southcentralus", "uksouth", "westcentralus", "switzerlandnorth"
]

# Quota resource types to include (all VM families + vCPU counts)
_QUOTA_KEYWORDS = [
    "Family", "cores", "vcpu", "Cores", "vCPU",
    "standardDs", "standardEs", "standardFs", "standardLs", "standardM",
    "basicA", "standardA", "standardB", "standardD", "standardE", "standardF",
    "promo"  # promotional SKUs
]


def _fetch_quota_for_region(subscription_id: str, region: str, access_token: str, debug: bool = False) -> list[dict]:
    """
    Fetch quota usage for a region via Azure Compute API.
    Returns list of {"resource_type": str, "limit": int, "current_usage": int, "unit": str}
    """
    import urllib.request

    url = f"https://management.azure.com/subscriptions/{subscription_id}/providers/Microsoft.Compute/locations/{region}/usages?api-version=2021-07-01"

    req = urllib.request.Request(url, method="GET")
    req.add_header("Authorization", f"Bearer {access_token}")
    req.add_header("Content-Type", "application/json")

    results = []
    try:
        import ssl
        ctx = ssl.create_default_context()
        ctx.check_hostname = False
        ctx.verify_mode = ssl.CERT_NONE
        with urllib.request.urlopen(req, context=ctx, timeout=30) as r:
            data = json.loads(r.read())
            usages = data.get("value", [])

            if debug:
                print(f"  {region}: {len(usages)} usage items returned")

            for usage in usages:
                # Safe extraction with fallbacks
                name_obj = usage.get("name", {})
                if not isinstance(name_obj, dict):
                    continue

                resource_type = name_obj.get("value", "")
                localized_name = name_obj.get("localizedValue", resource_type)
                limit = usage.get("limit")
                current = usage.get("currentValue")
                unit = usage.get("unit", "count")

                # Skip if no resource type
                if not resource_type:
                    if debug:
                        print(f"    [skip] Empty resource_type: {localized_name}")
                    continue

                # Skip if both limit and current are None/0
                if limit is None and current is None:
                    if debug:
                        print(f"    [skip] No limit/usage: {resource_type}")
                    continue

                # Convert to int, handling None
                try:
                    limit_int = int(limit) if limit is not None else 0
                    current_int = int(current) if current is not None else 0
                except (ValueError, TypeError):
                    if debug:
                        print(f"    [skip] Invalid numbers: {resource_type} limit={limit} current={current}")
                    continue

                # Filter to relevant quota types (VM families + core counts)
                # Include if matches any keyword OR has non-zero values
                include = (
                    any(kw.lower() in resource_type.lower() for kw in _QUOTA_KEYWORDS) or
                    limit_int > 0 or
                    current_int > 0
                )

                if include:
                    entry = {
                        "resource_type": resource_type,
                        "limit": limit_int,
                        "current_usage": current_int,
                        "unit": unit,
                    }
                    results.append(entry)
                    if debug:
                        print(f"    ✓ {resource_type}: limit={limit_int}, usage={current_int}, unit={unit}")
                else:
                    if debug:
                        print(f"    [skip] Filtered: {resource_type} (no keywords, zero values)")

    except urllib.error.HTTPError as e:
        error_body = e.read().decode(errors="replace")
        print(f"[quota] {region} HTTP {e.code}: {error_body[:200]}")
    except Exception as e:
        print(f"[quota] {region} failed: {e}")

    return results


def _bulk_fetch_quotas(subscription_ids: list[str], access_token: str, debug: bool = False) -> dict:
    """
    Bulk-fetch quotas for all regions and subscriptions in parallel.
    Returns: {sub_id: {region: [quota_entries]}}
    """
    results = {}

    def _fetch_sub_region(sub_id, region):
        quotas = _fetch_quota_for_region(sub_id, region, access_token, debug=debug)
        return (sub_id, region, quotas)

    with ThreadPoolExecutor(max_workers=10) as pool:
        futures = []
        for sub_id in subscription_ids:
            for region in _AZURE_REGIONS:
                futures.append(pool.submit(_fetch_sub_region, sub_id, region))

        for f in as_completed(futures):
            sub_id, region, quotas = f.result()
            if sub_id not in results:
                results[sub_id] = {}
            results[sub_id][region] = quotas

    return results


def _upsert_quotas(db, bulk_quotas: dict, now: datetime) -> int:
    """
    Bulk upsert quota rows. New data overrides old (via unique constraint).
    Returns count upserted.
    """
    import pandas as pd

    quota_rows = []
    for sub_id, regions in bulk_quotas.items():
        for region, entries in regions.items():
            for entry in entries:
                quota_rows.append({
                    "subscription_id": sub_id,
                    "region": region,
                    "resource_type": entry["resource_type"],
                    "limit": entry["limit"],
                    "current_usage": entry["current_usage"],
                    "available": max(0, entry["limit"] - entry["current_usage"]),
                    "unit": entry["unit"],
                    "fetched_at": now,
                })

    if not quota_rows:
        print("[quota] No quota rows to upsert")
        return 0

    # Clear old quotas for these subscription/region combos, then insert new ones
    sub_ids = list(bulk_quotas.keys())
    if sub_ids:
        db.execute(delete(Quota).where(Quota.subscription_id.in_(sub_ids)))
        db.commit()

    # Bulk insert new quotas
    db.bulk_insert_mappings(Quota, quota_rows)
    db.commit()

    return len(quota_rows)


def run(force: bool = False, debug: bool = False):
    """
    force=True skips webjob_state check — useful for local testing:
      python webjob_quota_collector.py --force

    debug=True shows detailed logging of what's being fetched:
      python webjob_quota_collector.py --force --debug
    """
    init_db()
    db = SessionLocal()

    try:
        print(f"[quota] Starting quota collector — {datetime.now(timezone.utc).isoformat()}")
        if debug:
            print("[quota] DEBUG MODE: Showing detailed fetch logs")

        # Load Azure DB config (tenant/client credentials for fallback auth)
        _load_azure_db_creds()

        # Obtain Azure Management token via Managed Identity (with caching)
        access_token = _get_azure_token()
        if not access_token:
            print("[quota] ERROR: Failed to get access token")
            return

        # Get subscription IDs (from DB > env > ARM API discovery)
        subscription_ids = _get_subscription_ids(access_token)
        if not subscription_ids:
            print("[quota] ERROR: No subscription IDs found")
            return

        print(f"[quota] Found {len(subscription_ids)} subscriptions: {', '.join(subscription_ids[:3])}{'...' if len(subscription_ids) > 3 else ''}")

        # Bulk-fetch quotas across all regions and subscriptions
        print(f"[quota] Fetching quotas for {len(subscription_ids)} subscriptions × {len(_AZURE_REGIONS)} regions…")
        bulk_quotas = _bulk_fetch_quotas(subscription_ids, access_token, debug=debug)

        # Analyze results
        total_quota_items = sum(
            len(entries)
            for regions in bulk_quotas.values()
            for entries in regions.values()
        )
        print(f"[quota] Fetched {total_quota_items} quota items from Azure")

        if total_quota_items == 0:
            print("[quota] WARNING: No quota data received from Azure!")
            print("[quota]   - Check subscription permissions (Compute API access required)")
            print("[quota]   - Verify subscriptions have VMs or are in allowed regions")
            print("[quota]   - Azure Compute API might be unavailable in some regions")

        # Upsert to database
        count = _upsert_quotas(db, bulk_quotas, datetime.now(timezone.utc))
        print(f"[quota] Upserted {count} quota records into database")

        # Update webjob state
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob_quota_collector").first()
        if not row:
            row = WebjobState(job_name="webjob_quota_collector")
            db.add(row)
        row.last_run_at = datetime.now(timezone.utc)
        row.last_run_ok = True
        row.context = {
            "last_fetch_items": count,
            "subscriptions": len(subscription_ids),
            "regions": len(_AZURE_REGIONS),
        }
        db.commit()
        print(f"[quota] ✓ DB write done: Collector state updated")

        print("[quota] Done")

    except Exception as e:
        row = db.query(WebjobState).filter(WebjobState.job_name == "webjob_quota_collector").first()
        if row:
            row.last_run_ok = False
            row.last_error = str(e)
            db.commit()
            print(f"[quota] ✓ DB write done: Error recorded")
        print(f"[quota] ERROR: {e}")
        raise

    finally:
        db.close()


if __name__ == "__main__":
    force = "--force" in sys.argv
    debug = "--debug" in sys.argv
    run(force=force, debug=debug)
