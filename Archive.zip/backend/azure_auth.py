"""
azure_auth.py — Shared Azure Managed Identity authentication with token caching.

Provides:
  - _get_azure_token()      → Fetch token with 55-min cache (App Service MI → IMDS → Azure CLI → Service Principal)
  - _load_azure_db_creds()  → Load Azure service principal config from AzureConfig DB
  - _get_subscription_ids() → Return subscription IDs (DB > env > ARM API discovery)

Token is cached at module level — all callers share one token fetch per 55 minutes.
"""

import base64
import json
import os
import subprocess
import threading
import time
import urllib.parse
import urllib.request
from database import SessionLocal

# ── Token caching: fetch Managed Identity token once, reuse for all API calls ────
_azure_token_cache = {"token": None, "expires_at": 0, "lock": threading.Lock()}
_AZURE_TOKEN_TTL_SECONDS = 55 * 60  # 55 minutes (Azure tokens valid for 60 min)

# In-memory cache of DB-stored Azure creds — loaded at startup and on PUT /api/azure-config
_azure_db_creds = {}   # keys: tenant_id, client_id, client_secret, subscription_ids


def _load_azure_db_creds():
    """Load AzureConfig from DB into the in-memory _azure_db_creds cache."""
    global _azure_db_creds
    from models import AzureConfig

    db = SessionLocal()
    try:
        cfg = db.query(AzureConfig).filter(AzureConfig.id == 1).first()
        if cfg:
            _azure_db_creds = {
                "tenant_id":        cfg.tenant_id or "",
                "client_id":        cfg.client_id or "",
                "client_secret":    (base64.b64decode(cfg.client_secret_enc.encode()).decode()
                                     if cfg.client_secret_enc else ""),
                "subscription_ids": cfg.subscription_ids or "",
            }
        else:
            _azure_db_creds = {}
    except Exception as e:
        print(f"[azure-config] Failed to load DB creds: {e}")
    finally:
        db.close()


def _get_azure_token() -> str:
    """
    Obtain an Azure Management token with caching. Three strategies in priority order:

    1. App Service Managed Identity  — uses IDENTITY_ENDPOINT + IDENTITY_HEADER
       env vars injected by Azure when a System/User-assigned MI is enabled.
    2. VM/IMDS Managed Identity      — fallback for VMs or older App Service plans.
    3. Azure CLI token              — local dev via `az login`.
    4. Service principal env vars   — local dev / CI fallback.

    Token is cached for 55 minutes — all endpoints share the same cached token
    to avoid repeated Managed Identity token requests.
    """
    now = time.time()

    # Check cache first (thread-safe)
    with _azure_token_cache["lock"]:
        if _azure_token_cache["token"] and _azure_token_cache["expires_at"] > now:
            print(f"[azure-auth] 🔄 Using cached token (expires in {int(_azure_token_cache['expires_at'] - now)}s)")
            return _azure_token_cache["token"]

    # Cache miss or expired — fetch new token
    resource = "https://management.azure.com/"
    print("[azure-auth] Starting token acquisition...")

    # 1. App Service Managed Identity (preferred on Azure App Service)
    identity_endpoint = os.getenv("IDENTITY_ENDPOINT", "")
    identity_header   = os.getenv("IDENTITY_HEADER", "")
    if identity_endpoint and identity_header:
        try:
            print(f"[azure-auth] Attempting App Service Managed Identity: {identity_endpoint[:50]}...")
            url = (f"{identity_endpoint}"
                   f"?api-version=2019-08-01"
                   f"&resource={urllib.parse.quote(resource)}")
            req = urllib.request.Request(
                url, headers={"X-IDENTITY-HEADER": identity_header})
            with urllib.request.urlopen(req, timeout=5) as r:
                token = json.loads(r.read().decode()).get("access_token", "")
            if token:
                print("[azure-auth] ✅ App Service Managed Identity successful")
                # Cache token with TTL
                with _azure_token_cache["lock"]:
                    _azure_token_cache["token"] = token
                    _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
                return token
        except Exception as e:
            print(f"[azure-auth] ❌ App Service MI failed: {type(e).__name__}: {e}")

    # 2. IMDS Managed Identity (VMs, older App Service plans)
    try:
        print("[azure-auth] Attempting IMDS Managed Identity: 169.254.169.254...")
        req = urllib.request.Request(
            f"http://169.254.169.254/metadata/identity/oauth2/token"
            f"?api-version=2018-02-01&resource={urllib.parse.quote(resource)}",
            headers={"Metadata": "true"},
        )
        with urllib.request.urlopen(req, timeout=3) as r:
            token = json.loads(r.read().decode()).get("access_token", "")
        if token:
            print("[azure-auth] ✅ IMDS Managed Identity successful")
            # Cache token with TTL
            with _azure_token_cache["lock"]:
                _azure_token_cache["token"] = token
                _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
            return token
    except Exception as e:
        print(f"[azure-auth] ❌ IMDS failed (expected in non-VM env): {type(e).__name__}")

    # 3. Azure CLI token (local dev — uses whichever account is logged in via `az login`)
    try:
        print("[azure-auth] Attempting Azure CLI token via 'az login'...")
        result = subprocess.run(
            ["az", "account", "get-access-token", "--resource", resource, "--query", "accessToken", "-o", "tsv"],
            capture_output=True, text=True, timeout=10,
        )
        token = result.stdout.strip()
        if token and not token.startswith("ERROR"):
            print("[azure-auth] ✅ Azure CLI token successful")
            # Cache token with TTL
            with _azure_token_cache["lock"]:
                _azure_token_cache["token"] = token
                _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
            return token
        if result.stderr:
            print(f"[azure-auth] ❌ Azure CLI error: {result.stderr}")
    except Exception as e:
        print(f"[azure-auth] ❌ Azure CLI failed: {type(e).__name__}: {e}")

    # 4. Service principal — DB config first, then env vars (local dev / CI)
    tid  = _azure_db_creds.get("tenant_id")     or os.getenv("AZURE_TENANT_ID", "")
    cid  = _azure_db_creds.get("client_id")     or os.getenv("AZURE_CLIENT_ID", "")
    csec = _azure_db_creds.get("client_secret") or os.getenv("AZURE_CLIENT_SECRET", "")

    if tid or cid:
        print(f"[azure-auth] Attempting Service Principal: {cid or '(from DB)'}...")

    if not all([tid, cid, csec]):
        print("[azure-auth] ❌ No authentication method available (no creds found)")
        return ""
    try:
        body = urllib.parse.urlencode({
            "grant_type": "client_credentials",
            "client_id": cid, "client_secret": csec,
            "scope": f"{resource}.default",
        }).encode()
        req = urllib.request.Request(
            f"https://login.microsoftonline.com/{tid}/oauth2/v2.0/token",
            data=body, method="POST",
        )
        with urllib.request.urlopen(req, timeout=15) as r:
            token = json.loads(r.read().decode()).get("access_token", "")
            if token:
                print(f"[azure-auth] ✅ Service Principal successful ({cid})")
                # Cache token with TTL
                with _azure_token_cache["lock"]:
                    _azure_token_cache["token"] = token
                    _azure_token_cache["expires_at"] = now + _AZURE_TOKEN_TTL_SECONDS
                return token
    except Exception as e:
        print(f"[azure-auth] ❌ Service Principal failed: {type(e).__name__}: {e}")

    print("[azure-auth] ❌ All authentication methods exhausted")
    return ""


def _get_subscription_ids(token: str) -> list:
    """Return configured subscription IDs (DB > env var > ARM API discovery)."""
    print("[azure-subs] Starting subscription lookup...")

    # Load DB config if not already loaded
    if not _azure_db_creds:
        _load_azure_db_creds()

    # Priority 1: DB config
    db_subs = [s.strip() for s in (_azure_db_creds.get("subscription_ids") or "").split(",") if s.strip()]
    if db_subs:
        print(f"[azure-subs] ✅ Found {len(db_subs)} subscription(s) from DB config")
        return db_subs

    # Priority 2: Environment variable
    env_subs = [
        s.strip() for s in
        os.environ.get("AZURE_SUBSCRIPTION_IDS",
                       os.environ.get("AZURE_SUBSCRIPTION_ID", "")).split(",")
        if s.strip()
    ]
    if env_subs:
        print(f"[azure-subs] ✅ Found {len(env_subs)} subscription(s) from env var")
        return env_subs

    # Priority 3: Discover via ARM API
    if not token:
        print("[azure-subs] ❌ No token available; cannot discover subscriptions via API")
        return []

    try:
        print("[azure-subs] Querying ARM API for subscriptions...")
        req = urllib.request.Request(
            "https://management.azure.com/subscriptions?api-version=2022-12-01",
            headers={"Authorization": f"Bearer {token}"},
        )
        with urllib.request.urlopen(req, timeout=10) as r:
            data = json.loads(r.read().decode())
            all_subs = data.get("value", [])
            subs = [s["subscriptionId"] for s in all_subs if s.get("state") == "Enabled"]
        print(f"[azure-subs] ✅ Discovered {len(subs)} enabled subscription(s) via API")
        return subs
    except Exception as e:
        print(f"[azure-subs] ❌ API discovery failed: {type(e).__name__}: {e}")
        return []
