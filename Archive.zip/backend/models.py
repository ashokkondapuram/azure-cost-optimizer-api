from datetime import datetime
from sqlalchemy import Column, Integer, String, Float, Text, DateTime, JSON, func, UniqueConstraint, Boolean
from database import Base, AuthBase, SkuBase


class Node(Base):
    __tablename__ = "nodes"

    id            = Column(Integer, primary_key=True, index=True)
    node_name     = Column(String, unique=True, nullable=False, index=True)
    cluster       = Column(String, index=True)
    nodepool      = Column(String, index=True)
    region        = Column(String, index=True)

    current_sku   = Column(String)
    rec_sku       = Column(String)
    cpu_alloc     = Column(Float)
    mem_alloc_gb  = Column(Float)
    cpu_avg_pct   = Column(Float)
    cpu_max_pct   = Column(Float)
    mem_avg_pct   = Column(Float)
    mem_max_pct   = Column(Float)
    cpu_avg_cores = Column(Float)
    cpu_max_cores = Column(Float)
    mem_avg_gb    = Column(Float)
    mem_max_gb    = Column(Float)
    current_price = Column(Float)
    rec_price     = Column(Float)
    saving        = Column(Float)
    saved_pct     = Column(Float)
    confidence       = Column(Integer)
    pod_count_30d_max = Column(Integer)   # 0 = no pods on this node in last 30 days

    status        = Column(String, default="pending", index=True)
    ai_reason     = Column(Text)
    ai_verdict    = Column(String)
    ai_assessed_at = Column(DateTime)

    last_fetched_at = Column(DateTime)
    created_at    = Column(DateTime, default=func.now())
    updated_at    = Column(DateTime, default=func.now(), onupdate=func.now())


class Container(Base):
    __tablename__ = "containers"

    id              = Column(Integer, primary_key=True, index=True)
    container_id    = Column(String, unique=True, nullable=False, index=True)  # namespace/name
    container_name  = Column(String, index=True)
    namespace       = Column(String, index=True)
    cluster         = Column(String, index=True)
    region          = Column(String)
    pod_count       = Column(Integer)
    pod_names       = Column(JSON)         # list of pod names running this container
    pod_node_map    = Column(JSON)         # {pod_name: node_name}
    node_names      = Column(JSON)         # list of nodes where pods run

    cpu_request     = Column(Float)
    cpu_limit       = Column(Float)
    mem_request_mib = Column(Float)
    mem_limit_mib   = Column(Float)
    cpu_avg         = Column(Float)
    cpu_p50         = Column(Float)
    cpu_p90         = Column(Float)
    cpu_p95         = Column(Float)
    cpu_max         = Column(Float)
    mem_avg_mib     = Column(Float)
    mem_p50_mib     = Column(Float)
    mem_p90_mib     = Column(Float)
    mem_p95_mib     = Column(Float)
    mem_max_mib     = Column(Float)
    cpu_util_pct    = Column(Float)
    mem_util_pct    = Column(Float)
    cpu_max_pct     = Column(Float)
    mem_max_pct     = Column(Float)

    rec_cpu_request = Column(Float)
    rec_cpu_limit   = Column(Float)
    rec_mem_req     = Column(Float)
    rec_mem_lim     = Column(Float)

    last_exit_reason = Column(String)   # e.g. OOMKilled, Error, Completed
    restart_count    = Column(Integer)

    status          = Column(String, default="pending", index=True)
    ai_reason       = Column(Text)
    ai_verdict      = Column(String)
    ai_assessed_at  = Column(DateTime)

    last_fetched_at = Column(DateTime)
    created_at      = Column(DateTime, default=func.now())
    updated_at      = Column(DateTime, default=func.now(), onupdate=func.now())


class ActionHistory(Base):
    __tablename__ = "action_history"

    id           = Column(Integer, primary_key=True, index=True)
    entity_type  = Column(String)   # "node" | "container"
    entity_name  = Column(String)
    action       = Column(String)   # "approved" | "ignored" | "ai_assessed" | "fetched" | "scheduled"
    performed_by = Column(String, default="system")
    details      = Column(JSON)
    created_at   = Column(DateTime, default=func.now(), index=True)


class FetchLog(Base):
    __tablename__ = "fetch_log"

    id             = Column(Integer, primary_key=True)
    started_at     = Column(DateTime, default=func.now())
    finished_at    = Column(DateTime)
    nodes_upserted = Column(Integer, default=0)
    ctrs_upserted  = Column(Integer, default=0)
    error          = Column(Text)


class User(AuthBase):
    __tablename__ = "users"

    id            = Column(Integer, primary_key=True)
    username      = Column(String, unique=True, nullable=False, index=True)
    password_hash = Column(String, nullable=False)
    role          = Column(String, nullable=False, default="viewer")  # admin | editor | viewer
    created_at    = Column(DateTime, default=func.now())


class UserSession(AuthBase):
    __tablename__ = "user_sessions"

    id         = Column(Integer, primary_key=True)
    token      = Column(String, unique=True, nullable=False, index=True)
    username   = Column(String, nullable=False)
    role       = Column(String, nullable=False)
    created_at = Column(DateTime, default=func.now())
    expires_at = Column(DateTime, nullable=False, index=True)


class Policy(Base):
    __tablename__ = "policies"

    id             = Column(Integer, primary_key=True)
    name           = Column(String, nullable=False)
    description    = Column(Text)
    enabled        = Column(Integer, default=0)          # 0/1
    min_confidence = Column(Integer, default=85)
    min_savings    = Column(Float, default=50)
    max_risk       = Column(String, default="low")       # low | medium | high
    category_mode  = Column(String, default="efficiency")# efficiency | idle | all
    cluster_filter = Column(String)                      # null = all clusters
    auto_approve   = Column(Integer, default=0)          # 0/1
    created_by     = Column(String, default="admin")
    created_at     = Column(DateTime, default=func.now())
    updated_at     = Column(DateTime, default=func.now(), onupdate=func.now())
    last_run_at    = Column(DateTime)
    last_run_count = Column(Integer, default=0)


class VmSku(SkuBase):
    __tablename__ = "vm_skus"
    __table_args__ = (UniqueConstraint("sku_name", "region", name="uq_vm_skus_name_region"),)

    id                     = Column(Integer, primary_key=True)
    sku_name               = Column(String, nullable=False, index=True)
    region                 = Column(String, nullable=False, index=True)
    tier                   = Column(String)           # Standard / Basic
    family                 = Column(String)           # e.g. standardDSv3Family
    vcpus                  = Column(Integer)
    vcpus_available        = Column(Integer)
    memory_gb              = Column(Float)
    max_data_disks         = Column(Integer)
    max_uncached_disk_iops = Column(Integer)
    max_uncached_disk_mbps = Column(Float)
    premium_io             = Column(Integer, default=0)   # 0/1
    accelerated_networking = Column(Integer, default=0)   # 0/1
    cpu_arch               = Column(String, default="x64")# x64 / Arm64
    hyper_v_gen            = Column(String)               # V1,V2
    max_nics               = Column(Integer)
    sku_type               = Column(String)                # General purpose | Memory optimized | etc.
    local_storage_gb       = Column(Float)                 # temp/NVMe local disk GiB (0 = none)
    rdma_enabled           = Column(Integer, default=0)    # 0/1
    gpu_count              = Column(Integer, default=0)    # number of GPUs
    gpu_memory_gb          = Column(Float)                 # GPU VRAM GiB
    confidential_compute   = Column(Integer, default=0)    # 0/1
    price_linux_hr         = Column(Float)
    price_windows_hr       = Column(Float)
    last_fetched_at        = Column(DateTime, index=True)
    created_at             = Column(DateTime, default=func.now())
    updated_at             = Column(DateTime, default=func.now(), onupdate=func.now())


class AlertConfig(Base):
    """Stores alert channel configuration (SMTP + Teams webhook). One row, id=1."""
    __tablename__ = "alert_config"

    id                 = Column(Integer, primary_key=True)
    # Teams / generic webhook
    teams_webhook_url  = Column(String)
    teams_enabled      = Column(Boolean, default=False)
    # SMTP
    smtp_host          = Column(String)
    smtp_port          = Column(Integer, default=587)
    smtp_user          = Column(String)
    smtp_pass_enc      = Column(String)   # base64-encoded; never returned to frontend
    smtp_from          = Column(String)
    smtp_to            = Column(String)   # comma-separated recipients
    smtp_enabled       = Column(Boolean, default=False)
    # Misc
    app_url            = Column(String)   # base URL for dashboard deep-links in alerts
    updated_at         = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by         = Column(String)


class WebjobState(Base):
    """Inter-webjob flags and run state. One row per job name."""
    __tablename__ = "webjob_state"

    id           = Column(Integer, primary_key=True)
    job_name     = Column(String, unique=True, nullable=False, index=True)
    # Flag a downstream job should check: 0 = idle, 1 = triggered
    flag         = Column(Integer, default=0, nullable=False)
    last_run_at  = Column(DateTime)
    last_run_ok  = Column(Boolean, default=True)
    last_error   = Column(Text)
    context      = Column(JSON)      # arbitrary payload passed between jobs
    updated_at   = Column(DateTime, default=func.now(), onupdate=func.now())


class PoolRecommendation(Base):
    """Pool-level AI / pre-score recommendations written by WebJob 3."""
    __tablename__ = "pool_recommendations"
    __table_args__ = (UniqueConstraint("cluster", "nodepool", name="uq_pool_rec"),)

    id             = Column(Integer, primary_key=True)
    cluster        = Column(String, nullable=False, index=True)
    nodepool       = Column(String, nullable=False, index=True)
    region         = Column(String)
    current_sku    = Column(String)
    node_count     = Column(Integer)

    # Pre-score (heuristic, no GPT) — 0–10
    pre_score      = Column(Float, default=0)
    severity       = Column(String, default="low")   # low | medium | critical

    # GPT result (only for critical pools)
    rec_sku        = Column(String)
    rec_node_count = Column(Integer)
    verdict        = Column(String)
    reason         = Column(Text)

    # Metrics snapshot at assessment time
    cpu_avg_pct    = Column(Float)
    mem_avg_pct    = Column(Float)
    empty_nodes    = Column(Integer, default=0)
    total_pods     = Column(Integer, default=0)
    saving         = Column(Float, default=0)

    # Alert lifecycle
    alert_status   = Column(String, default="new")   # new | sent | acknowledged
    alert_sent_at  = Column(DateTime)

    assessed_at    = Column(DateTime, default=func.now())
    updated_at     = Column(DateTime, default=func.now(), onupdate=func.now())


class Alert(Base):
    __tablename__ = "alerts"

    id           = Column(Integer, primary_key=True)
    title        = Column(String, nullable=False)
    message      = Column(Text, nullable=False)
    severity     = Column(String, default="info", index=True)  # info | warning | critical
    entity_type  = Column(String)                               # node | container | system
    entity_name  = Column(String)
    cluster      = Column(String, index=True)
    status       = Column(String, default="open", index=True)  # open | acknowledged | resolved
    triggered_by = Column(String, default="system")
    created_at   = Column(DateTime, default=func.now(), index=True)
    updated_at   = Column(DateTime, default=func.now(), onupdate=func.now())
    resolved_at  = Column(DateTime)


class Disk(Base):
    """Azure managed disks attached to nodes, with sizing and cost info.
    Fetched hourly via Azure Compute API. Upsert on each fetch (new data overrides old)."""
    __tablename__ = "disks"
    __table_args__ = (UniqueConstraint("subscription_id", "disk_id", name="uq_disk_sub_id"),)

    id               = Column(Integer, primary_key=True)
    subscription_id  = Column(String, nullable=False, index=True)
    disk_id          = Column(String, nullable=False, index=True)  # /subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.Compute/disks/{name}
    disk_name        = Column(String, nullable=False, index=True)
    resource_group   = Column(String, index=True)
    region           = Column(String, index=True)
    sku              = Column(String)  # Premium_LRS, Standard_LRS, StandardSSD_LRS, etc.
    size_gb          = Column(Integer)
    tier             = Column(String)  # Premium, Standard, StandardSSD
    iops             = Column(Integer)  # provisioned IOPS
    throughput_mbps  = Column(Integer)  # provisioned throughput

    # Attachment info
    attached_node_names = Column(JSON)  # list of node names this disk is attached to
    attached_vm_ids     = Column(JSON)  # list of VM resource IDs this disk is attached to
    is_attached         = Column(Boolean, default=False)  # True if currently attached to a VM

    # Lifecycle tracking
    creation_time    = Column(DateTime)                     # when disk was created
    last_attachment_time = Column(DateTime)                 # when disk was last attached to a VM
    days_since_last_use  = Column(Integer)                  # days since last attachment (for cleanup evaluation)

    # Cost estimate
    monthly_cost     = Column(Float)    # estimated monthly cost
    portal_url       = Column(String)   # deep-link to Azure Portal

    fetched_at       = Column(DateTime, nullable=False, default=func.now(), index=True)
    created_at       = Column(DateTime, default=func.now())
    updated_at       = Column(DateTime, default=func.now(), onupdate=func.now())


class Snapshot(Base):
    """Azure disk snapshots, with sizing and cost info.
    Fetched hourly via Azure Compute API. Upsert on each fetch (new data overrides old)."""
    __tablename__ = "snapshots"
    __table_args__ = (UniqueConstraint("subscription_id", "snapshot_id", name="uq_snapshot_sub_id"),)

    id               = Column(Integer, primary_key=True)
    subscription_id  = Column(String, nullable=False, index=True)
    snapshot_id      = Column(String, nullable=False, index=True)  # /subscriptions/{sub}/resourceGroups/{rg}/providers/Microsoft.Compute/snapshots/{name}
    snapshot_name    = Column(String, nullable=False, index=True)
    resource_group   = Column(String, index=True)
    region           = Column(String, index=True)
    sku              = Column(String)  # Premium_LRS, Standard_LRS, StandardSSD_LRS, etc.
    size_gb          = Column(Integer)
    tier             = Column(String)  # Premium, Standard, StandardSSD

    # Source info
    source_disk_id   = Column(String)   # If created from disk
    source_snapshot_id = Column(String)  # If created from snapshot

    # Cost estimate
    monthly_cost     = Column(Float)    # estimated monthly cost
    portal_url       = Column(String)   # deep-link to Azure Portal

    # Lifecycle (for cleanup/archival recommendations)
    creation_time    = Column(DateTime)
    age_days         = Column(Integer)  # days since creation

    fetched_at       = Column(DateTime, nullable=False, default=func.now(), index=True)
    created_at       = Column(DateTime, default=func.now())
    updated_at       = Column(DateTime, default=func.now(), onupdate=func.now())


class Quota(Base):
    """Azure subscription quota details (limits and usage) by region and resource type.
    Fetched hourly via Azure Compute API. Upsert on each fetch (new data overrides old)."""
    __tablename__ = "quotas"
    __table_args__ = (UniqueConstraint("subscription_id", "region", "resource_type", name="uq_quota_sub_region_type"),)

    id               = Column(Integer, primary_key=True)
    subscription_id  = Column(String, nullable=False, index=True)
    region           = Column(String, nullable=False, index=True)
    resource_type    = Column(String, nullable=False, index=True)  # e.g. "standardDSv5Family", "cores", "memory"
    limit            = Column(Integer)                              # quota limit (cores/vCPUs or count)
    current_usage    = Column(Integer)                              # current usage against quota
    available        = Column(Integer)                              # limit - current_usage
    unit             = Column(String)                               # "cores" | "count" | "vCPU"

    fetched_at       = Column(DateTime, nullable=False, default=func.now(), index=True)
    created_at       = Column(DateTime, default=func.now())
    updated_at       = Column(DateTime, default=func.now(), onupdate=func.now())


class AzureConfig(Base):
    """Azure subscription/tenant credentials for ARM API access. One row, id=1."""
    __tablename__ = "azure_config"

    id                 = Column(Integer, primary_key=True)
    subscription_ids   = Column(String)   # comma-separated subscription IDs
    tenant_id          = Column(String)
    client_id          = Column(String)
    client_secret_enc  = Column(String)   # base64-encoded; never returned to frontend
    updated_at         = Column(DateTime, default=func.now(), onupdate=func.now())
    updated_by         = Column(String)


class ClusterRegistry(Base):
    """Registry of all AKS clusters discovered across all resource groups.
    Built by webjob_cluster_discovery to provide cluster location lookup."""
    __tablename__ = "cluster_registry"
    __table_args__ = (UniqueConstraint("cluster_name", "subscription_id", name="uq_cluster_sub"),)

    id                 = Column(Integer, primary_key=True)
    cluster_name       = Column(String, nullable=False, index=True)  # e.g., "cbadevv2rg3ae"
    subscription_id    = Column(String, nullable=False, index=True)
    resource_group     = Column(String, nullable=False, index=True)
    location           = Column(String, index=True)                  # e.g., "australiaeast"
    cluster_id         = Column(String)                              # full resource ID
    created_at         = Column(DateTime, default=func.now())
    updated_at         = Column(DateTime, default=func.now(), onupdate=func.now())


class ClusterMapping(Base):
    """Map Prometheus datasource names → Azure AKS cluster names.
    Grafana datasources may not match actual Azure cluster names; this table provides the mapping."""
    __tablename__ = "cluster_mappings"
    __table_args__ = (UniqueConstraint("datasource_name", name="uq_datasource_name"),)

    id                 = Column(Integer, primary_key=True)
    datasource_name    = Column(String, nullable=False, index=True)  # e.g., "fcbqav3rg2eu2"
    azure_cluster_name = Column(String, nullable=False, index=True)  # e.g., "prod-aks-eastus"
    subscription_id    = Column(String)                              # optional: which subscription
    created_at         = Column(DateTime, default=func.now())
    updated_at         = Column(DateTime, default=func.now(), onupdate=func.now())
