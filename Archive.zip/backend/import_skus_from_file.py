"""
import_skus_from_file.py
------------------------
Reads azure_sku.json from the same directory and upserts all VM SKU
capabilities into the vm_skus table.

Usage:
    python import_skus_from_file.py [path/to/azure_sku.json]

If no path is given it looks for azure_sku.json next to this script.
"""

import json
import sys
from datetime import datetime, timezone
from pathlib import Path

# Allow running from any directory
sys.path.insert(0, str(Path(__file__).parent))

from database import SessionLocal, init_db
from models import VmSku


def _cap(capabilities: list, name: str, default=None):
    """Extract a named capability value from the capabilities list."""
    for c in capabilities:
        if c.get("name") == name:
            return c.get("value")
    return default


def _bool_cap(capabilities: list, name: str) -> int:
    v = _cap(capabilities, name, "False")
    return 1 if str(v).lower() == "true" else 0


def import_skus(json_path: str):
    data = json.loads(Path(json_path).read_text())
    items = data.get("value", [])

    # Handle paginated nextLink — just process whatever is in the file
    print(f"Found {len(items)} SKU entries in {json_path}")

    init_db()
    db = SessionLocal()
    now = datetime.now(timezone.utc)
    upserted = 0
    skipped  = 0

    try:
        for item in items:
            if item.get("resourceType") != "virtualMachines":
                skipped += 1
                continue

            sku_name = item.get("name")
            if not sku_name:
                skipped += 1
                continue

            caps = item.get("capabilities", [])
            locations = item.get("locations", [])

            for location in locations:
                region = location.lower()

                existing = (
                    db.query(VmSku)
                    .filter(VmSku.sku_name == sku_name, VmSku.region == region)
                    .first()
                )
                row = existing or VmSku(sku_name=sku_name, region=region)
                if not existing:
                    db.add(row)

                row.tier   = item.get("tier")
                row.family = item.get("family")

                vcpus_val = _cap(caps, "vCPUs")
                if vcpus_val is not None:
                    row.vcpus = int(vcpus_val)

                vcpus_avail = _cap(caps, "vCPUsAvailable")
                if vcpus_avail is not None:
                    row.vcpus_available = int(vcpus_avail)

                mem_val = _cap(caps, "MemoryGB")
                if mem_val is not None:
                    row.memory_gb = float(mem_val)

                max_disks = _cap(caps, "MaxDataDiskCount")
                if max_disks is not None:
                    row.max_data_disks = int(max_disks)

                iops = _cap(caps, "UncachedDiskIOPS")
                if iops is not None:
                    row.max_uncached_disk_iops = int(iops)

                mbps = _cap(caps, "UncachedDiskBytesPerSecond")
                if mbps is not None:
                    row.max_uncached_disk_mbps = float(mbps) / (1024 * 1024)

                row.premium_io             = _bool_cap(caps, "PremiumIO")
                row.accelerated_networking = _bool_cap(caps, "AcceleratedNetworkingEnabled")

                hyper_v = _cap(caps, "HyperVGenerations")
                if hyper_v:
                    row.hyper_v_gen = hyper_v

                max_nics = _cap(caps, "MaxNetworkInterfaces")
                if max_nics is not None:
                    row.max_nics = int(max_nics)

                row.last_fetched_at = now
                upserted += 1

        db.commit()
        print(f"Done — {upserted} rows upserted, {skipped} entries skipped")
    except Exception as e:
        db.rollback()
        print(f"Error: {e}")
        raise
    finally:
        db.close()


if __name__ == "__main__":
    # Accept azure_sku.json, azure_skus.json, or azuresku.json in that order
    _here = Path(__file__).parent
    candidates = ["preprod_sku.json", "azure_sku.json", "azure_skus.json", "azuresku.json"]
    default = next((str(_here / f) for f in candidates if (_here / f).exists() and (_here / f).stat().st_size > 0), str(_here / "azure_sku.json"))
    path = sys.argv[1] if len(sys.argv) > 1 else default
    import_skus(path)
