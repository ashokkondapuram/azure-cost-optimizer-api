#!/bin/bash
set -e

PACKAGES_DIR="/home/packages"
REQ_FILE="/home/site/wwwroot/requirements.txt"
HASH_FILE="$PACKAGES_DIR/.req_hash"
REQ_HASH=$(md5sum "$REQ_FILE" | cut -d' ' -f1)

if [ ! -f "$HASH_FILE" ] || [ "$(cat "$HASH_FILE")" != "$REQ_HASH" ]; then
    echo "Installing/updating packages..."
    pip install -r "$REQ_FILE" --target="$PACKAGES_DIR" --upgrade -q
    echo "$REQ_HASH" > "$HASH_FILE"
    echo "Packages installed."
fi

export PYTHONPATH="$PACKAGES_DIR"
cd /home/site/wwwroot/backend
exec python -m uvicorn main:app --host 0.0.0.0 --port 8000 --workers 1
